
  # Interactive Prototype for LinguaLink

  This is a code bundle for Interactive Prototype for LinguaLink. The original project is available at https://www.figma.com/design/wCkmJxp7b2VRLVSkvpIYiW/Interactive-Prototype-for-LinguaLink.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  