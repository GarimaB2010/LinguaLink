import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Camera, Mic, MicOff, CameraOff, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { toast } from 'sonner@2.0.3';

interface MediaStreamManagerProps {
  enableCamera?: boolean;
  enableMicrophone?: boolean;
  onStreamReady?: (stream: MediaStream) => void;
  onError?: (error: string) => void;
  children?: React.ReactNode;
}

export function MediaStreamManager({ 
  enableCamera = false, 
  enableMicrophone = false, 
  onStreamReady, 
  onError,
  children 
}: MediaStreamManagerProps) {
  const [isActive, setIsActive] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRequesting, setIsRequesting] = useState(false);
  const [audioLevel, setAudioLevel] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number>();

  const requestMediaAccess = async () => {
    try {
      setIsRequesting(true);
      toast.info('🚀 Starting media access...', { duration: 2000 });

      const constraints: MediaStreamConstraints = {};
      
      if (enableCamera) {
        constraints.video = {
          width: { ideal: 1280, min: 640 },
          height: { ideal: 720, min: 480 },
          frameRate: { ideal: 30, min: 15 }
        };
      }
      
      if (enableMicrophone) {
        constraints.audio = {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 44100
        };
      }

      if (!constraints.video && !constraints.audio) {
        throw new Error('No media constraints specified');
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      
      if (!mediaStream || !mediaStream.active) {
        throw new Error('Failed to get active media stream');
      }

      setStream(mediaStream);
      setIsActive(true);

      // Set up video preview
      if (enableCamera && videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play().catch(console.error);
      }

      // Set up audio level monitoring
      if (enableMicrophone) {
        setupAudioLevelMonitoring(mediaStream);
      }

      onStreamReady?.(mediaStream);
      
      toast.success(`✅ ${enableCamera ? '📹 Camera' : ''} ${enableMicrophone ? '🎤 Microphone' : ''} is now active!`, { 
        duration: 3000 
      });

      console.log('✅ Media stream active:', {
        video: mediaStream.getVideoTracks().length > 0,
        audio: mediaStream.getAudioTracks().length > 0,
        tracks: mediaStream.getTracks().map(t => ({ kind: t.kind, enabled: t.enabled, readyState: t.readyState }))
      });

    } catch (error: any) {
      console.error('❌ Media access failed:', error);
      const errorMsg = error.name === 'NotAllowedError' 
        ? 'Permission denied - please allow camera/microphone access'
        : error.name === 'NotFoundError'
        ? 'Camera or microphone not found'
        : `Media access failed: ${error.message}`;
      
      onError?.(errorMsg);
      toast.error(`❌ ${errorMsg}`, { duration: 5000 });
    } finally {
      setIsRequesting(false);
    }
  };

  const setupAudioLevelMonitoring = (mediaStream: MediaStream) => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const analyser = audioContext.createAnalyser();
      const microphone = audioContext.createMediaStreamSource(mediaStream);
      
      analyser.fftSize = 256;
      microphone.connect(analyser);
      
      audioContextRef.current = audioContext;
      analyserRef.current = analyser;
      
      const updateAudioLevel = () => {
        if (analyserRef.current) {
          const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
          analyserRef.current.getByteFrequencyData(dataArray);
          
          const average = dataArray.reduce((sum, value) => sum + value, 0) / dataArray.length;
          const normalizedLevel = Math.min(100, (average / 255) * 100);
          
          setAudioLevel(normalizedLevel);
        }
        
        if (isActive) {
          animationFrameRef.current = requestAnimationFrame(updateAudioLevel);
        }
      };
      
      updateAudioLevel();
    } catch (error) {
      console.error('Audio level monitoring setup failed:', error);
    }
  };

  const stopMediaAccess = () => {
    if (stream) {
      stream.getTracks().forEach(track => {
        track.stop();
        console.log(`Stopped ${track.kind} track`);
      });
      setStream(null);
    }

    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }

    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }

    setIsActive(false);
    setAudioLevel(0);
    toast.info('📱 Media access stopped', { duration: 2000 });
  };

  // Auto-request on mount if enabled
  useEffect(() => {
    if (enableCamera || enableMicrophone) {
      requestMediaAccess();
    }

    return () => {
      stopMediaAccess();
    };
  }, [enableCamera, enableMicrophone]);

  return (
    <div className="w-full">
      {/* Media Controls */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          {enableCamera && (
            <div className="flex items-center space-x-2">
              {isActive ? (
                <Camera className="w-5 h-5 text-green-500" />
              ) : (
                <CameraOff className="w-5 h-5 text-gray-400" />
              )}
              <span className="text-sm">{isActive ? 'Camera Active' : 'Camera Off'}</span>
            </div>
          )}
          
          {enableMicrophone && (
            <div className="flex items-center space-x-2">
              {isActive ? (
                <Mic className="w-5 h-5 text-green-500" />
              ) : (
                <MicOff className="w-5 h-5 text-gray-400" />
              )}
              <span className="text-sm">{isActive ? 'Microphone Active' : 'Microphone Off'}</span>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-2">
          {!isActive ? (
            <Button
              onClick={requestMediaAccess}
              disabled={isRequesting}
              size="sm"
              className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600"
            >
              {isRequesting ? (
                <>
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-4 h-4 mr-2"
                  >
                    <Zap className="w-4 h-4" />
                  </motion.div>
                  Starting...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Start Media
                </>
              )}
            </Button>
          ) : (
            <Button
              onClick={stopMediaAccess}
              size="sm"
              variant="outline"
              className="border-red-300 text-red-600 hover:bg-red-50"
            >
              Stop Media
            </Button>
          )}
        </div>
      </div>

      {/* Media Preview */}
      {isActive && (
        <div className="space-y-4">
          {/* Camera Preview */}
          {enableCamera && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative bg-black rounded-lg overflow-hidden"
            >
              <video
                ref={videoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs flex items-center">
                <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse" />
                LIVE
              </div>
            </motion.div>
          )}

          {/* Audio Level Monitor */}
          {enableMicrophone && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Audio Level</span>
                <span className="text-sm font-mono">{Math.round(audioLevel)}%</span>
              </div>
              <Progress value={audioLevel} className="h-2" />
              {audioLevel > 0 && (
                <div className="text-xs text-green-600 flex items-center">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse" />
                  Detecting audio input
                </div>
              )}
            </motion.div>
          )}
        </div>
      )}

      {/* Children content */}
      {children && (
        <div className="mt-4">
          {children}
        </div>
      )}
    </div>
  );
}

// Helper hook for easy media access
export function useMediaStream(enableCamera = false, enableMicrophone = false) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isActive, setIsActive] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startStream = async () => {
    try {
      const constraints: MediaStreamConstraints = {};
      
      if (enableCamera) {
        constraints.video = { width: 1280, height: 720 };
      }
      
      if (enableMicrophone) {
        constraints.audio = {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        };
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      setIsActive(true);
      setError(null);
      
      return mediaStream;
    } catch (err: any) {
      setError(err.message);
      setIsActive(false);
      throw err;
    }
  };

  const stopStream = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsActive(false);
  };

  useEffect(() => {
    return () => {
      stopStream();
    };
  }, []);

  return {
    stream,
    isActive,
    error,
    startStream,
    stopStream
  };
}