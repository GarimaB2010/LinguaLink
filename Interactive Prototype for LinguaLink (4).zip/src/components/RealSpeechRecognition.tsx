import { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Mic, MicOff, Volume2, AlertCircle, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Alert, AlertDescription } from "./ui/alert";
import { InteractiveWaveform } from "./InteractiveWaveform";

interface RealSpeechRecognitionProps {
  onTranscript: (text: string) => void;
  onError: (error: string) => void;
  isActive: boolean;
  language?: string;
}

export function RealSpeechRecognition({ onTranscript, onError, isActive, language = 'en-US' }: RealSpeechRecognitionProps) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [confidence, setConfidence] = useState(0);
  const [permissionStatus, setPermissionStatus] = useState<'granted' | 'denied' | 'prompt' | 'checking'>('checking');
  const [isSupported, setIsSupported] = useState(true);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Check microphone permissions
  const checkMicrophonePermissions = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setPermissionStatus('denied');
        return false;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      setPermissionStatus('granted');
      
      // Stop the stream immediately as we just needed to check permissions
      stream.getTracks().forEach(track => track.stop());
      
      return true;
    } catch (error: any) {
      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
        setPermissionStatus('denied');
        onError('Microphone access denied. Please grant permission and refresh the page.');
      } else if (error.name === 'NotFoundError') {
        setPermissionStatus('denied');
        onError('No microphone found. Please connect a microphone.');
      } else {
        setPermissionStatus('denied');
        onError('Microphone access error: ' + error.message);
      }
      return false;
    }
  };

  useEffect(() => {
    // Check if browser supports speech recognition
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setIsSupported(false);
      onError('Speech recognition not supported in this browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    // Check permissions on mount
    checkMicrophonePermissions();

    // Initialize speech recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = language;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i];
        if (result.isFinal) {
          finalTranscript += result[0].transcript;
          setConfidence(result[0].confidence);
        } else {
          interimTranscript += result[0].transcript;
        }
      }

      const fullTranscript = finalTranscript || interimTranscript;
      setTranscript(fullTranscript);
      
      if (finalTranscript) {
        onTranscript(finalTranscript.trim());
      }
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      console.error('Speech recognition error:', event.error);
      onError(`Speech recognition error: ${event.error}`);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [language, onTranscript, onError]);

  const startListening = async () => {
    if (permissionStatus !== 'granted') {
      const hasPermission = await checkMicrophonePermissions();
      if (!hasPermission) {
        return;
      }
    }
    
    if (recognitionRef.current && !isListening) {
      setTranscript('');
      setConfidence(0);
      try {
        recognitionRef.current.start();
      } catch (error) {
        console.error('Failed to start recognition:', error);
        onError('Failed to start speech recognition');
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  const toggleListening = async () => {
    if (isListening) {
      stopListening();
    } else {
      await startListening();
    }
  };

  // Auto-start/stop based on isActive prop
  useEffect(() => {
    if (isActive && !isListening && permissionStatus === 'granted') {
      startListening();
    } else if (!isActive && isListening) {
      stopListening();
    }
  }, [isActive, permissionStatus]);

  return (
    <div className="space-y-4">
      {/* Permission Error Alert */}
      {permissionStatus === 'denied' && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-red-50 border border-red-200 rounded-xl mb-4"
        >
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-medium text-red-800 mb-1">🎤 Microphone Access Required</h4>
              <p className="text-sm text-red-600 mb-3">
                Please allow microphone access to use speech recognition.
              </p>
              <div className="text-xs text-red-600 space-y-1 mb-3">
                <p>How to enable:</p>
                <p>1. Click the 🔒 or microphone icon in your address bar</p>
                <p>2. Allow microphone permissions for this site</p>
                <p>3. Refresh the page</p>
              </div>
              <Button
                onClick={checkMicrophonePermissions}
                variant="outline"
                size="sm"
                className="border-red-300 text-red-700 hover:bg-red-100"
              >
                🔄 Retry Microphone Access
              </Button>
            </div>
          </div>
        </motion.div>
      )}

      {!isSupported && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-yellow-50 border border-yellow-200 rounded-xl mb-4"
        >
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-yellow-800 mb-1">⚠️ Browser Not Supported</h4>
              <p className="text-sm text-yellow-600">
                Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.
              </p>
            </div>
          </div>
        </motion.div>
      )}

      <div className="text-center">
        <motion.button
          onClick={toggleListening}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          disabled={!isSupported || permissionStatus === 'denied'}
          className={`w-20 h-20 rounded-full flex items-center justify-center text-white shadow-lg ${
            !isSupported || permissionStatus === 'denied'
              ? 'bg-gray-400 cursor-not-allowed'
              : isListening 
                ? 'bg-gradient-to-r from-red-500 to-pink-500 animate-pulse' 
                : 'bg-gradient-to-r from-blue-500 to-purple-500'
          }`}
        >
          {isListening ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
        </motion.button>
        
        <p className="mt-3 text-sm text-muted-foreground">
          {!isSupported || permissionStatus === 'denied'
            ? '❌ Microphone unavailable'
            : permissionStatus === 'checking'
              ? '🔍 Checking permissions...'
              : isListening 
                ? '🎤 Listening... Tap to stop' 
                : '🎙️ Tap to start speaking'
          }
        </p>
        
        {confidence > 0 && (
          <div className="mt-2">
            <div className="text-xs text-muted-foreground mb-1">
              Confidence: {Math.round(confidence * 100)}%
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <motion.div
                className="bg-gradient-to-r from-green-400 to-blue-500 h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${confidence * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>
        )}
      </div>

      {isListening && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <InteractiveWaveform isActive={isListening} className="h-16 mb-4" />
        </motion.div>
      )}

      {transcript && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-200"
        >
          <h4 className="text-sm font-medium text-blue-700 mb-2">
            {isListening ? '🎵 Live Transcript' : '✅ Final Result'}
          </h4>
          <p className="text-sm text-blue-800">{transcript}</p>
        </motion.div>
      )}
    </div>
  );
}