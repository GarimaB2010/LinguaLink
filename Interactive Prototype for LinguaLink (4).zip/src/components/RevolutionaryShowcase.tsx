import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, Heart, Eye, Activity, Globe, Zap, Sparkles, Rocket } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';

interface ShowcaseProps {
  onFeatureSelect: (feature: string) => void;
}

export function RevolutionaryShowcase({ onFeatureSelect }: ShowcaseProps) {
  const [currentFeature, setCurrentFeature] = useState(0);
  const [isAnimating, setIsAnimating] = useState(true);

  const features = [
    {
      id: 'quantum',
      icon: Brain,
      name: 'Quantum Translation Engine',
      description: 'Multi-dimensional linguistic processing that transcends traditional translation',
      color: 'from-purple-500 to-indigo-600',
      particles: '🧠✨🔮⚡',
      stats: 'Progress: 99.7% accuracy • 50+ languages • Cultural context aware'
    },
    {
      id: 'empathy',
      icon: Heart,
      name: 'Neural Empathy Synchronization',
      description: 'Real-time emotional intelligence that creates deeper human connections',
      color: 'from-rose-500 to-pink-600',
      particles: '💖🌟💫❤️',
      stats: 'Bio-signals: Heart rate, stress, emotion • Empathy score: 97.3%'
    },
    {
      id: 'hologram',
      icon: Eye,
      name: 'Holographic Gesture Interface',
      description: 'Spatial computing interface that responds to gestures in 3D space',
      color: 'from-blue-500 to-cyan-600',
      particles: '✨👁️🌀💎',
      stats: 'Recognition: 15+ gestures • Accuracy: 94.8% • Real-time tracking'
    },
    {
      id: 'bio',
      icon: Activity,
      name: 'Bio-Rhythmic Communication Matching',
      description: 'Adapts communication style based on your biological rhythms',
      color: 'from-green-500 to-emerald-600',
      particles: '🧬⚡🌊💚',
      stats: 'Monitors: Circadian rhythm, energy, focus • Optimization: 96.1%'
    },
    {
      id: 'cultural',
      icon: Globe,
      name: 'Cultural Dimension Bridge',
      description: 'Bridges cultural communication gaps with deep contextual understanding',
      color: 'from-orange-500 to-red-600',
      particles: '🌍🌉🎭🌺',
      stats: 'Cultures: 25+ mapped • Dimensions: 5 core aspects • Harmony: 98.4%'
    },
    {
      id: 'synaptic',
      icon: Zap,
      name: 'Synaptic Learning Assistant',
      description: 'AI that evolves and learns your unique communication patterns',
      color: 'from-violet-500 to-purple-600',
      particles: '⚡🧠🔗💫',
      stats: 'Learning: Continuous adaptation • Patterns: 100+ analyzed • Evolution: Active'
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const currentFeat = features[currentFeature];
  const FeatureIcon = currentFeat.icon;

  return (
    <div className="space-y-6">
      {/* Main Showcase */}
      <Card className="relative overflow-hidden bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 text-white border-0 shadow-2xl">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-blue-500/10" />
        
        {/* Animated Background Particles */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              animate={{
                x: [0, 100, -50, 0],
                y: [0, -100, 50, 0],
                opacity: [0.1, 0.5, 0.2, 0.1],
                scale: [1, 1.5, 0.5, 1]
              }}
              transition={{
                duration: 10 + Math.random() * 10,
                repeat: Infinity,
                delay: Math.random() * 5,
                ease: "linear"
              }}
              className="absolute w-2 h-2 bg-white rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`
              }}
            />
          ))}
        </div>

        <CardContent className="p-8 relative z-10">
          <div className="text-center mb-6">
            <motion.div
              animate={{ 
                rotate: [0, 360],
                scale: [1, 1.2, 1]
              }}
              transition={{ 
                duration: 8, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="text-6xl mb-4"
            >
              🚀
            </motion.div>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent mb-2">
              Revolutionary AI Technology
            </h2>
            <p className="text-purple-200">
              Experience features that exist nowhere else on Earth
            </p>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentFeature}
              initial={{ opacity: 0, y: 30, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -30, scale: 1.1 }}
              transition={{ duration: 0.8 }}
              className="space-y-6"
            >
              {/* Feature Display */}
              <div className={`p-6 bg-gradient-to-r ${currentFeat.color} rounded-2xl shadow-lg`}>
                <div className="flex items-center space-x-4 mb-4">
                  <motion.div
                    animate={{ 
                      rotate: [0, 10, -10, 0],
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ 
                      duration: 3, 
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center"
                  >
                    <FeatureIcon className="w-6 h-6" />
                  </motion.div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold">{currentFeat.name}</h3>
                    <p className="text-white/90 text-sm">{currentFeat.description}</p>
                  </div>
                </div>

                <div className="bg-white/10 rounded-lg p-3 mb-4">
                  <p className="text-xs text-white/80">{currentFeat.stats}</p>
                </div>

                <div className="flex justify-between items-center">
                  <div className="text-2xl space-x-1">
                    {currentFeat.particles.split('').map((particle, i) => (
                      <motion.span
                        key={i}
                        animate={{
                          y: [0, -10, 0],
                          rotate: [0, 180, 360],
                          scale: [1, 1.2, 1]
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: i * 0.2,
                          ease: "easeInOut"
                        }}
                        className="inline-block"
                      >
                        {particle}
                      </motion.span>
                    ))}
                  </div>
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button
                      onClick={() => onFeatureSelect(currentFeat.id)}
                      className="bg-white/20 hover:bg-white/30 backdrop-blur-sm"
                    >
                      Try It Now ✨
                    </Button>
                  </motion.div>
                </div>
              </div>

              {/* Feature Progress Indicator */}
              <div className="flex justify-center space-x-2">
                {features.map((_, index) => (
                  <motion.button
                    key={index}
                    onClick={() => setCurrentFeature(index)}
                    animate={{
                      scale: index === currentFeature ? 1.2 : 1,
                      opacity: index === currentFeature ? 1 : 0.5
                    }}
                    className={`w-3 h-3 rounded-full ${
                      index === currentFeature 
                        ? 'bg-yellow-400' 
                        : 'bg-white/30'
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Feature Grid Preview */}
      <div className="grid grid-cols-3 gap-3">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <motion.div
              key={feature.id}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              animate={{
                opacity: index === currentFeature ? 1 : 0.7,
                scale: index === currentFeature ? 1.02 : 1,
                borderColor: index === currentFeature ? '#8B5CF6' : 'transparent'
              }}
              transition={{ duration: 0.3 }}
              className={`p-3 bg-gradient-to-r ${feature.color} rounded-lg cursor-pointer border-2`}
              onClick={() => {
                setCurrentFeature(index);
                onFeatureSelect(feature.id);
              }}
            >
              <div className="text-center text-white">
                <Icon className="w-6 h-6 mx-auto mb-1" />
                <p className="text-xs font-medium">{feature.name.split(' ')[0]}</p>
                <p className="text-xs font-medium">{feature.name.split(' ')[1]}</p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Call to Action */}
      <Card className="bg-gradient-to-r from-yellow-400/20 to-orange-400/20 border-yellow-500/30">
        <CardContent className="p-4 text-center">
          <motion.div
            animate={{ 
              rotate: [0, 5, -5, 0],
              scale: [1, 1.05, 1]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="text-4xl mb-2"
          >
            🏆
          </motion.div>
          <h3 className="font-bold text-lg bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent mb-2">
            Ready to Experience the Future?
          </h3>
          <p className="text-sm text-muted-foreground mb-3">
            These revolutionary features are exclusive to LinguaLink and exist nowhere else!
          </p>
          <motion.div
            animate={{ opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="text-xs text-orange-600 font-medium"
          >
            🌟 Innovation that will change how humans communicate forever 🌟
          </motion.div>
        </CardContent>
      </Card>
    </div>
  );
}