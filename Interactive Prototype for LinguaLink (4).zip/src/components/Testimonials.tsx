import { motion } from "motion/react";
import { Star, Quote } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Avatar, AvatarFallback } from "./ui/avatar";

export function Testimonials() {
  const testimonials = [
    {
      name: "Dr. Sarah Chen",
      role: "Emergency Physician",
      avatar: "SC",
      rating: 5,
      text: "LinguaLink has revolutionized how I communicate with patients. The real-time translation and simplified explanations help me provide better care to everyone.",
      color: "from-red-400 to-pink-400"
    },
    {
      name: "Maria Rodriguez",
      role: "ESL Student",
      avatar: "MR",
      rating: 5,
      text: "Finally, I can understand complex academic texts! The simplification feature makes learning so much easier for non-native speakers.",
      color: "from-blue-400 to-purple-400"
    },
    {
      name: "James Wilson",
      role: "Legal Aid Lawyer",
      avatar: "JW",
      rating: 5,
      text: "This tool breaks down language barriers in legal consultations. My clients finally understand their rights and options clearly.",
      color: "from-green-400 to-blue-400"
    }
  ];

  return (
    <div className="py-6">
      <motion.h3 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-6 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent"
      >
        Loved by Professionals Worldwide
      </motion.h3>
      
      <div className="space-y-4">
        {testimonials.map((testimonial, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.2 }}
          >
            <Card className="glass card-hover">
              <CardContent className="p-4">
                <div className="flex items-start space-x-4">
                  <Avatar className={`bg-gradient-to-br ${testimonial.color}`}>
                    <AvatarFallback className="text-white font-semibold">
                      {testimonial.avatar}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <h4 className="font-semibold">{testimonial.name}</h4>
                        <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      </div>
                      <div className="flex space-x-1">
                        {Array.from({ length: testimonial.rating }).map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    
                    <div className="relative">
                      <Quote className="absolute -top-1 -left-1 w-4 h-4 text-purple-300" />
                      <p className="text-sm italic pl-4">{testimonial.text}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}