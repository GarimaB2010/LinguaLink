import { useState } from "react";
import { Heart, GraduationCap, Scale, ArrowLeft, Users, MessageCircle, Globe, Sparkles, Trophy, Zap, Star, MapPin, Calendar } from "lucide-react";
import { motion } from "motion/react";
import { UseCaseCard } from "./UseCaseCard";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImpactCounter } from "./ImpactCounter";
import { soundEffects } from "./SoundEffects";

interface CommunityPageProps {
  onNavigate?: (page: string) => void;
}

export function CommunityPage({ onNavigate }: CommunityPageProps) {
  const [selectedDemo, setSelectedDemo] = useState<string | null>(null);

  const useCases = [
    {
      id: 'healthcare',
      icon: Heart,
      title: 'Healthcare',
      description: 'Helping doctors and patients communicate across language barriers, ensuring accurate medical information exchange.',
      color: 'bg-red-500',
      stats: { users: '125K', success: '98%' },
      demo: {
        scenario: 'Emergency Room Visit',
        patient: 'No hablo inglés. Me duele mucho el pecho.',
        translation: 'I don\'t speak English. My chest hurts a lot.',
        simplified: 'I don\'t speak English. My chest has bad pain.',
        doctor: 'We need to run some tests to check your heart.',
        response: 'Necesitamos hacer pruebas para revisar tu corazón.'
      }
    },
    {
      id: 'education',
      icon: GraduationCap,
      title: 'Education',
      description: 'Enabling teachers and students to connect regardless of language or literacy levels, making learning accessible to all.',
      color: 'bg-blue-500',
      stats: { users: '89K', success: '96%' },
      demo: {
        scenario: 'Classroom Instruction',
        teacher: 'Today we will analyze the photosynthesis process in plants.',
        simplified: 'Today we will study how plants make food from sunlight.',
        student: 'Teacher, I don\'t understand the big words.',
        response: 'Let me explain it in simpler terms: Plants use sunlight to make their own food.'
      }
    },
    {
      id: 'legal',
      icon: Scale,
      title: 'Legal Aid',
      description: 'Providing access to justice by breaking down language barriers in legal proceedings and documentation.',
      color: 'bg-purple-600',
      stats: { users: '45K', success: '94%' },
      demo: {
        scenario: 'Legal Consultation',
        lawyer: 'The defendant has the right to legal representation and may invoke their Fifth Amendment privileges.',
        simplified: 'The person accused has the right to a lawyer and can choose not to answer questions.',
        client: 'What does that mean for my case?',
        response: 'It means you can have a lawyer help you and you don\'t have to say anything that might hurt your case.'
      }
    }
  ];

  const renderDemo = (useCase: any) => {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="w-full space-y-6"
      >
        <div className="flex items-center justify-between">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button 
              variant="ghost" 
              onClick={() => {
                soundEffects.click();
                setSelectedDemo(null);
              }}
              className="mb-4 bg-white/50 hover:bg-white/80"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Community
            </Button>
          </motion.div>
          <Badge variant="secondary" className="bg-gradient-to-r from-purple-100 to-blue-100">{useCase.scenario}</Badge>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="w-full"
        >
          <Card className="w-full glass border-0 shadow-xl overflow-hidden">
            <CardHeader className={`w-full bg-gradient-to-r ${useCase.color === 'bg-red-500' ? 'from-red-100 to-pink-100' : useCase.color === 'bg-blue-500' ? 'from-blue-100 to-cyan-100' : 'from-purple-100 to-violet-100'}`}>
              <CardTitle className="w-full flex items-center space-x-2">
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <useCase.icon className="w-6 h-6" />
                </motion.div>
                <span>{useCase.title} Demo</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="w-full space-y-4 p-6">
              {/* Original Communication */}
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="w-full p-4 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <h4 className="mb-2 text-sm uppercase tracking-wide text-gray-600 flex items-center space-x-1">
                  <span>💬</span>
                  <span>Original Message</span>
                </h4>
                <p className="mb-3">{useCase.demo.patient || useCase.demo.teacher || useCase.demo.lawyer}</p>
                
                {useCase.demo.translation && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                    className="pt-3 border-t border-gray-200"
                  >
                    <h4 className="mb-2 text-sm uppercase tracking-wide text-blue-600 flex items-center space-x-1">
                      <span>🌐</span>
                      <span>Translation</span>
                    </h4>
                    <p className="text-blue-800">{useCase.demo.translation}</p>
                  </motion.div>
                )}
              </motion.div>

              {/* Simplified Version */}
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="w-full p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border-l-4 border-green-500 shadow-sm hover:shadow-md transition-shadow"
              >
                <h4 className="mb-2 text-sm uppercase tracking-wide text-green-600 flex items-center space-x-1">
                  <span>✨</span>
                  <span>Simplified</span>
                </h4>
                <p className="text-green-800">{useCase.demo.simplified}</p>
              </motion.div>

              {/* Response */}
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="w-full p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <h4 className="mb-2 text-sm uppercase tracking-wide text-blue-600 flex items-center space-x-1">
                  <span>👨‍⚕️</span>
                  <span>Professional Response</span>
                </h4>
                <p className="text-blue-800 mb-3">{useCase.demo.doctor || useCase.demo.response}</p>
                
                {useCase.demo.response && useCase.demo.doctor && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.7 }}
                    className="pt-3 border-t border-blue-200"
                  >
                    <h4 className="mb-2 text-sm uppercase tracking-wide text-blue-600 flex items-center space-x-1">
                      <span>💡</span>
                      <span>Simplified Response</span>
                    </h4>
                    <p className="text-blue-800">{useCase.demo.response}</p>
                  </motion.div>
                )}
              </motion.div>

            {/* Impact Stats */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="w-full grid grid-cols-2 gap-4 pt-4"
            >
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="text-center p-4 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-xl shadow-md hover:shadow-lg transition-shadow"
              >
                <motion.div 
                  className="text-3xl bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-1"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  {useCase.stats.users}
                </motion.div>
                <div className="text-sm text-muted-foreground flex items-center justify-center space-x-1">
                  <span>👥</span>
                  <span>Users Helped</span>
                </div>
              </motion.div>
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="text-center p-4 bg-gradient-to-br from-green-100 to-emerald-100 rounded-xl shadow-md hover:shadow-lg transition-shadow"
              >
                <motion.div 
                  className="text-3xl bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-1"
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
                >
                  {useCase.stats.success}
                </motion.div>
                <div className="text-sm text-muted-foreground flex items-center justify-center space-x-1">
                  <span>✅</span>
                  <span>Success Rate</span>
                </div>
              </motion.div>
            </motion.div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    );
  };

  if (selectedDemo) {
    const useCase = useCases.find(uc => uc.id === selectedDemo);
    return (
      <div className="min-h-screen bg-gray-50 pb-20">
        <div className="max-w-lg mx-auto px-4 pt-6">
          <div className="w-full">
            {useCase && renderDemo(useCase)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 relative">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          animate={{
            x: [0, 150, 0],
            y: [0, -50, 0],
            rotate: [0, 180, 360],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute top-10 right-10 w-24 h-24 bg-gradient-to-r from-pink-400/20 to-purple-400/20 rounded-full blur-xl"
        />
        <motion.div
          animate={{
            x: [0, -100, 0],
            y: [0, 80, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute bottom-20 left-10 w-32 h-32 bg-gradient-to-r from-green-400/20 to-blue-400/20 rounded-full blur-xl"
        />
      </div>

      <div className="max-w-lg mx-auto px-4 pt-6 relative z-10">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 text-center"
        >
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="inline-flex items-center space-x-3 mb-4"
          >
            <Globe className="w-8 h-8 text-purple-500" />
            <h1 className="text-4xl rainbow-text">Community Impact</h1>
            <Heart className="w-8 h-8 text-red-500" />
          </motion.div>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-muted-foreground text-lg"
          >
            Breaking barriers worldwide with innovative technology
          </motion.p>

          {/* Achievement Badges */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="flex justify-center space-x-2 mt-4"
          >
            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
              🏆 Award Winner
            </Badge>
            <Badge className="bg-gradient-to-r from-pink-400 to-purple-500 text-white">
              ✨ AI Innovation
            </Badge>
          </motion.div>
        </motion.div>

        {/* Enhanced Global Stats */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1 }}
          className="mb-6"
        >
          <Card className="glass border-0 shadow-lg">
            <CardContent className="p-6">
              <h3 className="text-center mb-4 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                🚀 Global Impact Today
              </h3>
              <div className="grid grid-cols-3 gap-4 text-center">
                <motion.div 
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="p-3 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-2xl"
                >
                  <motion.div 
                    className="text-3xl mb-2"
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    👥
                  </motion.div>
                  <div className="text-2xl bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-1">
                    <ImpactCounter target={259000} suffix="+" />
                  </div>
                  <div className="text-sm text-muted-foreground">Total Users</div>
                </motion.div>
                
                <motion.div 
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="p-3 bg-gradient-to-br from-green-100 to-emerald-100 rounded-2xl"
                >
                  <motion.div 
                    className="text-3xl mb-2"
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ duration: 3, repeat: Infinity }}
                  >
                    💬
                  </motion.div>
                  <div className="text-2xl bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-1">
                    <ImpactCounter target={1200000} suffix="+" />
                  </div>
                  <div className="text-sm text-muted-foreground">Conversations</div>
                </motion.div>
                
                <motion.div 
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="p-3 bg-gradient-to-br from-purple-100 to-violet-100 rounded-2xl"
                >
                  <motion.div 
                    className="text-3xl mb-2"
                    animate={{ 
                      opacity: [0.7, 1, 0.7],
                      scale: [1, 1.2, 1] 
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    🌍
                  </motion.div>
                  <div className="text-2xl bg-gradient-to-r from-purple-600 to-violet-600 bg-clip-text text-transparent mb-1">
                    <ImpactCounter target={50} suffix="+" />
                  </div>
                  <div className="text-sm text-muted-foreground">Languages</div>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Use Cases */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="space-y-4 mb-6"
        >
          <motion.h2 
            initial={{ x: -20 }}
            animate={{ x: 0 }}
            className="text-xl bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent flex items-center space-x-2"
          >
            <Sparkles className="w-6 h-6 text-purple-500" />
            <span>Real World Impact</span>
          </motion.h2>
          
          {useCases.map((useCase, index) => (
            <motion.div
              key={useCase.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5 + index * 0.2 }}
              whileHover={{ scale: 1.02 }}
            >
              <UseCaseCard
                icon={useCase.icon}
                title={useCase.title}
                description={useCase.description}
                color={useCase.color}
                onClick={() => setSelectedDemo(useCase.id)}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Success Stories */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.3 }}
        >
          <Card className="glass border-0 shadow-lg overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50">
              <CardTitle className="flex items-center space-x-2">
                <motion.span
                  animate={{ rotate: [0, 20, -20, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  ⭐
                </motion.span>
                <span>Recent Success Story</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <div className="space-y-3">
                <motion.div 
                  whileHover={{ scale: 1.02 }}
                  className="flex items-start space-x-3 p-3 bg-white/50 rounded-xl"
                >
                  <motion.div 
                    className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white shadow-lg"
                    animate={{ 
                      boxShadow: [
                        "0 4px 10px rgba(59, 130, 246, 0.3)",
                        "0 6px 20px rgba(139, 92, 246, 0.4)",
                        "0 4px 10px rgba(59, 130, 246, 0.3)"
                      ]
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    M
                  </motion.div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-medium">Maria Rodriguez</span>
                      <Badge variant="outline" className="text-xs bg-red-100 text-red-700 border-red-300">
                        🏥 Healthcare
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      LinguaLink helped me communicate with my doctor during an emergency. The simplified explanations made it easy to understand my treatment.
                    </p>
                    <motion.div 
                      className="flex items-center space-x-3 mt-3 text-xs text-muted-foreground"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.5 }}
                    >
                      <span className="flex items-center space-x-1">
                        <MapPin className="w-3 h-3" />
                        <span>New York, USA</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <Calendar className="w-3 h-3" />
                        <span>2 days ago</span>
                      </span>
                    </motion.div>
                  </div>
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
