import { createContext, useContext, useState, ReactNode } from 'react';

interface NotificationState {
  allPermissionsGranted: boolean;
  cameraGranted: boolean;
  microphoneGranted: boolean;
  partialPermissions: boolean;
  cameraTestSuccess: boolean;
  microphoneTestSuccess: boolean;
  signLanguageCameraGranted: boolean;
  settingsCameraGranted: boolean;
  cameraRetryGranted: boolean;
  anyCameraNotificationShown: boolean; // Master flag for any camera notification
}

interface NotificationContextType {
  shownNotifications: NotificationState;
  markNotificationShown: (key: keyof NotificationState) => void;
  resetNotifications: () => void;
  hasNotificationBeenShown: (key: keyof NotificationState) => boolean;
  canShowCameraNotification: () => boolean;
  markCameraNotificationShown: () => void;
}

const defaultState: NotificationState = {
  allPermissionsGranted: false,
  cameraGranted: false,
  microphoneGranted: false,
  partialPermissions: false,
  cameraTestSuccess: false,
  microphoneTestSuccess: false,
  signLanguageCameraGranted: false,
  settingsCameraGranted: false,
  cameraRetryGranted: false,
  anyCameraNotificationShown: false,
};

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [shownNotifications, setShownNotifications] = useState<NotificationState>(defaultState);

  const markNotificationShown = (key: keyof NotificationState) => {
    setShownNotifications(prev => ({ ...prev, [key]: true }));
  };

  const resetNotifications = () => {
    setShownNotifications(defaultState);
  };

  const hasNotificationBeenShown = (key: keyof NotificationState) => {
    return shownNotifications[key];
  };

  // Central camera notification control
  const canShowCameraNotification = () => {
    return !shownNotifications.anyCameraNotificationShown;
  };

  const markCameraNotificationShown = () => {
    setShownNotifications(prev => ({ 
      ...prev, 
      anyCameraNotificationShown: true,
      cameraGranted: true,
      signLanguageCameraGranted: true,
      settingsCameraGranted: true,
      cameraRetryGranted: true
    }));
  };

  return (
    <NotificationContext.Provider value={{
      shownNotifications,
      markNotificationShown,
      resetNotifications,
      hasNotificationBeenShown,
      canShowCameraNotification,
      markCameraNotificationShown
    }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}