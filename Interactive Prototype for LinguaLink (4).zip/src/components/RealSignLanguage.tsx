import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Camera, CameraOff, Hand, Sparkles, CheckCircle, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { toast } from "sonner@2.0.3";

interface RealSignLanguageProps {
  onGestureDetected: (gesture: string, confidence: number) => void;
  onError: (error: string) => void;
  isActive: boolean;
}

// Mock sign language gestures for demo (in real implementation, you'd use MediaPipe or similar)
const SIGN_GESTURES = [
  { name: 'Hello', description: 'Open hand wave', emoji: '👋' },
  { name: 'Thank you', description: 'Hand to chin then forward', emoji: '🙏' },
  { name: 'Please', description: 'Circular motion on chest', emoji: '🤲' },
  { name: 'Sorry', description: 'Fist circular on chest', emoji: '😔' },
  { name: 'Yes', description: 'Nod fist up and down', emoji: '✅' },
  { name: 'No', description: 'Index and middle finger side to side', emoji: '❌' },
  { name: 'Help', description: 'One hand on other, lift up', emoji: '🆘' },
  { name: 'Water', description: 'W hand to lips', emoji: '💧' },
  { name: 'Food', description: 'Fingers to mouth', emoji: '🍽️' },
  { name: 'More', description: 'Fingertips tap together', emoji: '➕' },
];

export function RealSignLanguage({ onGestureDetected, onError, isActive }: RealSignLanguageProps) {
  const [isDetecting, setIsDetecting] = useState(false);
  const [detectedGesture, setDetectedGesture] = useState<string | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<'granted' | 'denied' | 'prompt' | 'checking'>('checking');
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(true);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const detectionIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Check camera permissions and capabilities
  const checkCameraPermissions = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setIsSupported(false);
        onError('Camera access not supported in this browser. Please use Chrome, Edge, or Safari.');
        return false;
      }

      // Try to check permission status if supported
      try {
        if ('permissions' in navigator && 'query' in navigator.permissions) {
          const permission = await navigator.permissions.query({ name: 'camera' as PermissionName });
          setPermissionStatus(permission.state);

          if (permission.state === 'denied') {
            onError('Camera access denied. Please grant permission in browser settings.');
            return false;
          }
        }
      } catch (permError) {
        // Some browsers don't support permissions.query for camera
        console.log('Permissions API not fully supported, will request directly');
      }

      return true;
    } catch (error) {
      console.warn('Permission check failed, will attempt direct access');
      return true;
    }
  };

  // Initialize camera
  const startCamera = async () => {
    try {
      setCameraError(null);
      setPermissionStatus('checking');

      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setIsSupported(false);
        throw new Error('Camera not supported in this browser');
      }

      const constraints = {
        video: { 
          width: { ideal: 640 }, 
          height: { ideal: 480 },
          facingMode: 'user', // Front camera
          frameRate: { ideal: 30 }
        }
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      
      setStream(mediaStream);
      setPermissionStatus('granted');
      setCameraError(null);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play().catch(err => {
            console.error('Error playing video:', err);
          });
        };
      }
      
      setIsDetecting(true);
      startGestureDetection();
      
      // Show success message
      toast.success('📹 Camera started successfully!', { duration: 3000 });
    } catch (error: any) {
      console.error('Camera access error:', error);
      setPermissionStatus('denied');
      
      let errorMessage = 'Camera access denied';
      if (error.name === 'NotAllowedError') {
        errorMessage = 'Camera permission denied. Please allow camera access and try again.';
      } else if (error.name === 'NotFoundError') {
        errorMessage = 'No camera found. Please connect a camera and try again.';
      } else if (error.name === 'NotReadableError') {
        errorMessage = 'Camera is already in use by another application.';
      }
      
      setCameraError(errorMessage);
      onError(errorMessage);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsDetecting(false);
    setPermissionStatus('checking');
    
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
    }
  };

  // Mock gesture detection (replace with real ML model)
  const startGestureDetection = () => {
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current);
    }

    detectionIntervalRef.current = setInterval(() => {
      // Simulate gesture detection
      if (Math.random() > 0.7) { // 30% chance of detecting a gesture
        const randomGesture = SIGN_GESTURES[Math.floor(Math.random() * SIGN_GESTURES.length)];
        const mockConfidence = 0.7 + Math.random() * 0.3; // 70-100% confidence
        
        setDetectedGesture(randomGesture.name);
        setConfidence(mockConfidence);
        onGestureDetected(randomGesture.name, mockConfidence);
        
        // Clear detection after 2 seconds
        setTimeout(() => {
          setDetectedGesture(null);
          setConfidence(0);
        }, 2000);
      }
    }, 3000); // Check every 3 seconds
  };

  // Auto-start/stop based on isActive prop
  useEffect(() => {
    if (isActive && !isDetecting && permissionStatus !== 'denied') {
      startCamera();
    } else if (!isActive && isDetecting) {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isActive, permissionStatus]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="space-y-4">
      {/* Permission/Error Alert */}
      {cameraError && permissionStatus === 'denied' && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-red-50 border border-red-200 rounded-xl"
        >
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="font-medium text-red-800 mb-1">📹 Camera Access Required</h4>
              <p className="text-sm text-red-600 mb-3">
                Please allow camera access in your browser to use sign language detection.
              </p>
              <div className="text-xs text-red-600 space-y-1 mb-3">
                <p>How to enable:</p>
                <p>1. Click the 🔒 or camera icon in your address bar</p>
                <p>2. Allow camera permissions for this site</p>
                <p>3. Click the retry button below</p>
              </div>
              <Button
                onClick={startCamera}
                variant="outline"
                size="sm"
                className="border-red-300 text-red-700 hover:bg-red-100"
              >
                🔄 Retry Camera Access
              </Button>
            </div>
          </div>
        </motion.div>
      )}
      
      {/* Not Supported Alert */}
      {!isSupported && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-yellow-50 border border-yellow-200 rounded-xl"
        >
          <div className="flex items-start space-x-2">
            <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-medium text-yellow-800 mb-1">⚠️ Browser Not Supported</h4>
              <p className="text-sm text-yellow-600">
                Camera features are not supported in this browser. Please use Chrome, Edge, or Safari.
              </p>
            </div>
          </div>
        </motion.div>
      )}
      
      {/* Camera Feed */}
      <div className="relative">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl overflow-hidden aspect-video"
        >
          {isDetecting ? (
            <>
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                autoPlay
                muted
                playsInline
              />
              <canvas
                ref={canvasRef}
                className="absolute inset-0 w-full h-full"
              />
              
              {/* Detection Overlay */}
              <div className="absolute inset-0 pointer-events-none">
                {/* Corner brackets */}
                <div className="absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-green-400"></div>
                <div className="absolute top-4 right-4 w-8 h-8 border-r-2 border-t-2 border-green-400"></div>
                <div className="absolute bottom-4 left-4 w-8 h-8 border-l-2 border-b-2 border-green-400"></div>
                <div className="absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-green-400"></div>
                
                {/* Status indicator */}
                <div className="absolute top-4 left-1/2 transform -translate-x-1/2">
                  <motion.div
                    animate={{ opacity: [0.5, 1, 0.5] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="bg-green-500 text-white px-3 py-1 rounded-full text-xs flex items-center space-x-1"
                  >
                    <div className="w-2 h-2 bg-white rounded-full"></div>
                    <span>🤖 AI Detecting</span>
                  </motion.div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-white">
              <div className="text-center px-4">
                <motion.div
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  <Camera className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                </motion.div>
                <p className="text-lg font-medium mb-2">📹 Sign Language Detection</p>
                <p className="text-sm text-gray-400 mb-4">Click the camera button below to start</p>
                <div className="text-xs text-gray-500 space-y-1">
                  <p>🤟 Position your hands in view</p>
                  <p>✨ AI will detect and translate signs</p>
                </div>
              </div>
            </div>
          )}
        </motion.div>

        {/* Camera Controls */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
          <motion.button
            onClick={isDetecting ? stopCamera : startCamera}
            whileHover={{ scale: isSupported ? 1.05 : 1 }}
            whileTap={{ scale: isSupported ? 0.95 : 1 }}
            disabled={!isSupported}
            className={`w-12 h-12 rounded-full flex items-center justify-center text-white shadow-lg ${
              !isSupported
                ? 'bg-gray-400 cursor-not-allowed'
                : isDetecting 
                  ? 'bg-gradient-to-r from-red-500 to-pink-500' 
                  : 'bg-gradient-to-r from-blue-500 to-purple-500'
            }`}
          >
            {isDetecting ? <CameraOff className="w-6 h-6" /> : <Camera className="w-6 h-6" />}
          </motion.button>
        </div>
      </div>

      {/* Detection Result */}
      <AnimatePresence>
        {detectedGesture && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="relative"
          >
            <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="font-medium text-green-800">Gesture Detected!</span>
                  </div>
                  <Badge variant="secondary" className="bg-green-100 text-green-800">
                    {Math.round(confidence * 100)}% confident
                  </Badge>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="text-4xl">
                    {SIGN_GESTURES.find(g => g.name === detectedGesture)?.emoji}
                  </div>
                  <div>
                    <h3 className="font-semibold text-green-800">{detectedGesture}</h3>
                    <p className="text-sm text-green-600">
                      {SIGN_GESTURES.find(g => g.name === detectedGesture)?.description}
                    </p>
                  </div>
                </div>
                
                {/* Confidence Bar */}
                <div className="mt-3">
                  <div className="w-full bg-green-200 rounded-full h-2">
                    <motion.div
                      className="bg-gradient-to-r from-green-400 to-emerald-500 h-2 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${confidence * 100}%` }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Gesture Guide */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
        <CardContent className="p-4">
          <h4 className="font-medium text-blue-800 mb-3 flex items-center space-x-2">
            <Hand className="w-5 h-5" />
            <span>🤟 Supported Gestures</span>
          </h4>
          
          <div className="grid grid-cols-2 gap-2">
            {SIGN_GESTURES.slice(0, 6).map((gesture, index) => (
              <motion.div
                key={gesture.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center space-x-2 p-2 bg-white/60 rounded-lg"
              >
                <span className="text-lg">{gesture.emoji}</span>
                <div>
                  <div className="text-xs font-medium text-blue-800">{gesture.name}</div>
                  <div className="text-xs text-blue-600">{gesture.description}</div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-3 text-center">
            <Badge variant="outline" className="text-xs text-blue-600">
              ✨ More gestures coming soon!
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      {!isDetecting && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200"
        >
          <Sparkles className="w-8 h-8 mx-auto mb-2 text-purple-500" />
          <h4 className="font-medium text-purple-800 mb-2">How to Use Sign Language Detection</h4>
          <div className="text-sm text-purple-600 space-y-1">
            <p>1. 📹 Tap the camera button to start</p>
            <p>2. 🤟 Position your hands in view</p>
            <p>3. ✨ Make gestures from the supported list</p>
            <p>4. 🎯 AI will detect and translate your signs</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}