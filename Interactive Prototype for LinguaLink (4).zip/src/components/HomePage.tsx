import { useState, useEffect } from "react";
import { Mic, Keyboard, Hand, BookOpen, Sparkles, Globe, Heart } from "lucide-react";
import { motion } from "motion/react";
import { Card, CardContent } from "./ui/card";
import { FeatureCard } from "./FeatureCard";
import { Testimonials } from "./Testimonials";
import { ImpactCounter } from "./ImpactCounter";
import { WelcomeGuide } from "./WelcomeGuide";
import { DemoMode } from "./DemoMode";
import { FeatureHealthCheck } from "./FeatureHealthCheck";
import { QuickMediaTest } from "./QuickMediaTest";
import { RevolutionaryShowcase } from "./RevolutionaryShowcase";

interface HomePageProps {
  onNavigate: (page: string, mode?: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const [showGuide, setShowGuide] = useState(false);
  const [showDemo, setShowDemo] = useState(false);
  const [systemHealthy, setSystemHealthy] = useState(true);

  useEffect(() => {
    // Check if it's the user's first visit
    const hasSeenGuide = localStorage.getItem('lingualink_guide_seen');
    if (!hasSeenGuide) {
      setTimeout(() => setShowGuide(true), 1000);
    }
  }, []);

  const handleGuideComplete = () => {
    setShowGuide(false);
    localStorage.setItem('lingualink_guide_seen', 'true');
  };

  const handleDemoComplete = (scenario: string) => {
    setShowDemo(false);
    // Could track demo completion analytics here
    console.log(`Demo completed: ${scenario}`);
  };
  const features = [
    {
      icon: Mic,
      title: "Speak",
      description: "Voice to text with real-time translation",
      color: "bg-gradient-to-br from-blue-500 to-blue-700",
      action: () => onNavigate('conversation', 'speak')
    },
    {
      icon: Keyboard,
      title: "Type",
      description: "Text input with smart simplification",
      color: "bg-gradient-to-br from-green-500 to-emerald-600",
      action: () => onNavigate('conversation', 'type')
    },
    {
      icon: Hand,
      title: "Sign",
      description: "Sign language interpretation",
      color: "bg-gradient-to-br from-orange-500 to-red-500",
      action: () => onNavigate('conversation', 'sign')
    },
    {
      icon: BookOpen,
      title: "Simplify",
      description: "Complex text made easy to understand",
      color: "bg-gradient-to-br from-purple-500 to-indigo-600",
      action: () => onNavigate('conversation', 'simplify')
    }
  ];

  return (
    <div className="min-h-screen pb-20 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{
            x: [0, 100, 0],
            y: [0, -100, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-purple-400/20 to-pink-400/20 rounded-full blur-xl"
        />
        <motion.div
          animate={{
            x: [0, -150, 0],
            y: [0, 100, 0],
          }}
          transition={{
            duration: 25,
            repeat: Infinity,
            ease: "linear"
          }}
          className="absolute bottom-32 right-10 w-40 h-40 bg-gradient-to-r from-blue-400/20 to-green-400/20 rounded-full blur-xl"
        />
      </div>

      <div className="max-w-lg mx-auto px-6 pt-12 relative z-10">
        {/* Header with animation */}
        <motion.div 
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <motion.div
            initial={{ scale: 0.8 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="inline-flex items-center space-x-2 mb-4"
          >
            <Sparkles className="w-8 h-8 text-purple-500" />
            <h1 className="text-4xl bg-gradient-to-r from-purple-600 via-blue-600 to-green-600 bg-clip-text text-transparent">
              LinguaLink
            </h1>
            <Sparkles className="w-8 h-8 text-blue-500" />
          </motion.div>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-muted-foreground text-lg"
          >
            Breaking Barriers, Connecting Voices
          </motion.p>
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 }}
            className="flex items-center justify-center space-x-4 mt-4"
          >
            <Globe className="w-5 h-5 text-blue-500" />
            <Heart className="w-5 h-5 text-red-500" />
            <Sparkles className="w-5 h-5 text-purple-500" />
          </motion.div>
        </motion.div>

        {/* System Health Check */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
        >
          <FeatureHealthCheck onHealthChange={setSystemHealthy} />
        </motion.div>

        {/* Demo Mode Button */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.1 }}
          className="text-center mb-6"
        >
          <button
            onClick={() => setShowDemo(true)}
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
          >
            <Sparkles className="w-5 h-5" />
            <span className="font-medium">Watch Live Demo</span>
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              🎭
            </motion.div>
          </button>
        </motion.div>

        {/* Feature Cards with staggered animation */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="grid grid-cols-2 gap-4 mb-8"
        >
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.2 + index * 0.2 }}
            >
              <FeatureCard
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                color={feature.color}
                onClick={feature.action}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Quick Media Test */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.8 }}
          className="mb-6"
        >
          <QuickMediaTest />
        </motion.div>

        {/* Revolutionary Features Preview */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.6 }}
          className="mb-6"
        >
          <Card className="bg-gradient-to-r from-purple-900/90 to-blue-900/90 text-white border-purple-500/50 shadow-2xl backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="text-center mb-4">
                <motion.div
                  animate={{ 
                    scale: [1, 1.05, 1],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ 
                    duration: 4, 
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="text-6xl mb-2"
                >
                  🚀
                </motion.div>
                <h3 className="text-xl font-bold bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
                  Revolutionary AI Features
                </h3>
                <p className="text-sm text-purple-200">
                  Never-before-seen technology that will blow your mind!
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-3 text-center">
                <motion.div 
                  whileHover={{ scale: 1.05, y: -2 }}
                  className="p-3 bg-white/10 rounded-lg border border-white/20"
                >
                  <div className="text-2xl mb-1">🧠</div>
                  <div className="text-xs font-medium text-purple-200">Quantum Translation</div>
                </motion.div>
                <motion.div 
                  whileHover={{ scale: 1.05, y: -2 }}
                  className="p-3 bg-white/10 rounded-lg border border-white/20"
                >
                  <div className="text-2xl mb-1">💖</div>
                  <div className="text-xs font-medium text-pink-200">Neural Empathy</div>
                </motion.div>
                <motion.div 
                  whileHover={{ scale: 1.05, y: -2 }}
                  className="p-3 bg-white/10 rounded-lg border border-white/20"
                >
                  <div className="text-2xl mb-1">✨</div>
                  <div className="text-xs font-medium text-blue-200">Holographic UI</div>
                </motion.div>
                <motion.div 
                  whileHover={{ scale: 1.05, y: -2 }}
                  className="p-3 bg-white/10 rounded-lg border border-white/20"
                >
                  <div className="text-2xl mb-1">🧬</div>
                  <div className="text-xs font-medium text-green-200">Bio-Rhythmic Sync</div>
                </motion.div>
              </div>
              
              <motion.div 
                animate={{ opacity: [0.7, 1, 0.7] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-center mt-4"
              >
                <p className="text-xs text-yellow-300">
                  🌟 Exclusive to LinguaLink • Experience the future today! 🌟
                </p>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Enhanced Quick Stats */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2 }}
          className="p-6 bg-white/80 backdrop-blur-sm rounded-3xl shadow-lg border border-white/20 mb-8"
        >
          <h3 className="text-center mb-6 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Real Impact Today
          </h3>
          <div className="grid grid-cols-3 gap-4 text-center">
            <motion.div
              whileHover={{ scale: 1.05, y: -5 }}
              className="p-3 rounded-2xl bg-gradient-to-br from-blue-50 to-blue-100 shadow-sm"
            >
              <motion.div 
                className="text-3xl mb-2"
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                💬
              </motion.div>
              <div className="text-2xl bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent mb-1">
                <ImpactCounter target={1200000} suffix="+" />
              </div>
              <div className="text-sm text-muted-foreground">Conversations</div>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05, y: -5 }}
              className="p-3 rounded-2xl bg-gradient-to-br from-green-50 to-green-100 shadow-sm"
            >
              <motion.div 
                className="text-3xl mb-2"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                🌍
              </motion.div>
              <div className="text-2xl bg-gradient-to-r from-green-600 to-green-800 bg-clip-text text-transparent mb-1">
                <ImpactCounter target={50} suffix="+" />
              </div>
              <div className="text-sm text-muted-foreground">Languages</div>
            </motion.div>
            <motion.div
              whileHover={{ scale: 1.05, y: -5 }}
              className="p-3 rounded-2xl bg-gradient-to-br from-purple-50 to-purple-100 shadow-sm"
            >
              <motion.div 
                className="text-3xl mb-2"
                animate={{ 
                  opacity: [0.7, 1, 0.7],
                  scale: [1, 1.2, 1] 
                }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                ⚡
              </motion.div>
              <div className="text-2xl bg-gradient-to-r from-purple-600 to-purple-800 bg-clip-text text-transparent mb-1">
                <ImpactCounter target={99.2} suffix="%" decimals={1} />
              </div>
              <div className="text-sm text-muted-foreground">Accuracy</div>
            </motion.div>
          </div>
        </motion.div>

        {/* Testimonials */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.5 }}
        >
          <Testimonials />
        </motion.div>
      </div>

      {/* Welcome Guide */}
      {showGuide && (
        <WelcomeGuide onComplete={handleGuideComplete} />
      )}

      {/* Demo Mode */}
      {showDemo && (
        <DemoMode
          isActive={showDemo}
          onComplete={handleDemoComplete}
          onClose={() => setShowDemo(false)}
        />
      )}
    </div>
  );
}