import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HelpCircle, X } from "lucide-react";
import { Button } from "./ui/button";

interface HelpTooltipProps {
  content: string;
  title?: string;
  position?: 'top' | 'bottom' | 'left' | 'right';
  className?: string;
}

export function HelpTooltip({ content, title, position = 'top', className = '' }: HelpTooltipProps) {
  const [isVisible, setIsVisible] = useState(false);

  const positionClasses = {
    top: 'bottom-full left-1/2 transform -translate-x-1/2 mb-2',
    bottom: 'top-full left-1/2 transform -translate-x-1/2 mt-2',
    left: 'right-full top-1/2 transform -translate-y-1/2 mr-2',
    right: 'left-full top-1/2 transform -translate-y-1/2 ml-2'
  };

  return (
    <div className={`relative inline-block ${className}`}>
      <button
        onClick={() => setIsVisible(!isVisible)}
        className="p-1 text-muted-foreground hover:text-primary transition-colors"
        aria-label="Show help"
      >
        <HelpCircle className="w-4 h-4" />
      </button>

      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.2 }}
            className={`absolute ${positionClasses[position]} z-50 w-64 p-3 bg-white rounded-lg shadow-lg border border-gray-200`}
          >
            <div className="flex items-start justify-between mb-2">
              {title && (
                <h4 className="text-sm font-medium text-gray-900">{title}</h4>
              )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsVisible(false)}
                className="w-4 h-4 p-0 text-gray-400 hover:text-gray-600"
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
            
            <p className="text-sm text-gray-600 leading-relaxed">{content}</p>
            
            {/* Arrow */}
            <div 
              className={`absolute w-2 h-2 bg-white border transform rotate-45 ${
                position === 'top' ? 'top-full left-1/2 -translate-x-1/2 -translate-y-1/2 border-b-0 border-r-0' :
                position === 'bottom' ? 'bottom-full left-1/2 -translate-x-1/2 translate-y-1/2 border-t-0 border-l-0' :
                position === 'left' ? 'left-full top-1/2 -translate-x-1/2 -translate-y-1/2 border-t-0 border-r-0' :
                'right-full top-1/2 translate-x-1/2 -translate-y-1/2 border-b-0 border-l-0'
              }`}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}