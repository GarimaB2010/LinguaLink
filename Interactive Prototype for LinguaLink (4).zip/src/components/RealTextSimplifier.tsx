import { useState } from "react";
import { motion } from "motion/react";
import { Sparkles, BookOpen, Brain, Lightbulb, Copy } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Slider } from "./ui/slider";

interface RealTextSimplifierProps {
  originalText: string;
  onSimplified: (simplified: string, level: string) => void;
  onError: (error: string) => void;
}

// Simplification rules and patterns
const SIMPLIFICATION_RULES = {
  'beginner': {
    name: 'Beginner Friendly',
    description: 'Very simple words and short sentences',
    emoji: '🌱',
    color: 'from-green-400 to-emerald-500'
  },
  'intermediate': {
    name: 'Intermediate',
    description: 'Moderate complexity with clear structure',
    emoji: '🌿',
    color: 'from-blue-400 to-cyan-500'
  },
  'advanced': {
    name: 'Advanced',
    description: 'Sophisticated but clear language',
    emoji: '🌳',
    color: 'from-purple-400 to-violet-500'
  }
};

// Complex to simple word mappings
const WORD_SIMPLIFICATIONS: Record<string, string> = {
  'utilize': 'use',
  'facilitate': 'help',
  'demonstrate': 'show',
  'accomplish': 'do',
  'commence': 'start',
  'terminate': 'end',
  'acquire': 'get',
  'endeavor': 'try',
  'sufficient': 'enough',
  'approximately': 'about',
  'numerous': 'many',
  'substantial': 'large',
  'inadequate': 'not enough',
  'subsequent': 'next',
  'prior': 'before',
  'fundamental': 'basic',
  'comprehend': 'understand',
  'assistance': 'help',
  'requirements': 'needs',
  'alternative': 'other option',
  'consequently': 'so',
  'furthermore': 'also',
  'nevertheless': 'but',
  'therefore': 'so',
  'however': 'but',
  'additionally': 'also',
  'establishment': 'place',
  'individual': 'person',
  'modification': 'change',
  'implementation': 'putting in place',
  'documentation': 'papers',
  'certification': 'certificate',
  'authorization': 'permission',
  'recommendation': 'advice',
  'examination': 'check',
  'consideration': 'thinking about',
  'communication': 'talking',
  'transportation': 'travel',
  'accommodation': 'place to stay',
  'information': 'facts',
  'explanation': 'answer',
  'description': 'details',
  'instruction': 'directions',
  'notification': 'message',
  'investigation': 'looking into',
  'preparation': 'getting ready',
  'organization': 'group',
  'administration': 'management',
  'consultation': 'meeting',
  'registration': 'signing up',
  'application': 'request',
  'reservation': 'booking',
  'prescription': 'medicine order',
  'medication': 'medicine',
  'diagnosis': 'what is wrong',
  'treatment': 'care',
  'procedure': 'steps',
  'appointment': 'meeting',
  'insurance': 'protection plan',
  'emergency': 'urgent help needed',
  'symptoms': 'signs of illness',
  'allergies': 'bad reactions to',
  'vaccination': 'shot to prevent illness'
};

export function RealTextSimplifier({ originalText, onSimplified, onError }: RealTextSimplifierProps) {
  const [simplificationLevel, setSimplificationLevel] = useState(1); // 0=beginner, 1=intermediate, 2=advanced
  const [isSimplifying, setIsSimplifying] = useState(false);
  const [simplifiedResults, setSimplifiedResults] = useState<any[]>([]);

  const simplifyText = async (text: string, level: number) => {
    if (!text.trim()) {
      onError('No text to simplify');
      return;
    }

    setIsSimplifying(true);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1500));

      const levels = ['beginner', 'intermediate', 'advanced'];
      const currentLevel = levels[level];
      
      let simplified = text;

      // Step 1: Replace complex words
      Object.entries(WORD_SIMPLIFICATIONS).forEach(([complex, simple]) => {
        const regex = new RegExp(`\\b${complex}\\b`, 'gi');
        simplified = simplified.replace(regex, simple);
      });

      // Step 2: Break down long sentences
      if (level === 0) { // Beginner
        simplified = simplified
          .split(/[.!?]+/)
          .map(sentence => {
            if (sentence.length > 50) {
              // Break at conjunctions
              return sentence
                .replace(/,\s*(and|but|or|so)\s*/g, '. $1 ')
                .replace(/\s*(because|since|although|while)\s*/g, '. This is because ');
            }
            return sentence;
          })
          .join('. ')
          .replace(/\.\s*\./g, '.');
      }

      // Step 3: Add helpful explanations for beginners
      if (level === 0) {
        simplified = simplified
          .replace(/\bmedicine\b/gi, 'medicine (drugs that help you feel better)')
          .replace(/\bdoctor\b/gi, 'doctor (person who helps sick people)')
          .replace(/\bappointment\b/gi, 'appointment (meeting with doctor)')
          .replace(/\binsurance\b/gi, 'insurance (money help for medical care)');
      }

      // Step 4: Simplify sentence structure
      simplified = simplified
        .replace(/In order to/gi, 'To')
        .replace(/It is important that you/gi, 'You should')
        .replace(/Please be advised that/gi, 'Please know that')
        .replace(/We would like to inform you that/gi, 'We want to tell you that')
        .replace(/Due to the fact that/gi, 'Because')
        .replace(/At this point in time/gi, 'Now')
        .replace(/In the event that/gi, 'If');

      // Step 5: Level-specific adjustments
      if (level === 0) { // Beginner - very simple
        simplified = simplified
          .replace(/\bmust\b/gi, 'need to')
          .replace(/\bshall\b/gi, 'will')
          .replace(/\bought to\b/gi, 'should')
          .replace(/\bmay\b/gi, 'can')
          .replace(/\bmight\b/gi, 'could');
      }

      // Clean up
      simplified = simplified
        .replace(/\s+/g, ' ')
        .replace(/\.\s*,/g, '.')
        .replace(/[.]{2,}/g, '.')
        .trim();

      const result = {
        level: currentLevel,
        text: simplified,
        wordsChanged: countWordChanges(text, simplified),
        readabilityScore: calculateReadabilityScore(simplified),
        timestamp: new Date()
      };

      setSimplifiedResults(prev => [result, ...prev.slice(0, 2)]);
      onSimplified(simplified, currentLevel);

    } catch (error) {
      onError('Failed to simplify text. Please try again.');
    } finally {
      setIsSimplifying(false);
    }
  };

  const countWordChanges = (original: string, simplified: string): number => {
    const originalWords = original.toLowerCase().split(/\s+/);
    const simplifiedWords = simplified.toLowerCase().split(/\s+/);
    let changes = 0;
    
    originalWords.forEach(word => {
      if (!simplifiedWords.includes(word)) {
        changes++;
      }
    });
    
    return changes;
  };

  const calculateReadabilityScore = (text: string): number => {
    // Simple readability score based on sentence and word length
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    const words = text.split(/\s+/);
    const avgWordsPerSentence = words.length / sentences.length;
    const avgCharsPerWord = text.replace(/\s+/g, '').length / words.length;
    
    // Lower score = easier to read
    const score = Math.max(0, Math.min(100, 100 - (avgWordsPerSentence * 2 + avgCharsPerWord * 5)));
    return Math.round(score);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const levelNames = ['beginner', 'intermediate', 'advanced'];
  const currentLevelKey = levelNames[simplificationLevel];
  const currentLevel = SIMPLIFICATION_RULES[currentLevelKey];

  return (
    <div className="space-y-4">
      {/* Level Selection */}
      <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
        <CardContent className="p-4">
          <div className="flex items-center space-x-2 mb-3">
            <Brain className="w-5 h-5 text-indigo-600" />
            <h4 className="font-medium text-indigo-800">🎯 Simplification Level</h4>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-indigo-600">Simple</span>
              <span className="text-sm text-indigo-600">Complex</span>
            </div>
            
            <Slider
              value={[simplificationLevel]}
              onValueChange={([value]) => setSimplificationLevel(value)}
              min={0}
              max={2}
              step={1}
              className="w-full"
            />
            
            <div className="text-center">
              <Badge className={`bg-gradient-to-r ${currentLevel.color} text-white`}>
                {currentLevel.emoji} {currentLevel.name}
              </Badge>
              <p className="text-xs text-indigo-600 mt-1">{currentLevel.description}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Simplify Button */}
      <div className="text-center">
        <motion.button
          onClick={() => simplifyText(originalText, simplificationLevel)}
          disabled={!originalText.trim() || isSimplifying}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className={`px-8 py-3 rounded-full text-white font-medium shadow-lg transition-all ${
            !originalText.trim() || isSimplifying
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-violet-500 to-purple-600 hover:from-violet-600 hover:to-purple-700'
          }`}
        >
          {isSimplifying ? (
            <div className="flex items-center space-x-2">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="w-5 h-5" />
              </motion.div>
              <span>🧠 Simplifying...</span>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <Lightbulb className="w-5 h-5" />
              <span>✨ Simplify Text</span>
            </div>
          )}
        </motion.button>
      </div>

      {/* Results */}
      {simplifiedResults.map((result, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className={`bg-gradient-to-r ${SIMPLIFICATION_RULES[result.level].color}/10 border-${SIMPLIFICATION_RULES[result.level].color.split('-')[1]}-200`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Badge className={`bg-gradient-to-r ${SIMPLIFICATION_RULES[result.level].color} text-white`}>
                    {SIMPLIFICATION_RULES[result.level].emoji} {SIMPLIFICATION_RULES[result.level].name}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {result.wordsChanged} words simplified
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(result.text)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="space-y-3">
                <p className="text-sm leading-relaxed">{result.text}</p>
                
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <BookOpen className="w-3 h-3" />
                      <span>Readability: {result.readabilityScore}/100</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Sparkles className="w-3 h-3" />
                      <span>{result.text.split(' ').length} words</span>
                    </div>
                  </div>
                  <div>
                    {result.timestamp.toLocaleTimeString()}
                  </div>
                </div>
                
                {/* Readability bar */}
                <div className="w-full bg-gray-200 rounded-full h-1">
                  <motion.div
                    className={`bg-gradient-to-r ${SIMPLIFICATION_RULES[result.level].color} h-1 rounded-full`}
                    initial={{ width: 0 }}
                    animate={{ width: `${result.readabilityScore}%` }}
                    transition={{ duration: 0.8 }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}

      {/* Tips */}
      {!isSimplifying && simplifiedResults.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border border-yellow-200"
        >
          <Lightbulb className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
          <h4 className="font-medium text-yellow-800 mb-2">💡 Smart Text Simplification</h4>
          <div className="text-sm text-yellow-700 space-y-1">
            <p>• 🧠 AI-powered language simplification</p>
            <p>• 📚 Adapts to reading level needs</p>
            <p>• 🎯 Perfect for medical, legal, and academic texts</p>
            <p>• 🔄 Maintains original meaning while improving clarity</p>
          </div>
        </motion.div>
      )}
    </div>
  );
}