import { motion } from 'motion/react';
import { Brain, Heart, Eye, Activity, Globe, Zap, Sparkles, Rocket } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface RevolutionaryFeaturesPanelProps {
  onFeatureActivate: (feature: string) => void;
}

export function RevolutionaryFeaturesPanel({ onFeatureActivate }: RevolutionaryFeaturesPanelProps) {
  const features = [
    {
      id: 'quantum',
      name: 'Quantum Translation',
      description: 'Multi-dimensional linguistic processing',
      icon: Brain,
      color: 'from-purple-500 to-indigo-600',
      status: 'Ready',
      badge: '🌟 NEW'
    },
    {
      id: 'empathy',
      name: 'Neural Empathy',
      description: 'Real-time emotional synchronization',
      icon: Heart,
      color: 'from-rose-500 to-pink-600',
      status: 'Ready',
      badge: '💖 HOT'
    },
    {
      id: 'holographic',
      name: 'Holographic UI',
      description: '3D spatial gesture interface',
      icon: Eye,
      color: 'from-blue-500 to-cyan-600',
      status: 'Ready',
      badge: '✨ EXCLUSIVE'
    },
    {
      id: 'bio',
      name: 'Bio-Rhythmic Sync',
      description: 'Biological pattern optimization',
      icon: Activity,
      color: 'from-green-500 to-emerald-600',
      status: 'Ready',
      badge: '🧬 UNIQUE'
    },
    {
      id: 'cultural',
      name: 'Cultural Bridge',
      description: 'Cross-cultural communication',
      icon: Globe,
      color: 'from-orange-500 to-red-600',
      status: 'Ready',
      badge: '🌍 GLOBAL'
    },
    {
      id: 'synaptic',
      name: 'Synaptic Learning',
      description: 'Adaptive AI evolution',
      icon: Zap,
      color: 'from-violet-500 to-purple-600',
      status: 'Ready',
      badge: '⚡ SMART'
    }
  ];

  return (
    <Card className="glass border-0 shadow-lg bg-gradient-to-r from-purple-50/80 to-blue-50/80 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-30">
        {[...Array(10)].map((_, i) => (
          <motion.div
            key={i}
            animate={{
              x: [0, 50, 0],
              y: [0, -30, 0],
              opacity: [0.1, 0.3, 0.1]
            }}
            transition={{
              duration: 8 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 2
            }}
            className="absolute w-1 h-1 bg-purple-400 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
          />
        ))}
      </div>

      <CardHeader className="relative z-10">
        <CardTitle className="text-lg flex items-center space-x-2">
          <motion.div
            animate={{ 
              rotate: [0, 360],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Rocket className="w-5 h-5 text-purple-500" />
          </motion.div>
          <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Revolutionary AI Features
          </span>
          <motion.div
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.7, 1, 0.7]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity
            }}
          >
            <Sparkles className="w-5 h-5 text-yellow-500" />
          </motion.div>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Experience next-generation communication technology that exists nowhere else on Earth
        </p>
      </CardHeader>

      <CardContent className="relative z-10">
        <div className="grid grid-cols-2 gap-3 mb-4">
          {features.map((feature, index) => {
            const FeatureIcon = feature.icon;
            return (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  onClick={() => onFeatureActivate(feature.id)}
                  className={`w-full h-20 bg-gradient-to-r ${feature.color} hover:shadow-lg text-white shadow-md relative overflow-hidden group`}
                >
                  {/* Animated shine effect */}
                  <motion.div
                    animate={{
                      x: [-100, 100],
                      opacity: [0, 0.5, 0]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      delay: index * 0.3
                    }}
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent transform -skew-x-12"
                  />
                  
                  <div className="text-center relative z-10">
                    <div className="flex items-center justify-center mb-1">
                      <FeatureIcon className="w-5 h-5 mr-1" />
                      <Badge 
                        variant="secondary" 
                        className="text-xs bg-white/20 text-white border-white/30 ml-1"
                      >
                        {feature.badge}
                      </Badge>
                    </div>
                    <div className="text-xs font-bold">{feature.name}</div>
                    <div className="text-xs opacity-90">{feature.description}</div>
                  </div>
                </Button>
              </motion.div>
            );
          })}
        </div>
        
        <motion.div 
          animate={{ 
            opacity: [0.6, 1, 0.6],
            scale: [1, 1.02, 1]
          }}
          transition={{ 
            duration: 3, 
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="text-center p-4 bg-gradient-to-r from-yellow-100/50 to-orange-100/50 rounded-lg border border-yellow-300/30"
        >
          <div className="text-2xl mb-2">🏆</div>
          <p className="text-sm font-medium text-orange-700">
            World's First Revolutionary Communication Platform
          </p>
          <p className="text-xs text-orange-600 mt-1">
            These features exist nowhere else and will change how humans communicate forever
          </p>
        </motion.div>
      </CardContent>
    </Card>
  );
}