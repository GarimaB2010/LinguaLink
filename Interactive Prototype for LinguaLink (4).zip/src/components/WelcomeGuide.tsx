import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ArrowRight, Sparkles } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";

interface WelcomeGuideProps {
  onComplete: () => void;
}

const GUIDE_STEPS = [
  {
    title: "Welcome to LinguaLink! 🌍",
    description: "Your universal communication companion that breaks down language, literacy, and accessibility barriers.",
    emoji: "👋",
    tip: "Let's take a quick tour of your new superpower!"
  },
  {
    title: "Speak & Be Heard 🎤",
    description: "Use real speech recognition to convert your voice into text, then translate or simplify it instantly.",
    emoji: "🗣️",
    tip: "Perfect for doctor visits, meetings, or talking with friends from other countries!"
  },
  {
    title: "Type with Confidence ⌨️",
    description: "Type in any complexity level and get instant simplification to make communication crystal clear.",
    emoji: "📝",
    tip: "Turn complex legal documents into simple language everyone can understand!"
  },
  {
    title: "Sign Language Magic 🤟",
    description: "Our AI recognizes sign language gestures and converts them to text for seamless communication.",
    emoji: "✋",
    tip: "Bridge the gap between hearing and deaf communities with cutting-edge technology!"
  },
  {
    title: "Community Power 💫",
    description: "Join thousands of users making real impact in healthcare, education, and legal settings worldwide.",
    emoji: "🌟",
    tip: "Your voice matters! See how others are changing lives with LinguaLink."
  }
];

export function WelcomeGuide({ onComplete }: WelcomeGuideProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const handleNext = () => {
    if (currentStep < GUIDE_STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handleComplete = () => {
    setIsVisible(false);
    setTimeout(onComplete, 300);
  };

  const currentGuide = GUIDE_STEPS[currentStep];

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", duration: 0.5 }}
          >
            <Card className="w-full max-w-md bg-gradient-to-br from-white to-purple-50 border-2 border-purple-200 shadow-2xl">
              <CardContent className="p-6">
                {/* Header */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="w-5 h-5 text-purple-500" />
                    <span className="text-sm text-purple-600 font-medium">
                      Step {currentStep + 1} of {GUIDE_STEPS.length}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleComplete}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                {/* Progress Bar */}
                <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
                  <motion.div
                    className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentStep + 1) / GUIDE_STEPS.length) * 100}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>

                {/* Content */}
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="text-center"
                >
                  <motion.div
                    animate={{ 
                      scale: [1, 1.1, 1],
                      rotate: [0, 5, -5, 0] 
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut" 
                    }}
                    className="text-6xl mb-4"
                  >
                    {currentGuide.emoji}
                  </motion.div>

                  <h3 className="text-xl font-semibold mb-3 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                    {currentGuide.title}
                  </h3>

                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {currentGuide.description}
                  </p>

                  <div className="p-3 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-lg border border-yellow-200 mb-6">
                    <p className="text-sm text-yellow-700">
                      💡 <strong>Pro Tip:</strong> {currentGuide.tip}
                    </p>
                  </div>
                </motion.div>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <div className="flex space-x-1">
                    {GUIDE_STEPS.map((_, index) => (
                      <motion.div
                        key={index}
                        className={`w-2 h-2 rounded-full ${
                          index === currentStep ? 'bg-purple-500' : 'bg-gray-300'
                        }`}
                        animate={index === currentStep ? { scale: [1, 1.2, 1] } : {}}
                        transition={{ duration: 1, repeat: Infinity }}
                      />
                    ))}
                  </div>

                  <div className="flex space-x-2">
                    {currentStep > 0 && (
                      <Button
                        variant="outline"
                        onClick={() => setCurrentStep(currentStep - 1)}
                        className="text-gray-600"
                      >
                        Back
                      </Button>
                    )}
                    
                    <Button
                      onClick={handleNext}
                      className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 text-white"
                    >
                      {currentStep === GUIDE_STEPS.length - 1 ? (
                        <>
                          <Sparkles className="w-4 h-4 mr-2" />
                          Let's Go!
                        </>
                      ) : (
                        <>
                          Next
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}