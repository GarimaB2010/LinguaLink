import { motion } from "motion/react";
import { useEffect, useState } from "react";

interface InteractiveWaveformProps {
  isActive: boolean;
  className?: string;
}

export function InteractiveWaveform({ isActive, className = "" }: InteractiveWaveformProps) {
  const [bars] = useState(Array.from({ length: 20 }, (_, i) => i));

  return (
    <div className={`flex items-center justify-center space-x-1 ${className}`}>
      {bars.map((bar) => (
        <motion.div
          key={bar}
          className="bg-gradient-to-t from-blue-500 to-purple-500 rounded-full w-1"
          animate={isActive ? {
            height: [4, Math.random() * 40 + 10, 4],
            opacity: [0.4, 1, 0.4],
          } : {
            height: 4,
            opacity: 0.3,
          }}
          transition={{
            duration: 0.8,
            repeat: isActive ? Infinity : 0,
            delay: bar * 0.1,
            ease: "easeInOut",
          }}
          style={{ height: 4 }}
        />
      ))}
    </div>
  );
}