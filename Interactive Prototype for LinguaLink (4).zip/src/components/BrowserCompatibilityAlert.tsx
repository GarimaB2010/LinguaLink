import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, Chrome, X, Info } from 'lucide-react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';

interface BrowserInfo {
  name: string;
  isSupported: boolean;
  missingFeatures: string[];
}

export function BrowserCompatibilityAlert() {
  const [browserInfo, setBrowserInfo] = useState<BrowserInfo | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    checkBrowserCompatibility();
  }, []);

  // Auto-dismiss after 10 seconds
  useEffect(() => {
    if (isVisible && !isDismissed) {
      const timer = setTimeout(() => {
        handleDismiss();
      }, 10000);

      return () => clearTimeout(timer);
    }
  }, [isVisible, isDismissed]);

  const checkBrowserCompatibility = () => {
    const missingFeatures: string[] = [];
    
    // Check Speech Recognition
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      missingFeatures.push('Speech Recognition');
    }
    
    // Check Speech Synthesis
    if (!('speechSynthesis' in window)) {
      missingFeatures.push('Text-to-Speech');
    }
    
    // Check Media Devices
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      missingFeatures.push('Camera/Microphone Access');
    }

    // Detect browser
    const userAgent = navigator.userAgent.toLowerCase();
    let browserName = 'Unknown';
    
    if (userAgent.includes('chrome') && !userAgent.includes('edg')) {
      browserName = 'Chrome';
    } else if (userAgent.includes('safari') && !userAgent.includes('chrome')) {
      browserName = 'Safari';
    } else if (userAgent.includes('firefox')) {
      browserName = 'Firefox';
    } else if (userAgent.includes('edg')) {
      browserName = 'Edge';
    }

    const info: BrowserInfo = {
      name: browserName,
      isSupported: missingFeatures.length === 0,
      missingFeatures
    };

    setBrowserInfo(info);
    setIsVisible(!info.isSupported);
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    setIsVisible(false);
  };

  if (!browserInfo || !isVisible || isDismissed) {
    return null;
  }

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="fixed top-4 left-4 right-4 z-50 max-w-2xl mx-auto"
      >
        <Alert className="border-yellow-300 bg-yellow-50 shadow-lg">
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-3 flex-1">
              <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-medium text-yellow-800 mb-2">
                  ⚠️ Limited Browser Compatibility Detected
                </h4>
                <AlertDescription className="text-sm text-yellow-700">
                  <p className="mb-2">
                    Your browser ({browserInfo.name}) may not support all LinguaLink features.
                  </p>
                  {browserInfo.missingFeatures.length > 0 && (
                    <div className="mb-3">
                      <p className="font-medium mb-1">Missing features:</p>
                      <ul className="list-disc list-inside space-y-1">
                        {browserInfo.missingFeatures.map((feature) => (
                          <li key={feature}>{feature}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  <div className="flex items-center space-x-2 p-2 bg-white/60 rounded-lg">
                    <Chrome className="w-5 h-5 text-blue-600" />
                    <p className="text-xs">
                      <strong>Recommended:</strong> Use Chrome, Edge, or Safari for the best experience.
                    </p>
                  </div>
                </AlertDescription>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDismiss}
              className="ml-2 flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </Alert>
      </motion.div>
    </AnimatePresence>
  );
}
