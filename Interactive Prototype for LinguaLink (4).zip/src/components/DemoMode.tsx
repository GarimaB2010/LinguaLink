import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Pause, RotateCcw, FastForward, Sparkles, Trophy } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';

interface DemoStep {
  id: string;
  title: string;
  description: string;
  action: string;
  duration: number;
  emoji: string;
}

const DEMO_SCENARIOS = [
  {
    id: 'healthcare',
    title: '🏥 Healthcare Communication',
    description: 'Patient-Doctor Language Barrier',
    steps: [
      {
        id: 'patient_speaks',
        title: 'Patient Speaks Spanish',
        description: 'Patient explains symptoms in Spanish',
        action: 'Me duele mucho el estómago y tengo náuseas',
        duration: 3000,
        emoji: '🗣️'
      },
      {
        id: 'translation',
        title: 'Real-time Translation',
        description: 'LinguaLink translates to English',
        action: 'My stomach hurts a lot and I have nausea',
        duration: 2000,
        emoji: '🔄'
      },
      {
        id: 'simplification',
        title: 'Medical Simplification',
        description: 'Complex medical terms made simple',
        action: 'I have stomach pain and feel sick',
        duration: 2000,
        emoji: '📝'
      },
      {
        id: 'doctor_response',
        title: 'Doctor Responds',
        description: 'Doctor explains treatment in simple terms',
        action: 'You might have food poisoning. We need to run some tests.',
        duration: 3000,
        emoji: '👨‍⚕️'
      }
    ]
  },
  {
    id: 'education',
    title: '🎓 Educational Support',
    description: 'Student Learning Assistance',
    steps: [
      {
        id: 'complex_text',
        title: 'Complex Academic Text',
        description: 'Student encounters difficult reading material',
        action: 'The mitochondria undergoes cellular respiration to produce ATP',
        duration: 3000,
        emoji: '📚'
      },
      {
        id: 'simplify_level1',
        title: 'First Simplification',
        description: 'Breaking down complex concepts',
        action: 'Mitochondria makes energy for cells through breathing process',
        duration: 2500,
        emoji: '🔍'
      },
      {
        id: 'simplify_level2',
        title: 'Maximum Simplification',
        description: 'Making it accessible for all learners',
        action: 'Cell parts make power for the body',
        duration: 2000,
        emoji: '✨'
      },
      {
        id: 'audio_support',
        title: 'Audio Learning',
        description: 'Text-to-speech for auditory learners',
        action: 'Playing audio: "Cell parts make power for the body"',
        duration: 3000,
        emoji: '🔊'
      }
    ]
  },
  {
    id: 'legal',
    title: '⚖️ Legal Accessibility',
    description: 'Court Proceedings Support',
    steps: [
      {
        id: 'legal_document',
        title: 'Complex Legal Language',
        description: 'Defendant receives legal notice',
        action: 'The defendant is hereby notified of proceedings pursuant to statute 42-1337',
        duration: 4000,
        emoji: '📋'
      },
      {
        id: 'plain_english',
        title: 'Plain English Translation',
        description: 'Converting legalese to understandable language',
        action: 'You are being told about a court case that affects you',
        duration: 3000,
        emoji: '🔄'
      },
      {
        id: 'sign_language',
        title: 'Sign Language Interpretation',
        description: 'Converting to visual communication',
        action: 'Detected Sign: "I understand" (92% confidence)',
        duration: 2500,
        emoji: '🤟'
      },
      {
        id: 'confirmation',
        title: 'Verified Understanding',
        description: 'Ensuring clear communication',
        action: 'Communication verified ✓ Rights explained ✓',
        duration: 2000,
        emoji: '✅'
      }
    ]
  }
];

interface DemoModeProps {
  isActive: boolean;
  onComplete: (scenario: string) => void;
  onClose: () => void;
}

export function DemoMode({ isActive, onComplete, onClose }: DemoModeProps) {
  const [selectedScenario, setSelectedScenario] = useState<typeof DEMO_SCENARIOS[0] | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (!isPlaying || !selectedScenario) return;

    const currentStep = selectedScenario.steps[currentStepIndex];
    if (!currentStep) return;

    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + (100 / (currentStep.duration / 100));
        
        if (newProgress >= 100) {
          // Move to next step
          if (currentStepIndex < selectedScenario.steps.length - 1) {
            setCurrentStepIndex(prev => prev + 1);
            return 0;
          } else {
            // Demo complete
            setIsPlaying(false);
            onComplete(selectedScenario.id);
            return 100;
          }
        }
        
        return newProgress;
      });
    }, 100);

    return () => clearInterval(interval);
  }, [isPlaying, selectedScenario, currentStepIndex, onComplete]);

  const startDemo = (scenario: typeof DEMO_SCENARIOS[0]) => {
    setSelectedScenario(scenario);
    setCurrentStepIndex(0);
    setProgress(0);
    setIsPlaying(true);
  };

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const resetDemo = () => {
    setCurrentStepIndex(0);
    setProgress(0);
    setIsPlaying(false);
  };

  const skipToNext = () => {
    if (selectedScenario && currentStepIndex < selectedScenario.steps.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
      setProgress(0);
    }
  };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-auto">
        <CardHeader className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
                className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center"
              >
                <Sparkles className="w-5 h-5" />
              </motion.div>
              <div>
                <CardTitle>LinguaLink Demo Mode</CardTitle>
                <p className="text-sm text-white/80">Experience real-world impact scenarios</p>
              </div>
            </div>
            <Button variant="ghost" onClick={onClose} className="text-white hover:bg-white/20">
              ✕
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          {!selectedScenario ? (
            // Scenario Selection
            <div className="space-y-4">
              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold mb-2">Choose a Demo Scenario</h3>
                <p className="text-muted-foreground">
                  See how LinguaLink breaks barriers in real-world situations
                </p>
              </div>

              <div className="grid gap-4">
                {DEMO_SCENARIOS.map((scenario) => (
                  <motion.div
                    key={scenario.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Card className="cursor-pointer hover:shadow-lg transition-all border-2 hover:border-primary/20">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium mb-1">{scenario.title}</h4>
                            <p className="text-sm text-muted-foreground">{scenario.description}</p>
                            <Badge variant="outline" className="mt-2">
                              {scenario.steps.length} steps
                            </Badge>
                          </div>
                          <Button 
                            onClick={() => startDemo(scenario)}
                            className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                          >
                            <Play className="w-4 h-4 mr-2" />
                            Start Demo
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          ) : (
            // Demo Playback
            <div className="space-y-6">
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-2">{selectedScenario.title}</h3>
                <p className="text-muted-foreground">{selectedScenario.description}</p>
              </div>

              {/* Progress */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Step {currentStepIndex + 1} of {selectedScenario.steps.length}</span>
                  <span>{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" />
              </div>

              {/* Current Step */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentStepIndex}
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-6 border border-purple-200"
                >
                  <div className="flex items-start space-x-4">
                    <div className="text-4xl">
                      {selectedScenario.steps[currentStepIndex]?.emoji}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium mb-2">
                        {selectedScenario.steps[currentStepIndex]?.title}
                      </h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        {selectedScenario.steps[currentStepIndex]?.description}
                      </p>
                      <div className="bg-white p-3 rounded border border-purple-200">
                        <motion.p
                          key={`${currentStepIndex}-action`}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-sm font-mono"
                        >
                          {selectedScenario.steps[currentStepIndex]?.action}
                        </motion.p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>

              {/* Controls */}
              <div className="flex items-center justify-center space-x-3">
                <Button variant="outline" onClick={resetDemo}>
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
                
                <Button onClick={togglePlayPause} size="lg">
                  {isPlaying ? (
                    <>
                      <Pause className="w-4 h-4 mr-2" />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Play
                    </>
                  )}
                </Button>
                
                <Button variant="outline" onClick={skipToNext}>
                  <FastForward className="w-4 h-4 mr-2" />
                  Skip
                </Button>
              </div>

              {/* Step Timeline */}
              <div className="flex justify-center space-x-2">
                {selectedScenario.steps.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setCurrentStepIndex(index);
                      setProgress(0);
                    }}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      index === currentStepIndex
                        ? 'bg-primary'
                        : index < currentStepIndex
                        ? 'bg-green-500'
                        : 'bg-gray-300'
                    }`}
                  />
                ))}
              </div>

              <Button
                variant="outline"
                onClick={() => setSelectedScenario(null)}
                className="w-full"
              >
                Choose Different Scenario
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}