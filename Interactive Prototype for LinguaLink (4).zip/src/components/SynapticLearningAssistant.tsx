import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, Lightbulb, Target, TrendingUp, Sparkles, Zap, Network, Eye } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';

interface LearningPattern {
  type: string;
  frequency: number;
  effectiveness: number;
  trend: 'improving' | 'stable' | 'declining';
}

interface SynapticInsight {
  category: string;
  insight: string;
  confidence: number;
  actionable: boolean;
}

interface LearningProfile {
  learningStyle: string;
  comprehensionSpeed: number;
  retentionRate: number;
  preferredComplexity: number;
  adaptationSuggestions: string[];
  synapticInsights: SynapticInsight[];
  neuralEfficiency: number;
}

interface SynapticAssistantProps {
  isActive: boolean;
  conversationHistory: string[];
  userInteractions: any[];
  onLearningComplete: (profile: LearningProfile) => void;
}

export function SynapticLearningAssistant({ 
  isActive, 
  conversationHistory, 
  userInteractions, 
  onLearningComplete 
}: SynapticAssistantProps) {
  const [learningStage, setLearningStage] = useState('idle');
  const [neuralProcessing, setNeuralProcessing] = useState(0);
  const [patternRecognition, setPatternRecognition] = useState(0);
  const [synapticFormation, setSynapticFormation] = useState(0);
  const [adaptiveModeling, setAdaptiveModeling] = useState(0);
  const [currentProfile, setCurrentProfile] = useState<LearningProfile | null>(null);
  const [neuralConnections, setNeuralConnections] = useState<{ x: number; y: number; active: boolean }[]>([]);

  useEffect(() => {
    if (isActive) {
      generateNeuralConnections();
      startSynapticLearning();
    }
  }, [isActive, conversationHistory, userInteractions]);

  const generateNeuralConnections = () => {
    const connections = [];
    for (let i = 0; i < 12; i++) {
      connections.push({
        x: Math.random() * 280,
        y: Math.random() * 280,
        active: Math.random() > 0.3
      });
    }
    setNeuralConnections(connections);
  };

  const startSynapticLearning = async () => {
    setLearningStage('processing');
    
    // Stage 1: Neural Processing
    for (let i = 0; i <= 100; i += 2) {
      setNeuralProcessing(i);
      // Randomly activate neural connections
      setNeuralConnections(prev => prev.map(conn => ({
        ...conn,
        active: Math.random() > 0.4
      })));
      await new Promise(resolve => setTimeout(resolve, 40));
    }

    // Stage 2: Pattern Recognition
    setLearningStage('recognizing');
    for (let i = 0; i <= 100; i += 3) {
      setPatternRecognition(i);
      await new Promise(resolve => setTimeout(resolve, 35));
    }

    // Stage 3: Synaptic Formation
    setLearningStage('forming');
    for (let i = 0; i <= 100; i += 4) {
      setSynapticFormation(i);
      await new Promise(resolve => setTimeout(resolve, 30));
    }

    // Stage 4: Adaptive Modeling
    setLearningStage('adapting');
    for (let i = 0; i <= 100; i += 5) {
      setAdaptiveModeling(i);
      await new Promise(resolve => setTimeout(resolve, 25));
    }

    // Generate learning profile
    const profile = generateLearningProfile();
    setCurrentProfile(profile);
    setLearningStage('evolved');
    onLearningComplete(profile);

    // Auto-reset
    setTimeout(() => {
      setLearningStage('idle');
      setCurrentProfile(null);
      setNeuralProcessing(0);
      setPatternRecognition(0);
      setSynapticFormation(0);
      setAdaptiveModeling(0);
    }, 7000);
  };

  const generateLearningProfile = (): LearningProfile => {
    // Analyze conversation patterns
    const totalInteractions = conversationHistory.length;
    const avgResponseLength = conversationHistory.reduce((acc, msg) => acc + msg.length, 0) / Math.max(totalInteractions, 1);
    
    // Determine learning style based on interaction patterns
    let learningStyle = 'Balanced Multi-Modal';
    if (avgResponseLength > 200) {
      learningStyle = 'Deep Analytical';
    } else if (avgResponseLength < 50) {
      learningStyle = 'Quick Intuitive';
    } else if (totalInteractions > 10) {
      learningStyle = 'Interactive Collaborative';
    }

    // Calculate metrics
    const comprehensionSpeed = 70 + Math.random() * 30;
    const retentionRate = 80 + Math.random() * 20;
    const preferredComplexity = 60 + Math.random() * 40;
    const neuralEfficiency = 85 + Math.random() * 15;

    // Generate adaptive suggestions
    const adaptationSuggestions = generateAdaptiveSuggestions(learningStyle, comprehensionSpeed, preferredComplexity);
    
    // Generate synaptic insights
    const synapticInsights = generateSynapticInsights(conversationHistory, learningStyle);

    return {
      learningStyle,
      comprehensionSpeed,
      retentionRate,
      preferredComplexity,
      adaptationSuggestions,
      synapticInsights,
      neuralEfficiency
    };
  };

  const generateAdaptiveSuggestions = (style: string, speed: number, complexity: number): string[] => {
    const suggestions = [];

    if (style === 'Deep Analytical') {
      suggestions.push('🧠 Provide detailed explanations with supporting examples');
      suggestions.push('📊 Include data, charts, and comprehensive analysis');
      suggestions.push('🔗 Show connections between concepts');
    } else if (style === 'Quick Intuitive') {
      suggestions.push('⚡ Use concise, bullet-point format');
      suggestions.push('💡 Lead with key insights first');
      suggestions.push('🎯 Focus on actionable takeaways');
    } else if (style === 'Interactive Collaborative') {
      suggestions.push('🤝 Encourage questions and feedback');
      suggestions.push('🎪 Use interactive examples and scenarios');
      suggestions.push('👥 Build on their contributions');
    }

    if (speed > 85) {
      suggestions.push('🚀 Can handle rapid information flow');
    } else if (speed < 75) {
      suggestions.push('🌱 Allow processing time between concepts');
    }

    if (complexity > 80) {
      suggestions.push('🎓 Present advanced concepts and nuances');
    } else if (complexity < 70) {
      suggestions.push('📚 Break down complex ideas into simpler parts');
    }

    return suggestions.slice(0, 4);
  };

  const generateSynapticInsights = (history: string[], style: string): SynapticInsight[] => {
    const insights: SynapticInsight[] = [
      {
        category: 'Communication Pattern',
        insight: `Shows preference for ${style.toLowerCase()} communication`,
        confidence: 92 + Math.random() * 8,
        actionable: true
      },
      {
        category: 'Engagement Level',
        insight: history.length > 5 ? 'High engagement with sustained conversation' : 'Prefers focused, purposeful interactions',
        confidence: 88 + Math.random() * 12,
        actionable: true
      },
      {
        category: 'Learning Velocity',
        insight: 'Demonstrates rapid pattern recognition and adaptation',
        confidence: 85 + Math.random() * 15,
        actionable: true
      },
      {
        category: 'Cognitive Load',
        insight: 'Optimal performance in current complexity range',
        confidence: 90 + Math.random() * 10,
        actionable: false
      },
      {
        category: 'Neural Plasticity',
        insight: 'High adaptability to new communication styles',
        confidence: 87 + Math.random() * 13,
        actionable: true
      }
    ];

    return insights.slice(0, 3 + Math.floor(Math.random() * 2));
  };

  const renderNeuralNetwork = () => {
    return (
      <svg width="300" height="200" className="w-full h-48">
        {/* Neural connections */}
        {neuralConnections.map((start, i) => 
          neuralConnections.slice(i + 1).map((end, j) => (
            <motion.line
              key={`${i}-${j}`}
              x1={start.x}
              y1={start.y}
              x2={end.x}
              y2={end.y}
              stroke={start.active && end.active ? '#8B5CF6' : '#4B5563'}
              strokeWidth={start.active && end.active ? 2 : 1}
              opacity={start.active && end.active ? 0.8 : 0.3}
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
              transition={{ duration: 2, delay: (i + j) * 0.1 }}
            />
          ))
        )}

        {/* Neural nodes */}
        {neuralConnections.map((conn, i) => (
          <motion.circle
            key={i}
            cx={conn.x}
            cy={conn.y}
            r={conn.active ? 6 : 4}
            fill={conn.active ? '#8B5CF6' : '#6B7280'}
            animate={{
              scale: conn.active ? [1, 1.2, 1] : 1,
              opacity: conn.active ? [0.8, 1, 0.8] : 0.6
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.2
            }}
          />
        ))}

        {/* Synaptic activity indicators */}
        {neuralConnections.filter(conn => conn.active).map((conn, i) => (
          <motion.circle
            key={`pulse-${i}`}
            cx={conn.x}
            cy={conn.y}
            r={15}
            fill="none"
            stroke="#8B5CF6"
            strokeWidth={1}
            opacity={0}
            animate={{
              r: [6, 20],
              opacity: [0.8, 0]
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.5
            }}
          />
        ))}
      </svg>
    );
  };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50"
    >
      <Card className="w-[650px] max-h-[85vh] overflow-y-auto bg-gradient-to-br from-violet-900/90 to-purple-900/90 text-white border-violet-500/50 shadow-2xl">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <motion.div
              animate={{ 
                rotate: [0, 360],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 8, 
                repeat: Infinity,
                ease: "linear"
              }}
              className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-violet-500 to-purple-500 rounded-full flex items-center justify-center"
            >
              <Brain className="w-8 h-8" />
            </motion.div>
            <h3 className="text-xl font-bold bg-gradient-to-r from-violet-300 to-purple-300 bg-clip-text text-transparent">
              Synaptic Learning Assistant
            </h3>
            <p className="text-sm text-violet-200">
              Neural adaptation and cognitive pattern optimization
            </p>
          </div>

          {/* Neural Network Visualization */}
          <div className="mb-6 p-4 bg-gradient-to-r from-violet-500/20 to-purple-500/20 rounded-lg border border-violet-500/30">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium flex items-center space-x-2">
                <Network className="w-4 h-4" />
                <span>Neural Network Activity</span>
              </h4>
              <div className="flex items-center space-x-2 text-xs">
                <div className="w-2 h-2 bg-violet-400 rounded-full animate-pulse" />
                <span className="text-violet-300">Live Synaptic Formation</span>
              </div>
            </div>
            {renderNeuralNetwork()}
          </div>

          {/* Learning Progress */}
          {learningStage !== 'idle' && learningStage !== 'evolved' && (
            <div className="space-y-4 mb-6">
              <div className="text-center mb-4">
                <div className="text-sm text-violet-300 mb-2">
                  {learningStage === 'processing' && '🧠 Neural processing active...'}
                  {learningStage === 'recognizing' && '🔍 Pattern recognition engaged...'}
                  {learningStage === 'forming' && '⚡ Synaptic pathways forming...'}
                  {learningStage === 'adapting' && '🎯 Adaptive modeling in progress...'}
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Neural Processing</span>
                  <span className="text-xs text-violet-300">{neuralProcessing}%</span>
                </div>
                <Progress value={neuralProcessing} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Pattern Recognition</span>
                  <span className="text-xs text-violet-300">{patternRecognition}%</span>
                </div>
                <Progress value={patternRecognition} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Synaptic Formation</span>
                  <span className="text-xs text-violet-300">{synapticFormation}%</span>
                </div>
                <Progress value={synapticFormation} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Adaptive Modeling</span>
                  <span className="text-xs text-violet-300">{adaptiveModeling}%</span>
                </div>
                <Progress value={adaptiveModeling} className="h-2" />
              </div>
            </div>
          )}

          {/* Learning Profile Results */}
          {currentProfile && learningStage === 'evolved' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Learning Overview */}
              <div className="p-4 bg-gradient-to-r from-violet-500/20 to-purple-500/20 rounded-lg border border-violet-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Brain className="w-4 h-4" />
                  <span>Cognitive Profile Analysis</span>
                </h4>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <span className="text-xs text-violet-300">Learning Style:</span>
                    <p className="text-sm text-white font-medium">{currentProfile.learningStyle}</p>
                  </div>
                  <div>
                    <span className="text-xs text-violet-300">Neural Efficiency:</span>
                    <p className="text-sm text-white font-medium">{currentProfile.neuralEfficiency.toFixed(1)}%</p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-2 bg-violet-600/20 rounded">
                    <div className="text-lg font-medium text-violet-300">{currentProfile.comprehensionSpeed.toFixed(0)}%</div>
                    <div className="text-xs text-violet-200">Processing Speed</div>
                  </div>
                  <div className="text-center p-2 bg-purple-600/20 rounded">
                    <div className="text-lg font-medium text-purple-300">{currentProfile.retentionRate.toFixed(0)}%</div>
                    <div className="text-xs text-purple-200">Retention Rate</div>
                  </div>
                  <div className="text-center p-2 bg-pink-600/20 rounded">
                    <div className="text-lg font-medium text-pink-300">{currentProfile.preferredComplexity.toFixed(0)}%</div>
                    <div className="text-xs text-pink-200">Complexity Pref.</div>
                  </div>
                </div>
              </div>

              {/* Synaptic Insights */}
              <div className="p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg border border-purple-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Eye className="w-4 h-4" />
                  <span>Synaptic Insights</span>
                </h4>
                
                <div className="space-y-3">
                  {currentProfile.synapticInsights.map((insight, index) => (
                    <div key={index} className="flex items-start space-x-3 p-2 bg-white/5 rounded">
                      <div className="w-6 h-6 bg-purple-500/30 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Zap className="w-3 h-3 text-purple-300" />
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-1">
                          <span className="text-xs text-purple-300 font-medium">{insight.category}</span>
                          <Badge variant="outline" className="text-xs border-purple-400/50 text-purple-200">
                            {insight.confidence.toFixed(0)}% confidence
                          </Badge>
                        </div>
                        <p className="text-sm text-white">{insight.insight}</p>
                        {insight.actionable && (
                          <div className="flex items-center space-x-1 mt-1">
                            <Target className="w-3 h-3 text-green-400" />
                            <span className="text-xs text-green-300">Actionable insight</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Adaptive Suggestions */}
              <div className="p-4 bg-gradient-to-r from-green-500/20 to-teal-500/20 rounded-lg border border-green-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Lightbulb className="w-4 h-4" />
                  <span>Adaptive Communication Strategy</span>
                </h4>
                
                <div className="space-y-2">
                  {currentProfile.adaptationSuggestions.map((suggestion, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.2 }}
                      className="flex items-center space-x-2 text-sm"
                    >
                      <TrendingUp className="w-4 h-4 text-green-400 flex-shrink-0" />
                      <span className="text-green-200">{suggestion}</span>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* Evolution Indicator */}
          <div className="mt-6 flex justify-center">
            <div className="flex items-center space-x-2 text-xs text-violet-300">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="w-4 h-4" />
              </motion.div>
              <span>Neural pathways {learningStage === 'evolved' ? 'evolved' : 'evolving'}...</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}