import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HomePage } from "./components/HomePage";
import { ConversationPage } from "./components/ConversationPage";
import { SettingsPage } from "./components/SettingsPage";
import { CommunityPage } from "./components/CommunityPage";
import { BottomNavigation } from "./components/BottomNavigation";
import { FloatingEmojis } from "./components/FloatingEmojis";
import { ColorfulParticles } from "./components/ColorfulParticles";
import { LoadingAnimation } from "./components/LoadingAnimation";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { ChatbotToggle } from "./components/ChatbotToggle";
import { BrowserCompatibilityAlert } from "./components/BrowserCompatibilityAlert";
import { toast } from "sonner@2.0.3";
import { Toaster } from "./components/ui/sonner";
import { PermissionGuide } from "./components/PermissionGuide";
import { NotificationProvider, useNotifications } from "./components/NotificationContext";

function AppContent() {
  const [activeTab, setActiveTab] = useState('home');
  const [conversationMode, setConversationMode] = useState('speak');
  const [isLoading, setIsLoading] = useState(true);
  const [showPermissionGuide, setShowPermissionGuide] = useState(false);
  const [permissionsGranted, setPermissionsGranted] = useState({
    camera: false,
    microphone: false
  });

  // Use notification context
  const { shownNotifications, markNotificationShown, hasNotificationBeenShown, canShowCameraNotification, markCameraNotificationShown } = useNotifications();
  
  // Settings state
  const [settings, setSettings] = useState({
    textSize: 100,
    colorBlindMode: false,
    darkMode: false,
    easyMode: false,
    speechSpeed: 1.0,
    voiceType: 'female',
    autoPlay: false,
    preferredLanguage: 'english',
    autoSimplify: true,
    showOriginal: true,
    hapticFeedback: true,
    reduceAnimations: false,
    offlineMode: false
  });

  // Auto-request permissions function with notification tracking
  const requestPermissionsAutomatically = async (isRetry = false) => {
    const permissions = { camera: false, microphone: false };
    
    try {
      // Check if browser supports media devices
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        console.warn('Browser does not support media devices');
        return permissions;
      }
      
      // Request microphone permission FIRST and keep the stream alive briefly
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
            sampleRate: 44100
          } 
        });
        
        if (micStream && micStream.active) {
          // Keep stream active for 500ms to ensure permission is properly granted
          setTimeout(() => {
            micStream.getTracks().forEach(track => track.stop());
          }, 500);
          
          permissions.microphone = true;
          console.log('✅ Microphone permission granted');
        }
      } catch (error: any) {
        console.warn('Microphone permission denied:', error.name);
      }

      // Small delay between requests
      await new Promise(resolve => setTimeout(resolve, 500));

      // Request camera permission and keep the stream alive briefly
      try {
        const cameraStream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: 1280, min: 640 }, 
            height: { ideal: 720, min: 480 },
            frameRate: { ideal: 30, min: 15 }
          } 
        });
        
        if (cameraStream && cameraStream.active) {
          // Keep stream active for 500ms to ensure permission is properly granted
          setTimeout(() => {
            cameraStream.getTracks().forEach(track => track.stop());
          }, 500);
          
          permissions.camera = true;
          console.log('✅ Camera permission granted');
        }
      } catch (error: any) {
        console.warn('Camera permission denied:', error.name);
      }

      // Show notifications only once using centralized tracking system
      if (permissions.camera && permissions.microphone && !shownNotifications.allPermissionsGranted) {
        // All permissions granted
        toast.success('✅ All permissions granted! Ready to use all features!', { duration: 3000 });
        markNotificationShown('allPermissionsGranted');
        markNotificationShown('partialPermissions'); // Prevent partial notifications after full access
        markNotificationShown('microphoneGranted'); // Prevent individual microphone notifications
        markCameraNotificationShown(); // Mark all camera notifications as shown
      } else if (permissions.camera && !permissions.microphone && !shownNotifications.allPermissionsGranted) {
        // Only camera granted - only show during retry, not initial load, and only if no camera notification shown yet
        if (isRetry && canShowCameraNotification()) {
          toast.success('✅ Camera access granted!', { 
            duration: 3000,
            description: 'You can now use sign language features. Microphone still needed for speech recognition.'
          });
          markCameraNotificationShown();
        }
      } else if (!permissions.camera && permissions.microphone && !shownNotifications.microphoneGranted && !shownNotifications.allPermissionsGranted) {
        // Only microphone granted - only show during retry, not initial load
        if (isRetry) {
          toast.success('✅ Microphone access granted!', { 
            duration: 3000,
            description: 'You can now use speech recognition. Camera still needed for sign language.'
          });
          markNotificationShown('microphoneGranted');
        }
      } else if (!permissions.camera && !permissions.microphone) {
        // No permissions - don't show notifications, handled by permission guide
        console.log('No permissions granted');
      }

    } catch (error) {
      console.error('Error in permission flow:', error);
    }

    console.log('Final permissions state:', permissions);
    return permissions;
  };

  // Initialize app
  useEffect(() => {
    const initApp = async () => {
      // Wait for UI to load
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Request permissions quietly (no notifications on initial load)
      const permissions = await requestPermissionsAutomatically(false);
      setPermissionsGranted(permissions);
      
      // Store permissions globally for debugging
      (window as any).linguaLinkPermissions = permissions;
      
      // Finish loading
      await new Promise(resolve => setTimeout(resolve, 500));
      setIsLoading(false);
    };

    initApp();
  }, []);

  const handleNavigation = (page: string, mode?: string) => {
    setActiveTab(page);
    if (mode) {
      setConversationMode(mode);
      
      // Handle sign language mode specifically - only show if camera is already available and no camera notification shown yet
      if (mode === 'sign' && permissionsGranted.camera && canShowCameraNotification()) {
        // Show success notification for sign language mode only once per session
        setTimeout(() => {
          toast.success('📹 Camera ready for sign language!', { 
            duration: 3000,
            description: 'You can now communicate using sign language gestures.'
          });
          markCameraNotificationShown();
        }, 300);
      }
    }
    
    // Add haptic feedback if supported
    if ('vibrate' in navigator && settings.hapticFeedback) {
      navigator.vibrate(50);
    }
  };

  const handleSettingsChange = (newSettings: any) => {
    setSettings(newSettings);
  };

  const handleShake = () => {
    // Removed Easter egg - professional demo mode only
  };

  const renderCurrentPage = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage onNavigate={handleNavigation} />;
      case 'conversation':
        return <ConversationPage mode={conversationMode} settings={settings} permissionsGranted={permissionsGranted} />;
      case 'settings':
        return <SettingsPage settings={settings} onSettingsChange={handleSettingsChange} permissionsGranted={permissionsGranted} />;
      case 'community':
        return <CommunityPage onNavigate={handleNavigation} />;
      default:
        return <HomePage onNavigate={handleNavigation} />;
    }
  };

  // Show loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-blue-50 to-green-50">
        <div className="text-center">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <div className="text-6xl mb-4">🌍</div>
            <h1 className="text-4xl rainbow-text mb-2">LinguaLink</h1>
            <p className="text-muted-foreground">Breaking barriers worldwide ✨</p>
          </motion.div>
          <LoadingAnimation />
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="mt-6"
          >
            <p className="text-sm text-muted-foreground">Loading application...</p>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <BrowserCompatibilityAlert />
      <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Background Effects */}
      {!settings.reduceAnimations && (
        <>
          <FloatingEmojis />
          <ColorfulParticles />
        </>
      )}

      {/* Apply dynamic text size and accessibility settings */}
      <div 
        style={{ 
          fontSize: `${settings.textSize}%`,
          filter: settings.colorBlindMode ? 'contrast(1.2) saturate(1.3)' : 'none'
        }}
        className={`${settings.darkMode ? 'dark' : ''} ${settings.reduceAnimations ? 'motion-reduce' : ''}`}
      >
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
        >
          {renderCurrentPage()}
        </motion.div>
        
        <BottomNavigation 
          activeTab={activeTab} 
          onTabChange={setActiveTab}
          settings={settings}
        />

        {/* AI Chatbot */}
        <ChatbotToggle settings={settings} />

        {/* Permissions Button */}
        {(!permissionsGranted.camera || !permissionsGranted.microphone) && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="fixed top-4 right-4 z-40"
          >
            <button
              onClick={() => {
                setShowPermissionGuide(true);
              }}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-3 rounded-full shadow-lg flex items-center space-x-3 text-sm border border-white/20 backdrop-blur-sm"
            >
              <span className="text-lg">🔐</span>
              <div className="text-left">
                <div className="text-sm">Enable Features</div>
                <div className="text-xs text-blue-100">Grant permissions</div>
              </div>
            </button>
          </motion.div>
        )}
      </div>

        {/* Screen reader announcements */}
        <div 
          className="sr-only" 
          aria-live="polite" 
          aria-atomic="true"
          id="live-region"
        />
        
        {/* Toast notifications */}
        <Toaster position="top-center" richColors />
        
        {/* Permission Guide */}
        <PermissionGuide
          isOpen={showPermissionGuide}
          onClose={() => setShowPermissionGuide(false)}
          missingPermissions={{
            camera: !permissionsGranted.camera,
            microphone: !permissionsGranted.microphone
          }}
          onRetry={async () => {
            const newPermissions = await requestPermissionsAutomatically(true);
            setPermissionsGranted(newPermissions);
            if (newPermissions.camera && newPermissions.microphone) {
              setShowPermissionGuide(false);
            }
          }}
        />
      </div>
    </ErrorBoundary>
  );
}

// Main App component with NotificationProvider
export default function App() {
  return (
    <NotificationProvider>
      <AppContent />
    </NotificationProvider>
  );
}