import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface SuccessCelebrationProps {
  trigger: boolean;
  message?: string;
  duration?: number;
}

const CELEBRATION_EMOJIS = ['🎉', '🎊', '✨', '🌟', '💫', '🎈', '🎯', '🏆', '💖', '🚀'];

export function SuccessCelebration({ trigger, message = "Success!", duration = 2000 }: SuccessCelebrationProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [particles, setParticles] = useState<Array<{ id: number; emoji: string; x: number; y: number }>>([]);

  useEffect(() => {
    if (trigger) {
      setIsVisible(true);
      
      // Generate celebration particles
      const newParticles = Array.from({ length: 12 }, (_, i) => ({
        id: i,
        emoji: CELEBRATION_EMOJIS[Math.floor(Math.random() * CELEBRATION_EMOJIS.length)],
        x: Math.random() * 100,
        y: Math.random() * 100
      }));
      
      setParticles(newParticles);

      const timer = setTimeout(() => {
        setIsVisible(false);
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [trigger, duration]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 pointer-events-none z-50 overflow-hidden"
        >
          {/* Celebration particles */}
          {particles.map((particle) => (
            <motion.div
              key={particle.id}
              className="absolute text-4xl"
              style={{
                left: `${particle.x}%`,
                top: `${particle.y}%`,
              }}
              initial={{ 
                scale: 0,
                opacity: 0,
                y: 100
              }}
              animate={{ 
                scale: [0, 1.5, 1],
                opacity: [0, 1, 0],
                y: [100, -100],
                rotate: [0, 360],
                x: [0, Math.random() * 200 - 100]
              }}
              transition={{
                duration: 2,
                ease: "easeOut",
                delay: particle.id * 0.1
              }}
            >
              {particle.emoji}
            </motion.div>
          ))}

          {/* Central message */}
          <div className="flex items-center justify-center h-full">
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              transition={{ 
                type: "spring",
                stiffness: 300,
                damping: 20
              }}
              className="text-center bg-white/90 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/20"
            >
              <motion.div
                animate={{ 
                  scale: [1, 1.2, 1],
                  rotate: [0, 10, -10, 0]
                }}
                transition={{ 
                  duration: 0.8,
                  repeat: 2
                }}
                className="text-6xl mb-4"
              >
                🎉
              </motion.div>
              <motion.h3
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-2xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-2"
              >
                {message}
              </motion.h3>
              <motion.p
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="text-muted-foreground"
              >
                You're breaking barriers! 🌟
              </motion.p>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}