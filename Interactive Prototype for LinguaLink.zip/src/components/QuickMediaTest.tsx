import { useState } from 'react';
import { motion } from 'motion/react';
import { Camera, Mic, Zap, CheckCircle, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { toast } from 'sonner@2.0.3';

export function QuickMediaTest() {
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<{
    microphone: 'success' | 'failed' | 'pending';
    camera: 'success' | 'failed' | 'pending';
  }>({
    microphone: 'pending',
    camera: 'pending'
  });

  const runQuickTest = async () => {
    setTesting(true);
    setResults({ microphone: 'pending', camera: 'pending' });
    
    toast.info('🚀 Running quick media test...', { duration: 2000 });

    // Test Microphone
    try {
      const micStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      
      if (micStream && micStream.active) {
        setResults(prev => ({ ...prev, microphone: 'success' }));
        toast.success('✅ Microphone: Working!', { duration: 2000 });
        
        // Stop the stream after brief test
        setTimeout(() => {
          micStream.getTracks().forEach(track => track.stop());
        }, 1000);
      } else {
        throw new Error('Microphone stream not active');
      }
    } catch (error: any) {
      setResults(prev => ({ ...prev, microphone: 'failed' }));
      toast.error(`❌ Microphone: ${error.message}`, { duration: 3000 });
      console.error('Microphone test failed:', error);
    }

    // Test Camera
    try {
      const camStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 640 }, 
          height: { ideal: 480 }
        } 
      });
      
      if (camStream && camStream.active) {
        setResults(prev => ({ ...prev, camera: 'success' }));
        toast.success('✅ Camera: Working!', { duration: 2000 });
        
        // Stop the stream after brief test
        setTimeout(() => {
          camStream.getTracks().forEach(track => track.stop());
        }, 1000);
      } else {
        throw new Error('Camera stream not active');
      }
    } catch (error: any) {
      setResults(prev => ({ ...prev, camera: 'failed' }));
      toast.error(`❌ Camera: ${error.message}`, { duration: 3000 });
      console.error('Camera test failed:', error);
    }

    setTesting(false);
    
    // Show final result
    setTimeout(() => {
      const micOk = results.microphone === 'success';
      const camOk = results.camera === 'success';
      
      if (micOk && camOk) {
        toast.success('🎉 Both camera and microphone are working perfectly!', { duration: 4000 });
      } else if (micOk || camOk) {
        toast.success(`✅ ${micOk ? 'Microphone' : 'Camera'} is working!`, { duration: 3000 });
      } else {
        toast.error('❌ Both devices failed. Check browser permissions.', { duration: 4000 });
      }
    }, 1500);
  };

  const getStatusIcon = (status: 'success' | 'failed' | 'pending') => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <div className="w-4 h-4 rounded-full border-2 border-gray-300" />;
    }
  };

  return (
    <Card className="border-2 border-dashed border-purple-300 bg-gradient-to-br from-purple-50 to-pink-50">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center space-x-2">
          <Zap className="w-5 h-5 text-purple-500" />
          <span>Quick Media Test</span>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Test if camera and microphone are working properly
        </p>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between p-2 rounded border">
            <div className="flex items-center space-x-2">
              <Mic className="w-4 h-4" />
              <span className="text-sm">Microphone</span>
            </div>
            {getStatusIcon(results.microphone)}
          </div>
          
          <div className="flex items-center justify-between p-2 rounded border">
            <div className="flex items-center space-x-2">
              <Camera className="w-4 h-4" />
              <span className="text-sm">Camera</span>
            </div>
            {getStatusIcon(results.camera)}
          </div>
        </div>

        <Button
          onClick={runQuickTest}
          disabled={testing}
          className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
        >
          {testing ? (
            <>
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                className="w-4 h-4 mr-2"
              >
                <Zap className="w-4 h-4" />
              </motion.div>
              Testing...
            </>
          ) : (
            <>
              <Zap className="w-4 h-4 mr-2" />
              Run Quick Test
            </>
          )}
        </Button>

        <p className="text-xs text-center text-muted-foreground">
          This will briefly access your camera and microphone to verify they're working
        </p>
      </CardContent>
    </Card>
  );
}