import { useState } from 'react';
import { motion } from 'motion/react';
import { AlertTriangle, CheckCircle, Camera, Mic, RefreshCw, ExternalLink } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';

interface PermissionHelperProps {
  onPermissionsGranted: (permissions: { camera: boolean; microphone: boolean }) => void;
}

export function PermissionHelper({ onPermissionsGranted }: PermissionHelperProps) {
  const [isRequesting, setIsRequesting] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<{
    camera: 'unknown' | 'granted' | 'denied' | 'prompt';
    microphone: 'unknown' | 'granted' | 'denied' | 'prompt';
  }>({
    camera: 'unknown',
    microphone: 'unknown'
  });

  const checkCurrentPermissions = async () => {
    if (!navigator.permissions) {
      toast.info('🔍 Checking permissions manually...');
      return;
    }

    try {
      const cameraPermission = await navigator.permissions.query({ name: 'camera' as PermissionName });
      const microphonePermission = await navigator.permissions.query({ name: 'microphone' as PermissionName });
      
      setPermissionStatus({
        camera: cameraPermission.state,
        microphone: microphonePermission.state
      });

      // Listen for permission changes
      cameraPermission.onchange = () => {
        setPermissionStatus(prev => ({ ...prev, camera: cameraPermission.state }));
      };
      
      microphonePermission.onchange = () => {
        setPermissionStatus(prev => ({ ...prev, microphone: microphonePermission.state }));
      };

    } catch (error) {
      console.log('Permission API not fully supported, falling back to getUserMedia test');
    }
  };

  const requestPermissions = async () => {
    setIsRequesting(true);
    const permissions = { camera: false, microphone: false };

    try {
      toast.info('🎤 Requesting microphone access...', { duration: 2000 });
      
      // Request microphone first
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        permissions.microphone = true;
        micStream.getTracks().forEach(track => track.stop());
        toast.success('🎤 Microphone access granted!');
        
        setPermissionStatus(prev => ({ ...prev, microphone: 'granted' }));
      } catch (error: any) {
        console.error('Microphone permission failed:', error);
        setPermissionStatus(prev => ({ ...prev, microphone: 'denied' }));
        
        if (error.name === 'NotAllowedError') {
          toast.error('🎤 Microphone access denied. Please click "Allow" when prompted.');
        }
      }

      // Small delay between requests
      await new Promise(resolve => setTimeout(resolve, 500));

      toast.info('📹 Requesting camera access...', { duration: 2000 });
      
      // Request camera
      try {
        const camStream = await navigator.mediaDevices.getUserMedia({ video: true });
        permissions.camera = true;
        camStream.getTracks().forEach(track => track.stop());
        toast.success('📹 Camera access granted!');
        
        setPermissionStatus(prev => ({ ...prev, camera: 'granted' }));
      } catch (error: any) {
        console.error('Camera permission failed:', error);
        setPermissionStatus(prev => ({ ...prev, camera: 'denied' }));
        
        if (error.name === 'NotAllowedError') {
          toast.error('📹 Camera access denied. Please click "Allow" when prompted.');
        }
      }

      // Notify parent component
      onPermissionsGranted(permissions);

      if (permissions.camera && permissions.microphone) {
        toast.success('🎉 Perfect! All permissions granted! Revolutionary features unlocked! 🚀', { duration: 4000 });
      } else if (permissions.microphone || permissions.camera) {
        toast.success(`✅ Partial success! ${permissions.microphone ? 'Microphone' : ''} ${permissions.camera ? 'Camera' : ''} ready!`);
      }

    } catch (error) {
      toast.error('❌ Failed to request permissions. Please try manually.');
    } finally {
      setIsRequesting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'granted': return 'text-green-600 bg-green-50 border-green-200';
      case 'denied': return 'text-red-600 bg-red-50 border-red-200';
      case 'prompt': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'granted': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'denied': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default: return <RefreshCw className="w-4 h-4 text-gray-600" />;
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto shadow-lg border-2 border-primary/20">
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <motion.div
            animate={{ 
              rotate: [0, 10, -10, 0],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="text-4xl mb-2"
          >
            🔐
          </motion.div>
          <h3 className="text-lg font-semibold mb-2">Enable Revolutionary Features</h3>
          <p className="text-sm text-muted-foreground">
            Grant camera and microphone access to unlock LinguaLink's amazing AI capabilities!
          </p>
        </div>

        {/* Permission Status */}
        <div className="space-y-3 mb-6">
          <div className={`flex items-center justify-between p-3 rounded-lg border ${getStatusColor(permissionStatus.microphone)}`}>
            <div className="flex items-center space-x-2">
              <Mic className="w-4 h-4" />
              <span className="text-sm font-medium">Microphone</span>
            </div>
            <div className="flex items-center space-x-2">
              {getStatusIcon(permissionStatus.microphone)}
              <Badge variant="outline" className="text-xs">
                {permissionStatus.microphone === 'granted' ? 'Ready' :
                 permissionStatus.microphone === 'denied' ? 'Blocked' :
                 permissionStatus.microphone === 'prompt' ? 'Needs approval' : 'Unknown'}
              </Badge>
            </div>
          </div>

          <div className={`flex items-center justify-between p-3 rounded-lg border ${getStatusColor(permissionStatus.camera)}`}>
            <div className="flex items-center space-x-2">
              <Camera className="w-4 h-4" />
              <span className="text-sm font-medium">Camera</span>
            </div>
            <div className="flex items-center space-x-2">
              {getStatusIcon(permissionStatus.camera)}
              <Badge variant="outline" className="text-xs">
                {permissionStatus.camera === 'granted' ? 'Ready' :
                 permissionStatus.camera === 'denied' ? 'Blocked' :
                 permissionStatus.camera === 'prompt' ? 'Needs approval' : 'Unknown'}
              </Badge>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button 
              onClick={requestPermissions}
              disabled={isRequesting}
              className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
            >
              {isRequesting ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="mr-2"
                >
                  <RefreshCw className="w-4 h-4" />
                </motion.div>
              ) : (
                <CheckCircle className="w-4 h-4 mr-2" />
              )}
              {isRequesting ? 'Requesting Permissions...' : 'Grant Permissions'}
            </Button>
          </motion.div>

          <div className="flex space-x-2">
            <Button 
              onClick={checkCurrentPermissions}
              variant="outline"
              size="sm"
              className="flex-1"
            >
              <RefreshCw className="w-4 h-4 mr-1" />
              Check Status
            </Button>
            
            <Button 
              onClick={() => window.open('https://support.google.com/chrome/answer/2693767', '_blank')}
              variant="outline"
              size="sm"
              className="flex-1"
            >
              <ExternalLink className="w-4 h-4 mr-1" />
              Help
            </Button>
          </div>
        </div>

        {/* Tips */}
        <div className="mt-6 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <h4 className="text-sm font-medium text-blue-800 mb-1">💡 Quick Tips:</h4>
          <ul className="text-xs text-blue-600 space-y-1">
            <li>• Look for camera/microphone icons in your address bar</li>
            <li>• Click "Allow" when your browser asks for permission</li>
            <li>• Some browsers need you to refresh after granting access</li>
            <li>• Check your browser settings if permissions are blocked</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}