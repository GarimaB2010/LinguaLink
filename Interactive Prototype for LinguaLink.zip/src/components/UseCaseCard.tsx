import { LucideIcon } from "lucide-react";
import { motion } from "motion/react";
import { Card, CardContent } from "./ui/card";

interface UseCaseCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color: string;
  onClick: () => void;
}

export function UseCaseCard({ icon: Icon, title, description, color, onClick }: UseCaseCardProps) {
  const handleClick = () => {
    // Haptic feedback
    if ('vibrate' in navigator) {
      navigator.vibrate(50);
    }
    onClick();
  };

  return (
    <motion.div
      whileHover={{ scale: 1.03, y: -5 }}
      whileTap={{ scale: 0.98 }}
    >
      <Card 
        className="cursor-pointer transition-all duration-300 hover:shadow-2xl glass border-0 overflow-hidden group"
        onClick={handleClick}
      >
        <CardContent className="p-6 relative">
          {/* Gradient overlay on hover */}
          <motion.div
            className="absolute inset-0 opacity-0 group-hover:opacity-10 bg-gradient-to-r from-purple-500 to-blue-500 transition-opacity duration-300"
          />
          
          <div className="flex items-start space-x-4 relative z-10">
            <motion.div 
              className={`p-4 rounded-2xl ${color} shadow-lg relative overflow-hidden`}
              whileHover={{ 
                rotate: [0, -10, 10, -10, 0],
                scale: 1.1
              }}
              transition={{ duration: 0.5 }}
            >
              <Icon className="w-7 h-7 text-white" />
              
              {/* Sparkle effect */}
              <motion.div
                className="absolute top-0 right-0 w-2 h-2 bg-yellow-300 rounded-full"
                animate={{
                  scale: [0, 1, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: Math.random()
                }}
              />
            </motion.div>
            <div className="flex-1">
              <motion.h3 
                className="text-lg mb-2 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent"
                whileHover={{ x: 5 }}
              >
                {title}
              </motion.h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
              
              {/* Animated arrow on hover */}
              <motion.div
                className="mt-3 flex items-center text-sm text-purple-600 opacity-0 group-hover:opacity-100"
                initial={{ x: -10 }}
                whileHover={{ x: 0 }}
                transition={{ duration: 0.3 }}
              >
                <span>View demo</span>
                <motion.span
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  className="ml-1"
                >
                  →
                </motion.span>
              </motion.div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
