import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Brain, Waves, Activity, Eye, Smile, Frown, Meh, Users } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';

interface EmotionState {
  primary: string;
  intensity: number;
  secondary: string[];
  bioRhythm: number;
  empathyScore: number;
}

interface EmpathySyncProps {
  isActive: boolean;
  userText?: string;
  onEmpathyMatch: (emotion: EmotionState, recommendations: string[]) => void;
}

export function NeuralEmpathySync({ isActive, userText, onEmpathyMatch }: EmpathySyncProps) {
  const [currentEmotion, setCurrentEmotion] = useState<EmotionState>({
    primary: 'neutral',
    intensity: 50,
    secondary: [],
    bioRhythm: 75,
    empathyScore: 0
  });
  
  const [syncingStage, setSyncingStage] = useState('idle');
  const [brainwaveActivity, setBrainwaveActivity] = useState(0);
  const [emotionalResonance, setEmotionalResonance] = useState(0);
  const [empathicConnection, setEmpathicConnection] = useState(0);
  const [culturalAlignment, setCulturalAlignment] = useState(0);

  const emotions = {
    joy: { icon: Smile, color: '#22C55E', description: 'Joyful and optimistic' },
    sadness: { icon: Frown, color: '#3B82F6', description: 'Reflective and contemplative' },
    excitement: { icon: Activity, color: '#F59E0B', description: 'Energetic and enthusiastic' },
    anxiety: { icon: Waves, color: '#EF4444', description: 'Concerned and seeking reassurance' },
    curiosity: { icon: Eye, color: '#8B5CF6', description: 'Inquisitive and engaged' },
    neutral: { icon: Meh, color: '#6B7280', description: 'Balanced and receptive' },
    compassionate: { icon: Heart, color: '#EC4899', description: 'Empathetic and caring' }
  };

  useEffect(() => {
    if (isActive) {
      startEmpathySync();
    }
  }, [isActive, userText]);

  const startEmpathySync = async () => {
    setSyncingStage('analyzing');
    
    // Stage 1: Brainwave Analysis
    for (let i = 0; i <= 100; i += 3) {
      setBrainwaveActivity(i);
      await new Promise(resolve => setTimeout(resolve, 20));
    }

    // Stage 2: Emotional Resonance Detection
    setSyncingStage('resonating');
    for (let i = 0; i <= 100; i += 4) {
      setEmotionalResonance(i);
      await new Promise(resolve => setTimeout(resolve, 25));
    }

    // Stage 3: Empathic Connection Establishment
    setSyncingStage('connecting');
    for (let i = 0; i <= 100; i += 5) {
      setEmpathicConnection(i);
      await new Promise(resolve => setTimeout(resolve, 15));
    }

    // Stage 4: Cultural Alignment
    setSyncingStage('aligning');
    for (let i = 0; i <= 100; i += 6) {
      setCulturalAlignment(i);
      await new Promise(resolve => setTimeout(resolve, 12));
    }

    // Generate emotion state
    const detectedEmotion = analyzeEmotionalState(userText || '');
    setCurrentEmotion(detectedEmotion);
    
    // Generate empathy-based recommendations
    const recommendations = generateEmpathyRecommendations(detectedEmotion);
    
    setSyncingStage('synchronized');
    onEmpathyMatch(detectedEmotion, recommendations);

    // Reset after a delay
    setTimeout(() => {
      setSyncingStage('idle');
      setBrainwaveActivity(0);
      setEmotionalResonance(0);
      setEmpathicConnection(0);
      setCulturalAlignment(0);
    }, 4000);
  };

  const analyzeEmotionalState = (text: string): EmotionState => {
    // Simulate advanced emotional analysis
    const emotionKeys = Object.keys(emotions);
    const primaryEmotion = emotionKeys[Math.floor(Math.random() * emotionKeys.length)];
    
    // Determine secondary emotions
    const secondary = emotionKeys
      .filter(e => e !== primaryEmotion)
      .slice(0, 2 + Math.floor(Math.random() * 2));

    return {
      primary: primaryEmotion,
      intensity: 60 + Math.random() * 40,
      secondary,
      bioRhythm: 70 + Math.random() * 30,
      empathyScore: 85 + Math.random() * 15
    };
  };

  const generateEmpathyRecommendations = (emotion: EmotionState): string[] => {
    const recommendations = {
      joy: [
        "🌟 Match their enthusiasm with upbeat language",
        "🎉 Use celebration and positive reinforcement",
        "✨ Share in their excitement and energy"
      ],
      sadness: [
        "💙 Use gentle, supportive tone",
        "🤗 Offer comfort and understanding", 
        "🌱 Focus on hope and gradual progress"
      ],
      excitement: [
        "⚡ Match their energy level",
        "🚀 Use dynamic and action-oriented language",
        "🎯 Channel excitement into productive direction"
      ],
      anxiety: [
        "🕊️ Use calm, reassuring tone",
        "🌊 Provide step-by-step guidance",
        "💜 Emphasize safety and support"
      ],
      curiosity: [
        "🔍 Encourage exploration",
        "📚 Provide detailed explanations",
        "🌟 Feed their hunger for knowledge"
      ],
      neutral: [
        "⚖️ Maintain balanced communication",
        "🎯 Be clear and direct",
        "🌿 Allow space for their natural flow"
      ],
      compassionate: [
        "❤️ Acknowledge their caring nature",
        "🤝 Create collaborative atmosphere",
        "🌍 Appeal to their desire to help others"
      ]
    };

    return recommendations[emotion.primary as keyof typeof recommendations] || recommendations.neutral;
  };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50"
    >
      <Card className="w-[480px] bg-gradient-to-br from-rose-900/90 to-purple-900/90 text-white border-rose-500/50 shadow-2xl">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 3, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-rose-500 to-purple-500 rounded-full flex items-center justify-center"
            >
              <Brain className="w-8 h-8" />
            </motion.div>
            <h3 className="text-xl font-bold bg-gradient-to-r from-rose-300 to-purple-300 bg-clip-text text-transparent">
              Neural Empathy Synchronization
            </h3>
            <p className="text-sm text-rose-200">
              Establishing emotional resonance connection
            </p>
          </div>

          {syncingStage !== 'idle' && syncingStage !== 'synchronized' && (
            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between">
                <span className="text-sm">Brainwave Analysis</span>
                <span className="text-xs text-rose-300">{brainwaveActivity}%</span>
              </div>
              <Progress value={brainwaveActivity} className="h-2" />

              <div className="flex items-center justify-between">
                <span className="text-sm">Emotional Resonance</span>
                <span className="text-xs text-rose-300">{emotionalResonance}%</span>
              </div>
              <Progress value={emotionalResonance} className="h-2" />

              <div className="flex items-center justify-between">  
                <span className="text-sm">Empathic Connection</span>
                <span className="text-xs text-rose-300">{empathicConnection}%</span>
              </div>
              <Progress value={empathicConnection} className="h-2" />

              <div className="flex items-center justify-between">
                <span className="text-sm">Cultural Alignment</span>
                <span className="text-xs text-rose-300">{culturalAlignment}%</span>
              </div>
              <Progress value={culturalAlignment} className="h-2" />
            </div>
          )}

          <AnimatePresence>
            {syncingStage === 'synchronized' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
              >
                {/* Detected Emotion */}
                <div className="p-4 bg-gradient-to-r from-rose-500/20 to-purple-500/20 rounded-lg border border-rose-500/30">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center`}
                         style={{ backgroundColor: emotions[currentEmotion.primary as keyof typeof emotions]?.color + '40' }}>
                      {(() => {
                        const EmotionIcon = emotions[currentEmotion.primary as keyof typeof emotions]?.icon || Meh;
                        return <EmotionIcon className="w-5 h-5" style={{ color: emotions[currentEmotion.primary as keyof typeof emotions]?.color }} />;
                      })()}
                    </div>
                    <div>
                      <h4 className="font-medium capitalize">{currentEmotion.primary} State Detected</h4>
                      <p className="text-xs text-rose-200">
                        {emotions[currentEmotion.primary as keyof typeof emotions]?.description}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-rose-300">Intensity:</span>
                      <div className="mt-1">
                        <Progress value={currentEmotion.intensity} className="h-1" />
                      </div>
                    </div>
                    <div>
                      <span className="text-rose-300">Bio-Rhythm:</span>
                      <div className="mt-1">
                        <Progress value={currentEmotion.bioRhythm} className="h-1" />
                      </div>
                    </div>
                  </div>

                  {currentEmotion.secondary.length > 0 && (
                    <div className="mt-3">
                      <span className="text-xs text-rose-300">Secondary Emotions:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {currentEmotion.secondary.map((emotion, index) => (
                          <Badge key={index} variant="outline" className="text-xs border-rose-400/50 text-rose-200">
                            {emotion}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Empathy Score */}
                <div className="flex items-center justify-center space-x-2 p-3 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg">
                  <Users className="w-5 h-5 text-green-400" />
                  <span className="text-green-400 font-medium">
                    Empathy Score: {currentEmotion.empathyScore.toFixed(1)}%
                  </span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Neural Activity Visualization */}
          <div className="mt-6 flex justify-center">
            <div className="flex space-x-1">
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  animate={{ 
                    scaleY: [0.3, 1.5, 0.8, 1.2, 0.3],
                    opacity: [0.4, 1, 0.6, 1, 0.4]
                  }}
                  transition={{ 
                    duration: 2,
                    repeat: Infinity,
                    delay: i * 0.1,
                    ease: "easeInOut"
                  }}
                  className="w-1 h-8 bg-gradient-to-t from-rose-500 to-purple-400 rounded-full"
                />
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}