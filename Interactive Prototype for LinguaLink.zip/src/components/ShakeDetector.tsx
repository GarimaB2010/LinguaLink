import { useEffect } from "react";

interface ShakeDetectorProps {
  onShake: () => void;
  threshold?: number;
}

export function ShakeDetector({ onShake, threshold = 15 }: ShakeDetectorProps) {
  useEffect(() => {
    let lastX = 0;
    let lastY = 0;
    let lastZ = 0;
    let lastTime = 0;

    const handleMotion = (event: DeviceMotionEvent) => {
      const acceleration = event.accelerationIncludingGravity;
      if (!acceleration) return;

      const currentTime = new Date().getTime();
      
      if (currentTime - lastTime > 100) {
        const timeDiff = currentTime - lastTime;
        lastTime = currentTime;

        const x = acceleration.x || 0;
        const y = acceleration.y || 0;
        const z = acceleration.z || 0;

        const speed = Math.abs(x + y + z - lastX - lastY - lastZ) / timeDiff * 10000;

        if (speed > threshold) {
          onShake();
        }

        lastX = x;
        lastY = y;
        lastZ = z;
      }
    };

    // Request permission for iOS devices
    if (typeof (DeviceMotionEvent as any).requestPermission === 'function') {
      (DeviceMotionEvent as any).requestPermission()
        .then((permissionState: string) => {
          if (permissionState === 'granted') {
            window.addEventListener('devicemotion', handleMotion);
          }
        })
        .catch(console.error);
    } else {
      // Non-iOS devices
      window.addEventListener('devicemotion', handleMotion);
    }

    return () => {
      window.removeEventListener('devicemotion', handleMotion);
    };
  }, [onShake, threshold]);

  return null;
}
