import { motion } from "motion/react";
import { useEffect, useState } from "react";

const EMOJIS = ['🌟', '✨', '💫', '🎉', '🎊', '🔥', '💖', '🌈', '🚀', '⚡', '🎯', '🏆', '💝', '🌺', '🎀'];

interface FloatingEmoji {
  id: number;
  emoji: string;
  x: number;
  y: number;
  delay: number;
  duration: number;
}

export function FloatingEmojis() {
  const [emojis, setEmojis] = useState<FloatingEmoji[]>([]);

  useEffect(() => {
    const generateEmojis = () => {
      const newEmojis: FloatingEmoji[] = [];
      for (let i = 0; i < 8; i++) {
        newEmojis.push({
          id: i,
          emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
          x: Math.random() * 100,
          y: Math.random() * 100,
          delay: Math.random() * 5,
          duration: 3 + Math.random() * 4
        });
      }
      setEmojis(newEmojis);
    };

    generateEmojis();
    const interval = setInterval(generateEmojis, 8000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {emojis.map((emoji) => (
        <motion.div
          key={emoji.id}
          className="absolute text-2xl opacity-20"
          style={{
            left: `${emoji.x}%`,
            top: `${emoji.y}%`,
          }}
          animate={{
            y: [0, -100, 0],
            rotate: [0, 360],
            scale: [0.5, 1.2, 0.5],
            opacity: [0, 0.3, 0],
          }}
          transition={{
            duration: emoji.duration,
            delay: emoji.delay,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          {emoji.emoji}
        </motion.div>
      ))}
    </div>
  );
}