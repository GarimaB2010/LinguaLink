import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send, Mic, MicOff, Volume2, Bot, User, Lightbulb, HelpCircle, Settings, Camera, Languages, Accessibility, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type?: 'text' | 'quick-reply' | 'tutorial';
}

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  settings: any;
}

const QUICK_REPLIES = [
  { text: "Revolutionary AI features", icon: Sparkles, category: "✨ Hot" },
  { text: "How do I use speech recognition?", icon: Mic, category: "🎤 Voice" },
  { text: "Camera not working", icon: Camera, category: "📹 Camera" },
  { text: "Change language settings", icon: Languages, category: "🌍 Language" },
  { text: "Accessibility features", icon: Accessibility, category: "♿ Access" },
  { text: "Sign language help", icon: HelpCircle, category: "🤟 Sign" }
];

const KNOWLEDGE_BASE = {
  // Speech Recognition Help
  "speech recognition": {
    answer: "🎤 **Speech Recognition Setup:**\n\n1. **Grant microphone permission** when prompted\n2. Click the microphone button in Conversation mode\n3. Speak clearly into your device's microphone\n4. Your speech will appear as text automatically\n\n**Troubleshooting:**\n• Check browser permissions in settings\n• Ensure microphone is not muted\n• Try refreshing the page\n• Use Chrome/Edge for best results",
    quickActions: ["Test microphone", "Check permissions", "Speech settings"]
  },
  
  "camera": {
    answer: "📹 **Camera & Sign Language:**\n\n1. **Grant camera permission** when prompted\n2. Go to Conversation → Sign Language mode\n3. Position yourself in good lighting\n4. Keep hands visible in the camera frame\n\n**Camera Issues:**\n• Check browser camera permissions\n• Ensure no other apps are using camera\n• Try different lighting conditions\n• Refresh page and try again",
    quickActions: ["Test camera", "Sign language tutorial", "Camera settings"]
  },
  
  "audio": {
    answer: "🔊 **Audio & Text-to-Speech:**\n\n1. **Enable audio permission** if needed\n2. Use the speaker button to hear text\n3. Adjust voice speed in Settings\n4. Choose different voice types\n\n**Audio Problems:**\n• Check device volume settings\n• Ensure speakers/headphones work\n• Try different voice options\n• Check browser audio permissions",
    quickActions: ["Test audio", "Voice settings", "Audio troubleshooting"]
  },
  
  "language": {
    answer: "🌍 **Language & Translation:**\n\n**Supported Features:**\n• Real-time speech translation\n• Text simplification (multiple levels)\n• 50+ language support\n• Cultural context awareness\n\n**Change Language:**\n1. Go to Settings ⚙️\n2. Select 'Preferred Language'\n3. Choose from available options\n4. Changes apply immediately",
    quickActions: ["Language settings", "Translation demo", "Supported languages"]
  },
  
  "accessibility": {
    answer: "♿ **Accessibility Features:**\n\n**Visual:**\n• Large text sizing (up to 200%)\n• Color blind friendly mode\n• High contrast dark theme\n• Screen reader support\n\n**Motor:**\n• Voice commands\n• Large touch targets\n• Keyboard navigation\n• Haptic feedback\n\n**Cognitive:**\n• Text simplification\n• Easy mode interface\n• Visual cues and icons\n• Step-by-step guidance",
    quickActions: ["Accessibility settings", "Screen reader test", "Easy mode"]
  },
  
  "sign language": {
    answer: "🤟 **Sign Language Recognition:**\n\n**How it works:**\n1. Uses AI to detect hand gestures\n2. Converts signs to text instantly\n3. Supports ASL (American Sign Language)\n4. Real-time confidence scoring\n\n**Tips for better recognition:**\n• Use good lighting\n• Keep hands in camera frame\n• Sign at normal speed\n• Face the camera directly\n\n**Current supported signs:**\nBasic alphabet, common words, and phrases",
    quickActions: ["Start signing", "ASL tutorial", "Practice mode"]
  },
  
  "permissions": {
    answer: "🔒 **Browser Permissions:**\n\n**Required permissions:**\n• 🎤 Microphone: For speech recognition\n• 📹 Camera: For sign language detection\n• 🔊 Audio: For text-to-speech playback\n\n**How to grant permissions:**\n1. Look for permission popup when using features\n2. Click 'Allow' or 'Grant'\n3. If blocked: Click lock icon in address bar\n4. Enable Camera/Microphone permissions\n5. Refresh the page\n\n**Privacy:** All processing happens locally in your browser. No data is sent to servers.",
    quickActions: ["Check permissions", "Reset permissions", "Privacy policy"]
  }
};

export function LinguaLinkChatbot({ isOpen, onClose, settings }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [chatMode, setChatMode] = useState<'help' | 'features' | 'troubleshooting'>('help');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      // Enhanced welcome message
      const welcomeMessage: Message = {
        id: Date.now().toString(),
        text: "🌟 **Welcome to LinguaLink AI Assistant!** 🌟\n\nI'm Lingua, your personal communication expert! I'm here to help you unlock the full potential of LinguaLink.\n\n**🚀 What I can help you with:**\n\n🎤 **Speech & Voice**\n• Setup speech recognition\n• Fix microphone issues\n• Voice settings & preferences\n\n📹 **Camera & Sign Language**\n• Camera troubleshooting\n• Sign language calibration\n• Visual accessibility features\n\n🌍 **Languages & Translation**\n• Add new languages\n• Translation accuracy\n• Cultural communication tips\n\n♿ **Accessibility**\n• Screen reader compatibility\n• Motor accessibility features\n• Cognitive assistance tools\n\n🔧 **Technical Support**\n• Browser compatibility\n• Permission settings\n• Performance optimization\n\n**✨ Plus the revolutionary new AI features!**\n\nWhat would you like to explore first? Just ask me anything! 😊",
        sender: 'bot',
        timestamp: new Date(),
        type: 'text'
      };
      setMessages([welcomeMessage]);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initialize speech recognition for chatbot
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const handleVoiceInput = () => {
    if (!recognitionRef.current) return;

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  const generateBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    // Revolutionary features questions
    if (message.includes('revolutionary') || message.includes('quantum') || message.includes('neural') || message.includes('empathy') || message.includes('holographic')) {
      return "🚀 **Revolutionary AI Features!** 🚀\n\nYou've discovered our cutting-edge technology! Here's what makes LinguaLink truly revolutionary:\n\n🧠 **Quantum Translation Engine**\n• Multi-dimensional linguistic processing\n• 99.7% accuracy with cultural context\n• Real-time emotional resonance matching\n\n💖 **Neural Empathy Synchronization**\n• Detects emotional state through bio-signals\n• Adapts communication style automatically\n• Creates empathetic connections between users\n\n✨ **Holographic Gesture Interface**\n• 3D spatial interaction system\n• Gesture recognition in virtual space\n• Next-generation accessibility controls\n\n🧬 **Bio-Rhythmic Communication Matching**\n• Analyzes circadian rhythms and stress levels\n• Optimizes timing for conversations\n• Personalizes interaction based on energy levels\n\n🌉 **Cultural Dimension Bridge**\n• Maps cultural communication patterns\n• Bridges cultural gaps automatically\n• Provides context-aware cultural tips\n\n⚡ **Synaptic Learning Assistant**\n• AI that evolves with each conversation\n• Learns your unique communication style\n• Optimizes interface for your preferences\n\nThese features are **never-before-seen** in any communication platform! Want to try one? Just go to the Conversation page and click any of the revolutionary feature buttons! 🎯";
    }
    
    // Check knowledge base
    for (const [keyword, data] of Object.entries(KNOWLEDGE_BASE)) {
      if (message.includes(keyword) || message.includes(keyword.replace(' ', ''))) {
        return data.answer;
      }
    }

    // Common greetings
    if (message.match(/\b(hi|hello|hey|help)\b/)) {
      return "Hello there! 👋 I'm absolutely thrilled to help you master LinguaLink! \n\n🌟 **Popular Topics:**\n• 🎤 Speech recognition mastery\n• 📹 Camera & sign language magic\n• 🔊 Crystal-clear audio setup\n• 🌍 Global language support\n• ♿ Accessibility superpowers\n• 🚀 **Revolutionary AI features** ⭐\n\nWhat amazing feature would you like to explore first? I'm here to make your LinguaLink experience absolutely phenomenal! ✨";
    }

    // Microphone issues
    if (message.includes('microphone') || message.includes('mic')) {
      return KNOWLEDGE_BASE['speech recognition'].answer;
    }

    // Camera issues
    if (message.includes('camera') || message.includes('video')) {
      return KNOWLEDGE_BASE['camera'].answer;
    }

    // Audio issues
    if (message.includes('audio') || message.includes('sound') || message.includes('speaker')) {
      return KNOWLEDGE_BASE['audio'].answer;
    }

    // Translation
    if (message.includes('translate') || message.includes('language')) {
      return KNOWLEDGE_BASE['language'].answer;
    }

    // Sign language
    if (message.includes('sign') || message.includes('gesture') || message.includes('asl')) {
      return KNOWLEDGE_BASE['sign language'].answer;
    }

    // Accessibility
    if (message.includes('accessibility') || message.includes('vision') || message.includes('hearing')) {
      return KNOWLEDGE_BASE['accessibility'].answer;
    }

    // Permissions
    if (message.includes('permission') || message.includes('allow') || message.includes('block')) {
      return KNOWLEDGE_BASE['permissions'].answer;
    }

    // Troubleshooting
    if (message.includes('not working') || message.includes('broken') || message.includes('error')) {
      return "🔧 **Troubleshooting Steps:**\n\n1. **Refresh the page** - This fixes most issues\n2. **Check permissions** - Ensure camera/mic access is granted\n3. **Update browser** - Use latest Chrome/Edge for best support\n4. **Clear cache** - Go to browser settings → Clear browsing data\n5. **Try incognito mode** - Rules out extension conflicts\n\nIf issues persist, please describe exactly what's not working and I'll provide specific help!";
    }

    // Default helpful response with more personality
    return "🌟 **Great question!** I'm constantly learning to help you better! \n\nHere are some **hot topics** I'm absolutely fantastic at helping with:\n\n🔥 **Most Popular:**\n• **\"Revolutionary AI features\"** ⚡ (Our newest & coolest!)\n• **\"How do I use speech recognition?\"** 🎤\n• **\"Camera not working\"** 📹\n• **\"Change language settings\"** 🌍\n• **\"Audio issues\"** 🔊\n• **\"Sign language help\"** 🤟\n• **\"Accessibility features\"** ♿\n\n💡 **Pro Tip:** Try the quick reply buttons below for instant help, or ask me about our **revolutionary new AI features** - they're absolutely mind-blowing! 🚀\n\nI'm here to make your LinguaLink experience amazing! What sounds most interesting to you? 😊✨";
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: generateBotResponse(inputText),
        sender: 'bot',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleQuickReply = (text: string) => {
    setInputText(text);
    setTimeout(() => handleSendMessage(), 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, y: 100 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.8, y: 100 }}
      className="fixed bottom-20 right-4 z-50 w-96 h-[600px] max-h-[80vh] flex flex-col"
    >
      <Card className="h-full shadow-2xl border-2 border-gradient-to-r from-purple-500/30 to-blue-500/30 bg-gradient-to-b from-white via-purple-50/50 to-blue-50/50 backdrop-blur-sm flex flex-col overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 text-white rounded-t-lg p-4 relative overflow-hidden flex-shrink-0">
          {/* Animated background particles */}
          <div className="absolute inset-0">
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                animate={{
                  x: [0, 30, 0],
                  y: [0, -20, 0],
                  opacity: [0.3, 0.6, 0.3]
                }}
                transition={{
                  duration: 3 + i,
                  repeat: Infinity,
                  delay: i * 0.5
                }}
                className="absolute w-2 h-2 bg-white/20 rounded-full"
                style={{
                  left: `${10 + i * 15}%`,
                  top: `${20 + (i % 2) * 40}%`
                }}
              />
            ))}
          </div>
          
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ 
                  rotate: [0, 360],
                  scale: [1, 1.1, 1]
                }}
                transition={{ 
                  duration: 4, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="w-10 h-10 bg-gradient-to-r from-yellow-400/30 to-white/30 rounded-full flex items-center justify-center border-2 border-white/40"
              >
                <Bot className="w-6 h-6" />
              </motion.div>
              <div>
                <h3 className="font-bold text-lg">Lingua AI ✨</h3>
                <motion.p 
                  animate={{ opacity: [0.7, 1, 0.7] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="text-xs text-white/90"
                >
                  Your revolutionary communication guide! 🚀
                </motion.p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:bg-white/20"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-0 flex-1 flex flex-col overflow-hidden">
          {/* Messages */}
          <ScrollArea className="flex-1 p-4 overflow-y-auto">
            <div className="space-y-4 pb-4">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex items-start space-x-2 max-w-[80%]`}>
                    {message.sender === 'bot' && (
                      <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-white text-xs">
                        <Bot className="w-3 h-3" />
                      </div>
                    )}
                    <div
                      className={`p-3 rounded-lg ${
                        message.sender === 'user'
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                      <p className="text-xs opacity-60 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                    {message.sender === 'user' && (
                      <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center text-white text-xs">
                        <User className="w-3 h-3" />
                      </div>
                    )}
                  </div>
                </motion.div>
              ))}

              {isTyping && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex items-center space-x-2"
                >
                  <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-white text-xs">
                    <Bot className="w-3 h-3" />
                  </div>
                  <div className="bg-muted p-3 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
            <div ref={messagesEndRef} />
          </ScrollArea>

          {/* Enhanced Quick Replies */}
          <div className="p-4 border-t bg-gradient-to-r from-purple-50/30 to-blue-50/30 flex-shrink-0">
            <div className="text-xs text-purple-600 font-medium mb-3 text-center">
              🚀 Quick Actions • Click any topic below!
            </div>
            <div className="grid grid-cols-2 gap-2 mb-3">
              {QUICK_REPLIES.slice(0, 6).map((reply, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.02, y: -1 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Badge
                    variant="outline"
                    className={`cursor-pointer hover:bg-gradient-to-r ${
                      index === 0 
                        ? 'hover:from-yellow-400 hover:to-orange-500 border-yellow-400/50 text-yellow-700' 
                        : 'hover:from-purple-500 hover:to-blue-500 hover:text-white'
                    } transition-all duration-200 text-xs w-full justify-start p-2 ${
                      index === 0 ? 'animate-pulse border-2' : ''
                    }`}
                    onClick={() => handleQuickReply(reply.text)}
                  >
                    <reply.icon className="w-3 h-3 mr-1 flex-shrink-0" />
                    <div className="text-left overflow-hidden">
                      <div className="text-xs font-medium truncate">{reply.category}</div>
                      <div className="text-xs opacity-80 truncate">{reply.text.slice(0, 20)}...</div>
                    </div>
                  </Badge>
                </motion.div>
              ))}
            </div>
            
            <div className="text-center">
              <motion.div
                animate={{ opacity: [0.6, 1, 0.6] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-xs text-purple-500"
              >
                💡 Try asking about "revolutionary features" for something amazing!
              </motion.div>
            </div>
          </div>

          {/* Input */}
          <div className="p-4 border-t bg-gradient-to-r from-purple-50/50 to-blue-50/50 backdrop-blur-sm flex-shrink-0">
            <div className="flex items-center space-x-2">
              <div className="flex-1 relative">
                <Input
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me anything about LinguaLink's amazing features! ✨"
                  className="pr-12 border-2 border-purple-200/50 focus:border-purple-500/50 bg-white/80"
                />
                <motion.div
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleVoiceInput}
                    className={`absolute right-1 top-1/2 transform -translate-y-1/2 w-8 h-8 p-0 ${
                      isListening ? 'text-red-500 animate-pulse' : 'text-purple-500'
                    }`}
                  >
                    {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  </Button>
                </motion.div>
              </div>
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button 
                  onClick={handleSendMessage} 
                  disabled={!inputText.trim() || isTyping}
                  className="bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </motion.div>
            </div>
            <motion.p 
              animate={{ opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="text-xs text-purple-600/80 mt-2 text-center"
            >
              💡 Try voice input, quick replies, or ask about revolutionary features! 🚀
            </motion.p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}