import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Volume2, VolumeX, Pause, Play, AlertCircle, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Slider } from "./ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Alert, AlertDescription } from "./ui/alert";
import { InteractiveWaveform } from "./InteractiveWaveform";

interface RealTextToSpeechProps {
  text: string;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (error: string) => void;
  autoPlay?: boolean;
}

export function RealTextToSpeech({ text, onStart, onEnd, onError, autoPlay = false }: RealTextToSpeechProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [rate, setRate] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [volume, setVolume] = useState(1);
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isSupported, setIsSupported] = useState(true);
  const [audioError, setAudioError] = useState<string | null>(null);

  // Load available voices
  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = speechSynthesis.getVoices();
      setVoices(availableVoices);
      
      // Set default voice (prefer female English voice)
      const defaultVoice = availableVoices.find(voice => 
        voice.lang.startsWith('en') && voice.name.toLowerCase().includes('female')
      ) || availableVoices.find(voice => voice.lang.startsWith('en')) || availableVoices[0];
      
      setSelectedVoice(defaultVoice);
    };

    loadVoices();
    speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  // Auto-play when text changes
  useEffect(() => {
    if (autoPlay && text && selectedVoice) {
      speak();
    }
  }, [text, autoPlay, selectedVoice]);

  const speak = () => {
    if (!text.trim()) {
      onError?.('No text to speak');
      return;
    }

    // Stop any ongoing speech
    speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.voice = selectedVoice;
    utterance.rate = rate;
    utterance.pitch = pitch;
    utterance.volume = volume;

    utterance.onstart = () => {
      setIsSpeaking(true);
      setIsPaused(false);
      onStart?.();
    };

    utterance.onend = () => {
      setIsSpeaking(false);
      setIsPaused(false);
      onEnd?.();
    };

    utterance.onerror = (event) => {
      setIsSpeaking(false);
      setIsPaused(false);
      onError?.(`Speech synthesis error: ${event.error}`);
    };

    speechSynthesis.speak(utterance);
  };

  const pause = () => {
    if (isSpeaking && !isPaused) {
      speechSynthesis.pause();
      setIsPaused(true);
    }
  };

  const resume = () => {
    if (isSpeaking && isPaused) {
      speechSynthesis.resume();
      setIsPaused(false);
    }
  };

  const stop = () => {
    speechSynthesis.cancel();
    setIsSpeaking(false);
    setIsPaused(false);
  };

  const togglePlayPause = () => {
    if (!isSpeaking) {
      speak();
    } else if (isPaused) {
      resume();
    } else {
      pause();
    }
  };

  return (
    <div className="space-y-4">
      {/* Main Control */}
      <div className="text-center">
        <motion.button
          onClick={togglePlayPause}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          disabled={!text.trim()}
          className={`w-16 h-16 rounded-full flex items-center justify-center text-white shadow-lg transition-all ${
            !text.trim() 
              ? 'bg-gray-400 cursor-not-allowed'
              : isSpeaking
                ? 'bg-gradient-to-r from-orange-500 to-red-500'
                : 'bg-gradient-to-r from-green-500 to-emerald-500'
          }`}
        >
          {isSpeaking ? (
            isPaused ? <Play className="w-6 h-6" /> : <Pause className="w-6 h-6" />
          ) : (
            <Volume2 className="w-6 h-6" />
          )}
        </motion.button>
        
        <p className="mt-3 text-sm text-muted-foreground">
          {!text.trim() 
            ? '📝 Enter text to speak'
            : isSpeaking 
              ? (isPaused ? '⏸️ Paused - Tap to resume' : '🔊 Speaking - Tap to pause')
              : '🎵 Tap to speak aloud'
          }
        </p>

        {isSpeaking && (
          <motion.button
            onClick={stop}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="mt-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg text-sm"
          >
            <VolumeX className="w-4 h-4 inline mr-1" />
            Stop
          </motion.button>
        )}
      </div>

      {/* Visual Feedback */}
      {isSpeaking && !isPaused && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <InteractiveWaveform isActive={true} className="h-12 mb-4" />
          <div className="text-xs text-muted-foreground">
            🎤 Speaking at {Math.round(rate * 100)}% speed
          </div>
        </motion.div>
      )}

      {/* Advanced Controls */}
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        className="space-y-3 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl border border-purple-200"
      >
        <h4 className="text-sm font-medium text-purple-700">🎛️ Voice Settings</h4>
        
        {/* Voice Selection */}
        <div>
          <label className="text-xs text-muted-foreground block mb-1">Voice</label>
          <Select 
            value={selectedVoice?.name || ''} 
            onValueChange={(name) => {
              const voice = voices.find(v => v.name === name);
              setSelectedVoice(voice || null);
            }}
          >
            <SelectTrigger className="bg-white/50">
              <SelectValue placeholder="Select voice" />
            </SelectTrigger>
            <SelectContent>
              {voices.map((voice) => (
                <SelectItem key={voice.name} value={voice.name}>
                  {voice.name} ({voice.lang}) {voice.gender && `- ${voice.gender}`}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Speed Control */}
        <div>
          <label className="text-xs text-muted-foreground block mb-1">
            Speed: {Math.round(rate * 100)}%
          </label>
          <Slider
            value={[rate]}
            onValueChange={([value]) => setRate(value)}
            min={0.5}
            max={2}
            step={0.1}
            className="w-full"
          />
        </div>

        {/* Pitch Control */}
        <div>
          <label className="text-xs text-muted-foreground block mb-1">
            Pitch: {Math.round(pitch * 100)}%
          </label>
          <Slider
            value={[pitch]}
            onValueChange={([value]) => setPitch(value)}
            min={0.5}
            max={2}
            step={0.1}
            className="w-full"
          />
        </div>

        {/* Volume Control */}
        <div>
          <label className="text-xs text-muted-foreground block mb-1">
            Volume: {Math.round(volume * 100)}%
          </label>
          <Slider
            value={[volume]}
            onValueChange={([value]) => setVolume(value)}
            min={0}
            max={1}
            step={0.1}
            className="w-full"
          />
        </div>
      </motion.div>
    </div>
  );
}