import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Camera, Mic, Shield, AlertCircle, CheckCircle, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { toast } from 'sonner@2.0.3';

interface MediaPermission {
  name: string;
  status: 'granted' | 'denied' | 'prompt' | 'unknown';
  icon: React.ElementType;
  description: string;
  required: boolean;
}

interface MediaPermissionsManagerProps {
  onPermissionsUpdated: (permissions: Record<string, boolean>) => void;
  requiredFeatures?: string[];
}

export function MediaPermissionsManager({ onPermissionsUpdated, requiredFeatures = [] }: MediaPermissionsManagerProps) {
  const [permissions, setPermissions] = useState<MediaPermission[]>([
    {
      name: 'camera',
      status: 'unknown',
      icon: Camera,
      description: 'Required for sign language recognition',
      required: requiredFeatures.includes('camera')
    },
    {
      name: 'microphone',
      status: 'unknown',
      icon: Mic,
      description: 'Required for speech recognition',
      required: requiredFeatures.includes('microphone')
    }
  ]);

  const [isChecking, setIsChecking] = useState(false);
  const [showManager, setShowManager] = useState(false);
  const [supportInfo, setSupportInfo] = useState({
    mediaDevices: false,
    speechRecognition: false,
    speechSynthesis: false,
    permissions: false
  });

  // Check browser support
  useEffect(() => {
    const checkSupport = () => {
      setSupportInfo({
        mediaDevices: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia),
        speechRecognition: !!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window),
        speechSynthesis: !!('speechSynthesis' in window),
        permissions: !!(navigator.permissions && navigator.permissions.query)
      });
    };

    checkSupport();
  }, []);

  // Check permissions on load and when required features change
  useEffect(() => {
    if (requiredFeatures.length > 0) {
      checkAllPermissions();
    }
  }, [requiredFeatures, supportInfo.mediaDevices]);

  const checkAllPermissions = async () => {
    setIsChecking(true);
    
    const updatedPermissions = [...permissions];
    const permissionResults: Record<string, boolean> = {};
    let needsPermissionRequest = false;

    // Check camera permission
    try {
      if (supportInfo.permissions && navigator.permissions) {
        const cameraPermission = await navigator.permissions.query({ name: 'camera' as PermissionName });
        const cameraIndex = updatedPermissions.findIndex(p => p.name === 'camera');
        if (cameraIndex !== -1) {
          updatedPermissions[cameraIndex].status = cameraPermission.state;
          permissionResults.camera = cameraPermission.state === 'granted';
          if (cameraPermission.state === 'prompt' && updatedPermissions[cameraIndex].required) {
            needsPermissionRequest = true;
          }
        }
      } else {
        // Fallback: check if camera is required and set to prompt
        const cameraIndex = updatedPermissions.findIndex(p => p.name === 'camera');
        if (cameraIndex !== -1 && updatedPermissions[cameraIndex].required) {
          updatedPermissions[cameraIndex].status = 'prompt';
          needsPermissionRequest = true;
        }
      }
    } catch (error) {
      console.warn('Camera permission check failed:', error);
      // Try direct access
      const cameraIndex = updatedPermissions.findIndex(p => p.name === 'camera');
      if (cameraIndex !== -1 && updatedPermissions[cameraIndex].required) {
        updatedPermissions[cameraIndex].status = 'prompt';
        needsPermissionRequest = true;
      }
    }

    // Check microphone permission
    try {
      if (supportInfo.permissions && navigator.permissions) {
        const micPermission = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        const micIndex = updatedPermissions.findIndex(p => p.name === 'microphone');
        if (micIndex !== -1) {
          updatedPermissions[micIndex].status = micPermission.state;
          permissionResults.microphone = micPermission.state === 'granted';
          if (micPermission.state === 'prompt' && updatedPermissions[micIndex].required) {
            needsPermissionRequest = true;
          }
        }
      } else {
        // Fallback: check if microphone is required and set to prompt
        const micIndex = updatedPermissions.findIndex(p => p.name === 'microphone');
        if (micIndex !== -1 && updatedPermissions[micIndex].required) {
          updatedPermissions[micIndex].status = 'prompt';
          needsPermissionRequest = true;
        }
      }
    } catch (error) {
      console.warn('Microphone permission check failed:', error);
      // Try direct access
      const micIndex = updatedPermissions.findIndex(p => p.name === 'microphone');
      if (micIndex !== -1 && updatedPermissions[micIndex].required) {
        updatedPermissions[micIndex].status = 'prompt';
        needsPermissionRequest = true;
      }
    }

    setPermissions(updatedPermissions);
    onPermissionsUpdated(permissionResults);
    setIsChecking(false);
    
    // Auto-close if all required permissions are granted
    const allRequiredGranted = updatedPermissions
      .filter(p => p.required)
      .every(p => p.status === 'granted');
    
    if (allRequiredGranted && updatedPermissions.some(p => p.required)) {
      toast.success('🎉 All permissions granted! You\'re all set!', { duration: 3000 });
      setTimeout(() => {
        setShowManager(false);
      }, 1500);
      return;
    }
    
    // Auto-request permissions if needed and in prompt state
    if (needsPermissionRequest && supportInfo.mediaDevices) {
      // Small delay to show the UI first
      setTimeout(() => {
        requestAllPermissions();
      }, 500);
    }
  };

  const requestPermission = async (permissionName: string) => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        toast.error('❌ Media devices not supported in this browser', { duration: 5000 });
        return;
      }

      let stream: MediaStream | null = null;

      if (permissionName === 'camera') {
        stream = await navigator.mediaDevices.getUserMedia({ 
          video: { 
            width: { ideal: 640 }, 
            height: { ideal: 480 }
          } 
        });
      } else if (permissionName === 'microphone') {
        stream = await navigator.mediaDevices.getUserMedia({ 
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
          } 
        });
      }

      if (stream) {
        // Stop the stream immediately - we just needed to get permission
        stream.getTracks().forEach(track => track.stop());
        
        // Update permission status immediately
        const updatedPermissions = permissions.map(p => 
          p.name === permissionName ? { ...p, status: 'granted' as const } : p
        );
        setPermissions(updatedPermissions);
        
        // Show success toast with celebration
        toast.success(`✅ ${permissionName === 'camera' ? '📹 Camera' : '🎤 Microphone'} access granted!`, {
          duration: 3000,
        });
        
        // Re-check all permissions to get the latest status
        setTimeout(() => {
          checkAllPermissions();
        }, 100);
      }
    } catch (error: any) {
      const updatedPermissions = permissions.map(p => 
        p.name === permissionName ? { ...p, status: 'denied' as const } : p
      );
      setPermissions(updatedPermissions);
      
      const errorMessage = error.name === 'NotAllowedError' 
        ? 'Permission denied by user' 
        : error.name === 'NotFoundError'
        ? 'Device not found'
        : 'Permission request failed';
      
      toast.error(`❌ ${permissionName === 'camera' ? 'Camera' : 'Microphone'}: ${errorMessage}`, { duration: 5000 });
      console.error(`${permissionName} permission denied:`, error);
      
      onPermissionsUpdated({ 
        ...permissions.reduce((acc, p) => ({ ...acc, [p.name]: p.status === 'granted' }), {}),
        [permissionName]: false 
      });
    }
  };

  const requestAllPermissions = async () => {
    for (const permission of permissions) {
      if (permission.required && permission.status !== 'granted') {
        await requestPermission(permission.name);
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'granted': return 'bg-green-100 text-green-800';
      case 'denied': return 'bg-red-100 text-red-800';
      case 'prompt': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'granted': return CheckCircle;
      case 'denied': return AlertCircle;
      default: return Shield;
    }
  };

  const hasRequiredPermissions = permissions
    .filter(p => p.required)
    .every(p => p.status === 'granted');

  const hasDeniedPermissions = permissions
    .some(p => p.required && p.status === 'denied');

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
    >
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center"
            >
              <Shield className="w-8 h-8 text-white" />
            </motion.div>
            <CardTitle>Media Permissions Required</CardTitle>
            <p className="text-sm text-muted-foreground">
              LinguaLink needs access to your device features to work properly
            </p>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* Browser Support Check */}
            <Alert className={supportInfo.mediaDevices ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
              <AlertCircle className="w-4 h-4" />
              <AlertDescription>
                {supportInfo.mediaDevices 
                  ? '✅ Your browser supports media features' 
                  : '❌ Your browser may not support all features. Please use Chrome, Edge, or Safari.'
                }
              </AlertDescription>
            </Alert>

            {/* Permissions List */}
            <div className="space-y-3">
              {permissions.map((permission) => {
                const StatusIcon = getStatusIcon(permission.status);
                return (
                  <div key={permission.name} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <permission.icon className="w-5 h-5 text-muted-foreground" />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium capitalize">{permission.name}</span>
                          {permission.required && (
                            <Badge variant="secondary" className="text-xs">Required</Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">{permission.description}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(permission.status)}>
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {permission.status}
                      </Badge>
                      
                      {permission.status !== 'granted' && permission.required && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => requestPermission(permission.name)}
                          className="text-xs"
                        >
                          Grant
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Actions */}
            <Separator />
            
            <div className="space-y-2">
              {!hasRequiredPermissions && (
                <Button
                  onClick={requestAllPermissions}
                  className="w-full bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
                  disabled={isChecking}
                >
                  {isChecking ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Checking...
                    </>
                  ) : (
                    <>
                      <Shield className="w-4 h-4 mr-2" />
                      Grant All Required Permissions
                    </>
                  )}
                </Button>
              )}

              {hasDeniedPermissions && (
                <Alert className="border-yellow-200 bg-yellow-50">
                  <AlertCircle className="w-4 h-4" />
                  <AlertDescription className="text-sm">
                    Some permissions were denied. You can grant them manually by:
                    <br />1. Clicking the lock icon in your address bar
                    <br />2. Enabling Camera/Microphone permissions
                    <br />3. Refreshing this page
                  </AlertDescription>
                </Alert>
              )}

              <Button
                variant="outline"
                onClick={() => {
                  setShowManager(false);
                  toast.info('ℹ️ You can enable permissions later from browser settings', { duration: 4000 });
                }}
                className="w-full"
              >
                {hasRequiredPermissions ? 'Continue' : 'Skip for Now'}
              </Button>
            </div>

            <div className="text-xs text-center text-muted-foreground">
              🔒 Your privacy is protected. All processing happens locally in your browser.
            </div>
          </CardContent>
        </Card>
      </motion.div>
  );
}