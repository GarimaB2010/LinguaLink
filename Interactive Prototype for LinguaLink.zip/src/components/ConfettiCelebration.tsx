import { motion, AnimatePresence } from "motion/react";
import { useEffect, useState } from "react";

interface ConfettiCelebrationProps {
  trigger: boolean;
  onComplete?: () => void;
}

export function ConfettiCelebration({ trigger, onComplete }: ConfettiCelebrationProps) {
  const [show, setShow] = useState(false);
  const [confetti, setConfetti] = useState<Array<{ id: number; x: number; y: number; color: string; emoji: string }>>([]);

  useEffect(() => {
    if (trigger) {
      setShow(true);
      
      // Generate confetti particles
      const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#FFD93D', '#6BCF7F'];
      const emojis = ['🎉', '✨', '🌟', '💫', '⭐', '🎊', '🎈', '💝', '🎁', '🌈'];
      
      const newConfetti = Array.from({ length: 30 }, (_, i) => ({
        id: i,
        x: Math.random() * window.innerWidth,
        y: -50,
        color: colors[Math.floor(Math.random() * colors.length)],
        emoji: emojis[Math.floor(Math.random() * emojis.length)]
      }));
      
      setConfetti(newConfetti);
      
      // Auto-hide after animation
      const timer = setTimeout(() => {
        setShow(false);
        setConfetti([]);
        if (onComplete) onComplete();
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [trigger, onComplete]);

  return (
    <AnimatePresence>
      {show && (
        <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
          {confetti.map((piece) => (
            <motion.div
              key={piece.id}
              className="absolute text-2xl"
              initial={{
                x: piece.x,
                y: piece.y,
                rotate: 0,
                scale: 0
              }}
              animate={{
                y: window.innerHeight + 100,
                x: piece.x + (Math.random() - 0.5) * 200,
                rotate: Math.random() * 720,
                scale: [0, 1, 1, 0.8]
              }}
              exit={{
                opacity: 0,
                scale: 0
              }}
              transition={{
                duration: 2 + Math.random() * 2,
                ease: "easeOut"
              }}
            >
              {piece.emoji}
            </motion.div>
          ))}
        </div>
      )}
    </AnimatePresence>
  );
}
