import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Mic, Settings, RefreshCw, Chrome, Globe, Monitor, X, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface PermissionGuideProps {
  isOpen: boolean;
  onClose: () => void;
  missingPermissions: {
    camera: boolean;
    microphone: boolean;
  };
  onRetry: () => void;
}

export function PermissionGuide({ isOpen, onClose, missingPermissions, onRetry }: PermissionGuideProps) {
  const [currentStep, setCurrentStep] = useState(0);

  const getBrowserName = () => {
    const userAgent = navigator.userAgent;
    if (userAgent.includes('Chrome')) return 'Chrome';
    if (userAgent.includes('Firefox')) return 'Firefox';
    if (userAgent.includes('Safari')) return 'Safari';
    return 'Browser';
  };

  const getBrowserIcon = (browser: string) => {
    switch (browser) {
      case 'Chrome':
        return Chrome;
      case 'Firefox':
        return Globe; // Using Globe as Firefox alternative
      case 'Safari':
        return Monitor; // Using Monitor as Safari alternative
      default:
        return Globe;
    }
  };

  const browser = getBrowserName();

  const steps = [
    {
      title: "Grant Permissions",
      description: "Allow LinguaLink to access your camera and microphone",
      icon: Settings,
      content: (
        <div className="space-y-4">
          <div className="text-center">
            <div className="text-6xl mb-4">🔒</div>
            <h3 className="text-lg font-semibold mb-2">Permission Required</h3>
            <p className="text-sm text-muted-foreground">
              LinguaLink needs camera and microphone access to enable our revolutionary AI features!
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {!missingPermissions.microphone && (
              <div className="flex items-center space-x-2 p-3 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <div className="text-sm font-medium text-green-800">Microphone</div>
                  <div className="text-xs text-green-600">✅ Enabled</div>
                </div>
              </div>
            )}
            
            {missingPermissions.microphone && (
              <div className="flex items-center space-x-2 p-3 bg-red-50 rounded-lg border border-red-200">
                <Mic className="w-5 h-5 text-red-600" />
                <div>
                  <div className="text-sm font-medium text-red-800">Microphone</div>
                  <div className="text-xs text-red-600">❌ Blocked</div>
                </div>
              </div>
            )}
            
            {!missingPermissions.camera && (
              <div className="flex items-center space-x-2 p-3 bg-green-50 rounded-lg border border-green-200">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <div className="text-sm font-medium text-green-800">Camera</div>
                  <div className="text-xs text-green-600">✅ Enabled</div>
                </div>
              </div>
            )}
            
            {missingPermissions.camera && (
              <div className="flex items-center space-x-2 p-3 bg-red-50 rounded-lg border border-red-200">
                <Camera className="w-5 h-5 text-red-600" />
                <div>
                  <div className="text-sm font-medium text-red-800">Camera</div>
                  <div className="text-xs text-red-600">❌ Blocked</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )
    },
    {
      title: "Browser Instructions",
      description: `How to enable permissions in ${browser}`,
      icon: getBrowserIcon(browser),
      content: (
        <div className="space-y-4">
          <div className="text-center mb-4">
            <div className="text-5xl mb-2">
              {browser === 'Chrome' && '🌐'}
              {browser === 'Firefox' && '🔥'}
              {browser === 'Safari' && '🧭'}
              {browser === 'Browser' && '🌍'}
            </div>
            <h3 className="text-lg font-semibold">{browser} Instructions</h3>
          </div>

          {browser === 'Chrome' && (
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="font-medium text-blue-800 mb-1">Method 1: Click the camera/microphone icon</p>
                <p className="text-blue-600">• Look for 🎤 or 📹 icon in the address bar</p>
                <p className="text-blue-600">• Click it and select "Always allow"</p>
              </div>
              
              <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                <p className="font-medium text-purple-800 mb-1">Method 2: Site settings</p>
                <p className="text-purple-600">• Click the lock icon 🔒 next to the URL</p>
                <p className="text-purple-600">• Change Camera and Microphone to "Allow"</p>
              </div>
              
              <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                <p className="font-medium text-orange-800 mb-1">Method 3: Chrome settings</p>
                <p className="text-orange-600">• Go to chrome://settings/content</p>
                <p className="text-orange-600">• Find this site and allow permissions</p>
              </div>
            </div>
          )}

          {browser === 'Firefox' && (
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                <p className="font-medium text-orange-800 mb-1">Method 1: Address bar</p>
                <p className="text-orange-600">• Look for the shield or camera/mic icon in the address bar</p>
                <p className="text-orange-600">• Click it and select "Allow" for both camera and microphone</p>
              </div>
              
              <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                <p className="font-medium text-red-800 mb-1">Method 2: Firefox settings</p>
                <p className="text-red-600">• Type about:preferences#privacy in the address bar</p>
                <p className="text-red-600">• Scroll to "Permissions" section</p>
                <p className="text-red-600">• Find this website and allow camera/microphone</p>
              </div>
            </div>
          )}

          {(browser === 'Browser' || !['Chrome', 'Firefox', 'Safari'].includes(browser)) && (
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                <p className="font-medium text-gray-800 mb-1">General Instructions:</p>
                <p className="text-gray-600">• Look for camera 📹 or microphone 🎤 icons in your address bar</p>
                <p className="text-gray-600">• Click on them and select "Allow" or "Always allow"</p>
                <p className="text-gray-600">• Check your browser's privacy/security settings</p>
                <p className="text-gray-600">• Refresh the page after making changes</p>
              </div>
              
              <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                <p className="font-medium text-yellow-800 mb-1">💡 Pro Tip:</p>
                <p className="text-yellow-600">Most browsers show permission requests when you try to use camera/microphone. Click "Allow" when prompted!</p>
              </div>
            </div>
          )}

          {browser === 'Safari' && (
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                <p className="font-medium text-blue-800 mb-1">Method 1: Safari menu</p>
                <p className="text-blue-600">• Go to Safari → Settings → Websites</p>
                <p className="text-blue-600">• Find Camera and Microphone in the left sidebar</p>
                <p className="text-blue-600">• Set this website to "Allow"</p>
              </div>
              
              <div className="p-3 bg-teal-50 rounded-lg border border-teal-200">
                <p className="font-medium text-teal-800 mb-1">Method 2: Address bar</p>
                <p className="text-teal-600">• Look for camera/microphone icons in the address bar</p>
                <p className="text-teal-600">• Click and select "Allow"</p>
                <p className="text-teal-600">• You may need to refresh the page</p>
              </div>
            </div>
          )}
        </div>
      )
    },
    {
      title: "Try Again",
      description: "Refresh and test your permissions",
      icon: RefreshCw,
      content: (
        <div className="space-y-4 text-center">
          <div className="text-6xl mb-4">🚀</div>
          <h3 className="text-lg font-semibold mb-2">Ready to Experience the Future?</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Once you've enabled permissions, click the button below to unlock LinguaLink's revolutionary AI features!
          </p>
          
          <div className="space-y-2">
            <Badge variant="outline" className="mx-1">🧠 Quantum Translation</Badge>
            <Badge variant="outline" className="mx-1">💖 Neural Empathy</Badge>
            <Badge variant="outline" className="mx-1">✨ Holographic UI</Badge>
            <Badge variant="outline" className="mx-1">🧬 Bio-Rhythmic Sync</Badge>
          </div>
        </div>
      )
    }
  ];

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
    >
      <Card className="w-full max-w-md shadow-2xl border-2 border-primary/20">
        <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center space-x-2">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <Settings className="w-5 h-5" />
              </motion.div>
              <span>Enable Revolutionary Features</span>
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose} className="text-white hover:bg-white/20">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {steps[currentStep].content}
            </motion.div>
          </AnimatePresence>

          {/* Progress indicator */}
          <div className="flex justify-center space-x-2 mt-6 mb-4">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentStep ? 'bg-primary' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>

          {/* Navigation buttons */}
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
            >
              Previous
            </Button>

            {currentStep < steps.length - 1 ? (
              <Button
                onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
              >
                Next
              </Button>
            ) : (
              <div className="space-x-2">
                <Button variant="outline" onClick={() => window.location.reload()}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh Page
                </Button>
                <Button onClick={onRetry} className="bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Test Again
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}