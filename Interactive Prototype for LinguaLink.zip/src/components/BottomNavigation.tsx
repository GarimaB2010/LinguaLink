import { Home, MessageCircle, Settings, Users } from "lucide-react";
import { motion } from "motion/react";

interface BottomNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  settings?: any;
}

export function BottomNavigation({ activeTab, onTabChange, settings }: BottomNavigationProps) {
  const tabs = [
    { id: 'home', icon: Home, label: 'Home', emoji: '🏠', gradient: 'from-purple-500 to-blue-500' },
    { id: 'conversation', icon: MessageCircle, label: 'Chat', emoji: '💬', gradient: 'from-blue-500 to-cyan-500' },
    { id: 'settings', icon: Settings, label: 'Settings', emoji: '⚙️', gradient: 'from-orange-500 to-pink-500' },
    { id: 'community', icon: Users, label: 'Community', emoji: '👥', gradient: 'from-green-500 to-emerald-500' },
  ];

  const handleTabClick = (tabId: string) => {
    // Haptic feedback
    if ('vibrate' in navigator && settings?.hapticFeedback) {
      navigator.vibrate(50);
    }
    onTabChange(tabId);
  };

  return (
    <motion.div 
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-xl border-t border-white/30 shadow-2xl z-50"
    >
      <div className="flex justify-around items-center py-2 px-2 max-w-lg mx-auto">
        {tabs.map((tab, index) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <motion.button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              whileHover={{ scale: 1.1, y: -5 }}
              whileTap={{ scale: 0.95 }}
              className={`flex flex-col items-center p-3 rounded-2xl transition-all duration-300 relative ${
                isActive
                  ? `text-white bg-gradient-to-r ${tab.gradient} shadow-xl`
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/70'
              }`}
            >
              <motion.div
                animate={isActive ? {
                  scale: [1, 1.2, 1],
                  rotate: [0, 10, -10, 0]
                } : {}}
                transition={{
                  duration: 0.5,
                  repeat: isActive ? Infinity : 0,
                  repeatDelay: 2
                }}
                className="relative"
              >
                <Icon className="w-6 h-6 mb-1" />
                {isActive && !settings?.reduceAnimations && (
                  <motion.div
                    className="absolute -inset-2 bg-white/30 rounded-full"
                    animate={{
                      scale: [1, 1.5],
                      opacity: [0.5, 0]
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      ease: "easeOut"
                    }}
                  />
                )}
              </motion.div>
              <span className="text-xs font-medium">{tab.label}</span>
              
              {/* Active indicator */}
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute -top-1 w-2 h-2 bg-yellow-400 rounded-full shadow-lg"
                  initial={{ scale: 0 }}
                  animate={{ scale: [1, 1.3, 1] }}
                  transition={{
                    scale: { duration: 1, repeat: Infinity }
                  }}
                />
              )}
              
              {/* Emoji indicator on hover */}
              {!isActive && (
                <motion.span
                  className="absolute -top-8 text-xl opacity-0"
                  whileHover={{ opacity: 1, y: -5 }}
                  transition={{ duration: 0.2 }}
                >
                  {tab.emoji}
                </motion.span>
              )}
            </motion.button>
          );
        })}
      </div>
    </motion.div>
  );
}