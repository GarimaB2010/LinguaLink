// Simple sound effects using Web Audio API
export class SoundEffects {
  private audioContext: AudioContext | null = null;

  constructor() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (error) {
      console.warn('Web Audio API not supported');
    }
  }

  private createTone(frequency: number, duration: number, type: OscillatorType = 'sine') {
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);

    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
    oscillator.type = type;

    gainNode.gain.setValueAtTime(0.1, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);

    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration);
  }

  success() {
    this.createTone(523.25, 0.2); // C5
    setTimeout(() => this.createTone(659.25, 0.2), 100); // E5
    setTimeout(() => this.createTone(783.99, 0.3), 200); // G5
  }

  error() {
    this.createTone(220, 0.3, 'sawtooth'); // A3
    setTimeout(() => this.createTone(196, 0.4, 'sawtooth'), 150); // G3
  }

  notification() {
    this.createTone(440, 0.1); // A4
    setTimeout(() => this.createTone(554.37, 0.1), 100); // C#5
  }

  click() {
    this.createTone(800, 0.05, 'square');
  }

  recording() {
    this.createTone(400, 0.1);
    setTimeout(() => this.createTone(600, 0.1), 50);
  }

  stopRecording() {
    this.createTone(600, 0.1);
    setTimeout(() => this.createTone(400, 0.1), 50);
  }
}

export const soundEffects = new SoundEffects();