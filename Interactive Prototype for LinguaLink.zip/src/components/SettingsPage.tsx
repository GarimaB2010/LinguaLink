import { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import { Slider } from "./ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Palette, Eye, Volume2, Type, Globe, Save, Smartphone, CheckCircle, Camera, Mic, Play, Square, Video, AlertCircle, RefreshCw } from "lucide-react";
import { SuccessFeedback } from "./SuccessFeedback";
import { MediaStreamManager } from "./MediaStreamManager";
import { toast } from "sonner@2.0.3";

interface SettingsPageProps {
  settings: any;
  onSettingsChange: (newSettings: any) => void;
  permissionsGranted?: {
    camera: boolean;
    microphone: boolean;
  };
}

export function SettingsPage({ settings, onSettingsChange, permissionsGranted = { camera: false, microphone: false } }: SettingsPageProps) {
  const [localSettings, setLocalSettings] = useState(settings);
  const [micDevices, setMicDevices] = useState<MediaDeviceInfo[]>([]);
  const [cameraDevices, setCameraDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedMic, setSelectedMic] = useState<string>('');
  const [selectedCamera, setSelectedCamera] = useState<string>('');
  const [micLevel, setMicLevel] = useState(0);
  const [isMicTesting, setIsMicTesting] = useState(false);
  const [isCameraPreviewOpen, setIsCameraPreviewOpen] = useState(false);
  const [micPermission, setMicPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  const [cameraPermission, setCameraPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const cameraStreamRef = useRef<MediaStream | null>(null);

  // Check permissions on mount and when permissionsGranted changes
  useEffect(() => {
    // Set initial permission states from props
    if (permissionsGranted.microphone) {
      setMicPermission('granted');
    }
    if (permissionsGranted.camera) {
      setCameraPermission('granted');
    }
    
    checkPermissions();
    loadDevices();
  }, [permissionsGranted]);

  const checkPermissions = async () => {
    if (navigator.permissions && navigator.permissions.query) {
      try {
        const micPerm = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        setMicPermission(micPerm.state as any);
        
        const camPerm = await navigator.permissions.query({ name: 'camera' as PermissionName });
        setCameraPermission(camPerm.state as any);
      } catch (error) {
        console.warn('Permission query not supported:', error);
      }
    }
  };

  const loadDevices = async () => {
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const mics = devices.filter(device => device.kind === 'audioinput');
      const cameras = devices.filter(device => device.kind === 'videoinput');
      
      setMicDevices(mics);
      setCameraDevices(cameras);
      
      if (mics.length > 0 && !selectedMic) {
        setSelectedMic(mics[0].deviceId);
      }
      if (cameras.length > 0 && !selectedCamera) {
        setSelectedCamera(cameras[0].deviceId);
      }
    } catch (error) {
      console.error('Error loading devices:', error);
    }
  };

  const requestMicPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      stream.getTracks().forEach(track => track.stop());
      setMicPermission('granted');
      toast.success('🎤 Microphone access granted!', { duration: 3000 });
      await loadDevices();
    } catch (error) {
      setMicPermission('denied');
      toast.error('❌ Microphone access denied', { duration: 5000 });
    }
  };

  const requestCameraPermission = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 640 }, 
          height: { ideal: 480 }
        } 
      });
      stream.getTracks().forEach(track => track.stop());
      setCameraPermission('granted');
      toast.success('📹 Camera access granted!', { duration: 3000 });
      await loadDevices();
    } catch (error) {
      setCameraPermission('denied');
      toast.error('❌ Camera access denied', { duration: 5000 });
    }
  };

  const startMicTest = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          deviceId: selectedMic ? { exact: selectedMic } : undefined,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });

      micStreamRef.current = stream;
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);

      setIsMicTesting(true);
      setMicPermission('granted');
      toast.success('🎤 Microphone test started', { duration: 3000 });
      
      // Monitor mic level
      const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
      const updateLevel = () => {
        if (!analyserRef.current || !isMicTesting) return;
        
        analyserRef.current.getByteFrequencyData(dataArray);
        const average = dataArray.reduce((a, b) => a + b) / dataArray.length;
        setMicLevel(Math.min(100, average * 2));
        
        if (isMicTesting) {
          requestAnimationFrame(updateLevel);
        }
      };
      updateLevel();
    } catch (error: any) {
      toast.error('❌ Failed to access microphone: ' + error.message, { duration: 5000 });
      setMicPermission('denied');
    }
  };

  const stopMicTest = () => {
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(track => track.stop());
      micStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    analyserRef.current = null;
    setIsMicTesting(false);
    setMicLevel(0);
    toast.info('🎤 Microphone test stopped', { duration: 3000 });
  };

  const toggleCameraPreview = async () => {
    if (isCameraPreviewOpen) {
      // Stop camera
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach(track => track.stop());
        cameraStreamRef.current = null;
      }
      if (videoRef.current) {
        videoRef.current.srcObject = null;
      }
      setIsCameraPreviewOpen(false);
      toast.info('📹 Camera preview closed', { duration: 3000 });
    } else {
      // Start camera
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            deviceId: selectedCamera ? { exact: selectedCamera } : undefined,
            width: { ideal: 640 },
            height: { ideal: 480 }
          }
        });
        
        cameraStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setIsCameraPreviewOpen(true);
        setCameraPermission('granted');
        toast.success('📹 Camera preview started');
      } catch (error: any) {
        toast.error('❌ Failed to access camera: ' + error.message);
        setCameraPermission('denied');
      }
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopMicTest();
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleSettingChange = (key: string, value: any) => {
    const newSettings = { ...localSettings, [key]: value };
    setLocalSettings(newSettings);
  };

  const handleSaveSettings = () => {
    onSettingsChange(localSettings);
    toast.success('✅ Settings saved successfully!');
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <div className="max-w-lg mx-auto px-4 pt-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl mb-2">Accessibility Settings</h1>
          <p className="text-muted-foreground">
            Customize LinguaLink for your needs
          </p>
        </div>

        <div className="space-y-6">
          {/* Media Devices Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <Video className="w-5 h-5" />
                <span>Media Devices</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Microphone Settings */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="flex items-center space-x-2">
                    <Mic className="w-4 h-4" />
                    <span>Microphone</span>
                  </Label>
                  <Badge className={
                    micPermission === 'granted' ? 'bg-green-100 text-green-800' :
                    micPermission === 'denied' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }>
                    {micPermission === 'granted' && <CheckCircle className="w-3 h-3 mr-1" />}
                    {micPermission === 'denied' && <AlertCircle className="w-3 h-3 mr-1" />}
                    {micPermission}
                  </Badge>
                </div>

                {micPermission === 'granted' && micDevices.length > 0 && (
                  <Select value={selectedMic} onValueChange={setSelectedMic}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select microphone" />
                    </SelectTrigger>
                    <SelectContent>
                      {micDevices.map((device, index) => (
                        <SelectItem key={device.deviceId} value={device.deviceId}>
                          {device.label || `Microphone ${index + 1}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                {micPermission !== 'granted' && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={requestMicPermission}
                  >
                    <Mic className="w-4 h-4 mr-2" />
                    Grant Microphone Permission
                  </Button>
                )}

                {micPermission === 'granted' && (
                  <>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Microphone Level</span>
                        <span className="text-sm">{Math.round(micLevel)}%</span>
                      </div>
                      <Progress value={micLevel} className="h-2" />
                    </div>

                    <Button
                      variant={isMicTesting ? "destructive" : "default"}
                      className="w-full"
                      onClick={isMicTesting ? stopMicTest : startMicTest}
                    >
                      {isMicTesting ? (
                        <>
                          <Square className="w-4 h-4 mr-2" />
                          Stop Test
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Test Microphone
                        </>
                      )}
                    </Button>
                  </>
                )}
              </div>

              {/* Camera Settings */}
              <div className="space-y-3 pt-3 border-t">
                <div className="flex items-center justify-between">
                  <Label className="flex items-center space-x-2">
                    <Camera className="w-4 h-4" />
                    <span>Camera</span>
                  </Label>
                  <Badge className={
                    cameraPermission === 'granted' ? 'bg-green-100 text-green-800' :
                    cameraPermission === 'denied' ? 'bg-red-100 text-red-800' :
                    'bg-yellow-100 text-yellow-800'
                  }>
                    {cameraPermission === 'granted' && <CheckCircle className="w-3 h-3 mr-1" />}
                    {cameraPermission === 'denied' && <AlertCircle className="w-3 h-3 mr-1" />}
                    {cameraPermission}
                  </Badge>
                </div>

                {cameraPermission === 'granted' && cameraDevices.length > 0 && (
                  <Select value={selectedCamera} onValueChange={setSelectedCamera}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select camera" />
                    </SelectTrigger>
                    <SelectContent>
                      {cameraDevices.map((device, index) => (
                        <SelectItem key={device.deviceId} value={device.deviceId}>
                          {device.label || `Camera ${index + 1}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                {cameraPermission !== 'granted' && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={requestCameraPermission}
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Grant Camera Permission
                  </Button>
                )}

                {cameraPermission === 'granted' && (
                  <>
                    {isCameraPreviewOpen && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="rounded-lg overflow-hidden bg-black"
                      >
                        <video
                          ref={videoRef}
                          autoPlay
                          playsInline
                          muted
                          className="w-full h-auto"
                        />
                      </motion.div>
                    )}

                    <Button
                      variant={isCameraPreviewOpen ? "destructive" : "default"}
                      className="w-full"
                      onClick={toggleCameraPreview}
                    >
                      {isCameraPreviewOpen ? (
                        <>
                          <Square className="w-4 h-4 mr-2" />
                          Stop Preview
                        </>
                      ) : (
                        <>
                          <Video className="w-4 h-4 mr-2" />
                          Test Camera
                        </>
                      )}
                    </Button>
                  </>
                )}
              </div>

              <Button
                variant="ghost"
                size="sm"
                className="w-full"
                onClick={() => {
                  checkPermissions();
                  loadDevices();
                }}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Devices
              </Button>
            </CardContent>
          </Card>

          {/* Visual Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <Eye className="w-5 h-5" />
                <span>Visual Accessibility</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Text Size */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <Label>Text Size</Label>
                  <Badge variant="secondary">{localSettings.textSize}%</Badge>
                </div>
                <Slider
                  value={[localSettings.textSize]}
                  onValueChange={([value]) => handleSettingChange('textSize', value)}
                  min={75}
                  max={150}
                  step={25}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Small</span>
                  <span>Normal</span>
                  <span>Large</span>
                </div>
              </div>

              {/* Color Blind Mode */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Color-blind Friendly</Label>
                  <p className="text-sm text-muted-foreground">High contrast colors</p>
                </div>
                <Switch
                  checked={localSettings.colorBlindMode}
                  onCheckedChange={(checked) => handleSettingChange('colorBlindMode', checked)}
                />
              </div>

              {/* Dark Mode */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">Easier on the eyes</p>
                </div>
                <Switch
                  checked={localSettings.darkMode}
                  onCheckedChange={(checked) => handleSettingChange('darkMode', checked)}
                />
              </div>

              {/* Easy Mode */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Easy Mode</Label>
                  <p className="text-sm text-muted-foreground">Simplified interface</p>
                </div>
                <Switch
                  checked={localSettings.easyMode}
                  onCheckedChange={(checked) => handleSettingChange('easyMode', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Audio Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <Volume2 className="w-5 h-5" />
                <span>Audio Settings</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Speech Speed */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <Label>Speech Speed</Label>
                  <Badge variant="secondary">{localSettings.speechSpeed}x</Badge>
                </div>
                <Slider
                  value={[localSettings.speechSpeed * 10]}
                  onValueChange={([value]) => handleSettingChange('speechSpeed', value / 10)}
                  min={5}
                  max={20}
                  step={2.5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>Slow</span>
                  <span>Normal</span>
                  <span>Fast</span>
                </div>
              </div>

              {/* Voice Type */}
              <div>
                <Label className="mb-2 block">Voice Type</Label>
                <Select 
                  value={localSettings.voiceType} 
                  onValueChange={(value) => handleSettingChange('voiceType', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="neutral">Neutral</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Auto-play */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Auto-play Audio</Label>
                  <p className="text-sm text-muted-foreground">Play audio automatically</p>
                </div>
                <Switch
                  checked={localSettings.autoPlay}
                  onCheckedChange={(checked) => handleSettingChange('autoPlay', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Language Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <Globe className="w-5 h-5" />
                <span>Language & Communication</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Preferred Language */}
              <div>
                <Label className="mb-2 block">Preferred Language</Label>
                <Select 
                  value={localSettings.preferredLanguage} 
                  onValueChange={(value) => handleSettingChange('preferredLanguage', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="spanish">Español</SelectItem>
                    <SelectItem value="hindi">हिंदी</SelectItem>
                    <SelectItem value="mandarin">中文</SelectItem>
                    <SelectItem value="arabic">العربية</SelectItem>
                    <SelectItem value="asl">ASL</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Auto-simplify */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Auto-simplify Text</Label>
                  <p className="text-sm text-muted-foreground">Simplify complex language</p>
                </div>
                <Switch
                  checked={localSettings.autoSimplify}
                  onCheckedChange={(checked) => handleSettingChange('autoSimplify', checked)}
                />
              </div>

              {/* Show Original */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Show Original Text</Label>
                  <p className="text-sm text-muted-foreground">Display alongside simplified</p>
                </div>
                <Switch
                  checked={localSettings.showOriginal}
                  onCheckedChange={(checked) => handleSettingChange('showOriginal', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Device Settings */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center space-x-2">
                <Smartphone className="w-5 h-5" />
                <span>Device & Performance</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Haptic Feedback */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Haptic Feedback</Label>
                  <p className="text-sm text-muted-foreground">Vibrate on interactions</p>
                </div>
                <Switch
                  checked={localSettings.hapticFeedback}
                  onCheckedChange={(checked) => handleSettingChange('hapticFeedback', checked)}
                />
              </div>

              {/* Reduce Animations */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Reduce Animations</Label>
                  <p className="text-sm text-muted-foreground">Minimize motion effects</p>
                </div>
                <Switch
                  checked={localSettings.reduceAnimations}
                  onCheckedChange={(checked) => handleSettingChange('reduceAnimations', checked)}
                />
              </div>

              {/* Offline Mode */}
              <div className="flex items-center justify-between">
                <div>
                  <Label>Offline Mode Ready</Label>
                  <p className="text-sm text-muted-foreground">Cache for offline use</p>
                </div>
                <Switch
                  checked={localSettings.offlineMode}
                  onCheckedChange={(checked) => handleSettingChange('offlineMode', checked)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Save Button */}
          <Button 
            onClick={handleSaveSettings}
            className="w-full"
            size="lg"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Settings
          </Button>

          {/* Reset to Defaults */}
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => {
              const defaultSettings = {
                textSize: 100,
                colorBlindMode: false,
                darkMode: false,
                easyMode: false,
                speechSpeed: 1.0,
                voiceType: 'female',
                autoPlay: false,
                preferredLanguage: 'english',
                autoSimplify: true,
                showOriginal: true,
                hapticFeedback: true,
                reduceAnimations: false,
                offlineMode: false
              };
              setLocalSettings(defaultSettings);
            }}
          >
            Reset to Defaults
          </Button>
        </div>
      </div>
    </div>
  );
}