import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cube, Hand, Eye, Sparkles, Layers, Zap, Target, Scan } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface GestureCommand {
  name: string;
  gesture: string;
  action: string;
  confidence: number;
}

interface HologramProps {
  isActive: boolean;
  onGestureDetected: (command: GestureCommand) => void;
  onClose: () => void;
}

export function HolographicGestureInterface({ isActive, onGestureDetected, onClose }: HologramProps) {
  const [hologramMode, setHologramMode] = useState<'initializing' | 'calibrating' | 'active' | 'detecting'>('initializing');
  const [gestureConfidence, setGestureConfidence] = useState(0);
  const [currentGesture, setCurrentGesture] = useState<string | null>(null);
  const [handPosition, setHandPosition] = useState({ x: 50, y: 50, z: 0 });
  const [hologramLayers, setHologramLayers] = useState(3);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const gestures = [
    { name: 'Open Palm', emoji: '✋', action: 'Voice Activation', command: 'activate_voice' },
    { name: 'Peace Sign', emoji: '✌️', action: 'Language Switch', command: 'switch_language' },
    { name: 'Thumbs Up', emoji: '👍', action: 'Confirm Action', command: 'confirm' },
    { name: 'Point', emoji: '👉', action: 'Select Target', command: 'select' },
    { name: 'Fist', emoji: '✊', action: 'Emergency Mode', command: 'emergency' },
    { name: 'Wave', emoji: '👋', action: 'Start Conversation', command: 'start_chat' }
  ];

  useEffect(() => {
    if (isActive) {
      initializeHologram();
    }
  }, [isActive]);

  useEffect(() => {
    if (hologramMode === 'active') {
      simulateGestureDetection();
    }
  }, [hologramMode]);

  const initializeHologram = async () => {
    setHologramMode('initializing');
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setHologramMode('calibrating');
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setHologramMode('active');
    drawHolographicInterface();
  };

  const simulateGestureDetection = () => {
    const interval = setInterval(() => {
      if (hologramMode !== 'active') {
        clearInterval(interval);
        return;
      }

      // Simulate hand movement
      setHandPosition({
        x: 30 + Math.random() * 40,
        y: 30 + Math.random() * 40,  
        z: -10 + Math.random() * 20
      });

      // Randomly detect gestures
      if (Math.random() < 0.3) {
        const detectedGesture = gestures[Math.floor(Math.random() * gestures.length)];
        const confidence = 85 + Math.random() * 15;
        
        setCurrentGesture(detectedGesture.name);
        setGestureConfidence(confidence);
        setHologramMode('detecting');

        setTimeout(() => {
          onGestureDetected({
            name: detectedGesture.name,
            gesture: detectedGesture.emoji,
            action: detectedGesture.action,
            confidence: confidence
          });
          
          setHologramMode('active');
          setCurrentGesture(null);
          setGestureConfidence(0);
        }, 1500);
      }
    }, 500);

    return () => clearInterval(interval);
  };

  const drawHolographicInterface = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 300;
    canvas.height = 300;

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const time = Date.now() * 0.002;
      
      // Draw holographic grid
      ctx.strokeStyle = '#8B5CF680';
      ctx.lineWidth = 1;
      
      for (let i = 0; i < 10; i++) {
        for (let j = 0; j < 10; j++) {
          const x = (i / 9) * canvas.width;
          const y = (j / 9) * canvas.height;
          const wave = Math.sin(time + i * 0.5 + j * 0.5) * 5;
          
          ctx.beginPath();
          ctx.arc(x, y + wave, 2, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // Draw hand position indicator
      const handX = (handPosition.x / 100) * canvas.width;
      const handY = (handPosition.y / 100) * canvas.height;
      
      ctx.fillStyle = '#3B82F6';
      ctx.beginPath();
      ctx.arc(handX, handY, 8 + Math.sin(time * 3) * 2, 0, Math.PI * 2);
      ctx.fill();

      // Draw gesture recognition zone
      ctx.strokeStyle = '#10B98160';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
      ctx.strokeRect(50, 50, 200, 200);
      ctx.setLineDash([]);

      if (hologramMode === 'active') {
        requestAnimationFrame(animate);
      }
    };

    animate();
  };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50"
    >
      <Card className="w-[600px] bg-gradient-to-br from-blue-900/90 to-purple-900/90 text-white border-blue-500/50 shadow-2xl">
        <CardContent className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-300 to-purple-300 bg-clip-text text-transparent">
                Holographic Gesture Interface
              </h3>
              <p className="text-sm text-blue-200">
                Next-generation spatial interaction system
              </p>
            </div>
            <Button variant="ghost" onClick={onClose} className="text-white hover:bg-white/20">
              ✕
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {/* Holographic Display */}
            <div className="space-y-4">
              <div className="text-center">
                <motion.div
                  animate={{ 
                    rotateY: [0, 360],
                    rotateX: [0, 15, 0]
                  }}
                  transition={{ 
                    duration: 8, 
                    repeat: Infinity,
                    ease: "linear"
                  }}
                  className="relative w-80 h-80 mx-auto"
                >
                  {/* Hologram Layers */}
                  {[...Array(hologramLayers)].map((_, i) => (
                    <motion.div
                      key={i}
                      animate={{
                        scale: [1, 1.1, 1],
                        opacity: [0.3, 0.6, 0.3]
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        delay: i * 0.5
                      }}
                      className="absolute inset-0 border-2 border-blue-400/30 rounded-lg"
                      style={{
                        transform: `translateZ(${i * 20}px)`,
                        filter: `blur(${i}px)`
                      }}
                    />
                  ))}
                  
                  {/* Main Canvas */}
                  <canvas
                    ref={canvasRef}
                    className="absolute inset-0 w-full h-full rounded-lg opacity-80"
                  />
                  
                  {/* Holographic Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-lg">
                    <div className="absolute top-4 left-4 text-xs text-blue-300">
                      HOLO-INTERFACE v3.7
                    </div>
                    <div className="absolute top-4 right-4 text-xs text-green-400">
                      {hologramMode.toUpperCase()}
                    </div>
                    
                    {/* Hand Position Indicator */}
                    <motion.div
                      animate={{
                        x: handPosition.x * 2.8,
                        y: handPosition.y * 2.8,
                        scale: [1, 1.2, 1]
                      }}
                      transition={{ duration: 0.5 }}
                      className="absolute w-4 h-4 bg-blue-400 rounded-full shadow-lg shadow-blue-400/50"
                    />
                  </div>
                </motion.div>
              </div>

              {/* Status Display */}
              <div className="flex justify-center space-x-4">
                <Badge variant={hologramMode === 'active' ? 'default' : 'secondary'} className="flex items-center space-x-1">
                  <Eye className="w-3 h-3" />
                  <span>Tracking</span>
                </Badge>
                <Badge variant={currentGesture ? 'default' : 'secondary'} className="flex items-center space-x-1">
                  <Hand className="w-3 h-3" />
                  <span>Recognition</span>
                </Badge>
                <Badge variant={gestureConfidence > 80 ? 'default' : 'secondary'} className="flex items-center space-x-1">
                  <Target className="w-3 h-3" />
                  <span>Precision</span>
                </Badge>
              </div>
            </div>

            {/* Control Panel */}
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-lg border border-blue-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Scan className="w-4 h-4" />
                  <span>Detection Status</span>
                </h4>
                
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Mode:</span>
                    <span className="text-blue-300 capitalize">{hologramMode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Hand Position:</span>
                    <span className="text-green-300">
                      {handPosition.x.toFixed(0)}, {handPosition.y.toFixed(0)}, {handPosition.z.toFixed(0)}
                    </span>
                  </div>
                  {currentGesture && (
                    <div className="flex justify-between">
                      <span>Current Gesture:</span>
                      <span className="text-yellow-300">{currentGesture}</span>
                    </div>
                  )}
                  {gestureConfidence > 0 && (
                    <div className="flex justify-between">
                      <span>Confidence:</span>
                      <span className="text-green-300">{gestureConfidence.toFixed(1)}%</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Available Gestures */}
              <div className="p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg border border-purple-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Hand className="w-4 h-4" />
                  <span>Available Gestures</span>
                </h4>
                
                <div className="space-y-2">
                  {gestures.slice(0, 4).map((gesture, index) => (
                    <motion.div
                      key={index}
                      whileHover={{ scale: 1.02, x: 5 }}
                      className={`flex items-center space-x-3 p-2 rounded transition-colors ${
                        currentGesture === gesture.name 
                          ? 'bg-yellow-500/20 border border-yellow-500/40' 
                          : 'hover:bg-white/10'
                      }`}
                    >
                      <span className="text-2xl">{gesture.emoji}</span>
                      <div className="flex-1">
                        <div className="text-sm font-medium">{gesture.name}</div>
                        <div className="text-xs text-blue-200">{gesture.action}</div>
                      </div>
                      {currentGesture === gesture.name && (
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        >
                          <Sparkles className="w-4 h-4 text-yellow-400" />
                        </motion.div>
                      )}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Hologram Controls */}
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="flex-1 border-blue-500/50 text-blue-300 hover:bg-blue-500/20"
                  onClick={() => setHologramLayers(hologramLayers === 3 ? 5 : 3)}
                >
                  <Layers className="w-4 h-4 mr-2" />
                  Layers: {hologramLayers}
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  className="flex-1 border-purple-500/50 text-purple-300 hover:bg-purple-500/20"
                  onClick={() => setHologramMode(hologramMode === 'active' ? 'calibrating' : 'active')}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Recalibrate
                </Button>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-6 text-center text-xs text-blue-300/60">
            ⚡ Powered by Neural Gesture Processing Engine ⚡
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}