import { motion } from "motion/react";
import { LucideIcon } from "lucide-react";

interface FloatingActionButtonProps {
  icon: LucideIcon;
  onClick: () => void;
  className?: string;
  color?: string;
  pulse?: boolean;
}

export function FloatingActionButton({ 
  icon: Icon, 
  onClick, 
  className = "", 
  color = "bg-gradient-to-r from-purple-500 to-blue-500",
  pulse = false 
}: FloatingActionButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`
        w-14 h-14 rounded-full shadow-lg 
        flex items-center justify-center
        text-white font-medium
        ${color} ${className}
      `}
      animate={pulse ? {
        boxShadow: [
          "0 0 0 0 rgba(139, 92, 246, 0.7)",
          "0 0 0 10px rgba(139, 92, 246, 0)",
          "0 0 0 0 rgba(139, 92, 246, 0)"
        ]
      } : {}}
      transition={{
        duration: 2,
        repeat: pulse ? Infinity : 0,
      }}
    >
      <Icon className="w-6 h-6" />
    </motion.button>
  );
}