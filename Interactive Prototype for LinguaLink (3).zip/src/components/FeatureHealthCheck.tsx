import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, AlertTriangle, RefreshCw, Wifi, WifiOff } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';

interface HealthStatus {
  feature: string;
  status: 'healthy' | 'warning' | 'error';
  message: string;
  action?: () => void;
}

interface FeatureHealthCheckProps {
  onHealthChange: (isHealthy: boolean) => void;
}

export function FeatureHealthCheck({ onHealthChange }: FeatureHealthCheckProps) {
  const [healthChecks, setHealthChecks] = useState<HealthStatus[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const runHealthChecks = async () => {
    setIsChecking(true);
    const checks: HealthStatus[] = [];

    // Check Speech Recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      checks.push({
        feature: 'Speech Recognition',
        status: 'healthy',
        message: 'Ready for voice input'
      });
    } else {
      checks.push({
        feature: 'Speech Recognition',
        status: 'error',
        message: 'Not supported in this browser. Use Chrome, Edge, or Safari.'
      });
    }

    // Check Text-to-Speech
    if ('speechSynthesis' in window) {
      const voices = speechSynthesis.getVoices();
      if (voices.length > 0) {
        checks.push({
          feature: 'Text-to-Speech',
          status: 'healthy',
          message: `${voices.length} voices available`
        });
      } else {
        checks.push({
          feature: 'Text-to-Speech',
          status: 'warning',
          message: 'Loading voices... Please wait.'
        });
      }
    } else {
      checks.push({
        feature: 'Text-to-Speech',
        status: 'error',
        message: 'Not supported in this browser'
      });
    }

    // Check Camera Access
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        // Check if camera is available (without actually accessing it)
        const devices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = devices.filter(device => device.kind === 'videoinput');
        
        if (videoDevices.length > 0) {
          checks.push({
            feature: 'Camera',
            status: 'healthy',
            message: `${videoDevices.length} camera(s) detected`
          });
        } else {
          checks.push({
            feature: 'Camera',
            status: 'warning',
            message: 'No camera detected'
          });
        }
      } catch (error) {
        checks.push({
          feature: 'Camera',
          status: 'error',
          message: 'Camera access blocked or unavailable'
        });
      }
    } else {
      checks.push({
        feature: 'Camera',
        status: 'error',
        message: 'Camera not supported'
      });
    }

    // Check Microphone Access
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioDevices = devices.filter(device => device.kind === 'audioinput');
        
        if (audioDevices.length > 0) {
          checks.push({
            feature: 'Microphone',
            status: 'healthy',
            message: `${audioDevices.length} microphone(s) detected`
          });
        } else {
          checks.push({
            feature: 'Microphone',
            status: 'warning',
            message: 'No microphone detected'
          });
        }
      } catch (error) {
        checks.push({
          feature: 'Microphone',
          status: 'error',
          message: 'Microphone access blocked or unavailable'
        });
      }
    } else {
      checks.push({
        feature: 'Microphone',
        status: 'error',
        message: 'Microphone not supported'
      });
    }

    // Check Local Storage
    try {
      localStorage.setItem('health_check', 'test');
      localStorage.removeItem('health_check');
      checks.push({
        feature: 'Storage',
        status: 'healthy',
        message: 'Settings will be saved'
      });
    } catch (error) {
      checks.push({
        feature: 'Storage',
        status: 'warning',
        message: 'Settings cannot be saved'
      });
    }

    // Network Status
    if (isOnline) {
      checks.push({
        feature: 'Network',
        status: 'healthy',
        message: 'Online - All features available'
      });
    } else {
      checks.push({
        feature: 'Network',
        status: 'warning',
        message: 'Offline - Some features may be limited'
      });
    }

    setHealthChecks(checks);
    
    // Determine overall health
    const hasErrors = checks.some(check => check.status === 'error');
    const hasWarnings = checks.some(check => check.status === 'warning');
    
    onHealthChange(!hasErrors);
    setIsChecking(false);
  };

  useEffect(() => {
    runHealthChecks();
    
    // Re-check periodically
    const interval = setInterval(runHealthChecks, 30000); // Every 30 seconds
    
    return () => clearInterval(interval);
  }, [isOnline]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'error': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default: return <RefreshCw className="w-4 h-4 text-gray-500 animate-spin" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'border-green-200 bg-green-50';
      case 'warning': return 'border-yellow-200 bg-yellow-50';
      case 'error': return 'border-red-200 bg-red-50';
      default: return 'border-gray-200 bg-gray-50';
    }
  };

  const healthyCount = healthChecks.filter(check => check.status === 'healthy').length;
  const totalChecks = healthChecks.length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mb-6"
    >
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              {isOnline ? (
                <Wifi className="w-5 h-5 text-green-500" />
              ) : (
                <WifiOff className="w-5 h-5 text-red-500" />
              )}
              <h3 className="font-medium">System Status</h3>
              {isChecking && <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />}
            </div>
            
            <div className="text-sm text-muted-foreground">
              {healthyCount}/{totalChecks} features ready
            </div>
          </div>

          <div className="space-y-2">
            <AnimatePresence>
              {healthChecks.map((check, index) => (
                <motion.div
                  key={check.feature}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className={`flex items-center justify-between p-2 rounded-lg border ${getStatusColor(check.status)}`}
                >
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(check.status)}
                    <div>
                      <span className="font-medium text-sm">{check.feature}</span>
                      <p className="text-xs text-muted-foreground">{check.message}</p>
                    </div>
                  </div>
                  
                  {check.action && (
                    <Button size="sm" variant="outline" onClick={check.action}>
                      Fix
                    </Button>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={runHealthChecks}
            disabled={isChecking}
            className="w-full mt-3"
          >
            {isChecking ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Checking...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Status
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
}