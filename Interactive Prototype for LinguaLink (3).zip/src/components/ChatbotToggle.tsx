import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, HelpCircle, Sparkles } from 'lucide-react';
import { LinguaLinkChatbot } from './LinguaLinkChatbot';

interface ChatbotToggleProps {
  settings: any;
}

export function ChatbotToggle({ settings }: ChatbotToggleProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [hasNewMessage, setHasNewMessage] = useState(true);

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setHasNewMessage(false);
    }
  };

  return (
    <>
      {/* Floating Action Button - Enhanced Visibility */}
      <motion.div
        className="fixed bottom-24 right-4 z-40"
        initial={{ scale: 0, y: 100 }}
        animate={{ scale: 1, y: 0 }}
        transition={{ delay: 1, type: "spring", stiffness: 200, damping: 15 }}
      >
        <motion.button
          onClick={toggleChatbot}
          className={`
            relative w-16 h-16 rounded-full shadow-2xl
            bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500
            hover:from-purple-600 hover:via-pink-600 hover:to-blue-600
            text-white flex items-center justify-center
            transition-all duration-300
          `}
          whileHover={{ scale: 1.15, rotate: 5 }}
          whileTap={{ scale: 0.9 }}
          animate={settings.reduceAnimations ? {} : {
            scale: [1, 1.1, 1],
            boxShadow: [
              "0 10px 30px rgba(139, 92, 246, 0.4)",
              "0 15px 40px rgba(236, 72, 153, 0.6)",
              "0 10px 30px rgba(139, 92, 246, 0.4)"
            ]
          }}
          transition={{
            scale: { duration: 2, repeat: Infinity, ease: "easeInOut" },
            boxShadow: { duration: 2, repeat: Infinity, ease: "easeInOut" }
          }}
        >
          {/* Notification Badge */}
          <AnimatePresence>
            {hasNewMessage && !isOpen && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0 }}
                className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center"
              >
                <Sparkles className="w-2 h-2 text-white" />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Icon with animation */}
          <motion.div
            animate={!settings.reduceAnimations ? { 
              rotate: [0, 10, -10, 0],
              scale: [1, 1.1, 1]
            } : {}}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            {isOpen ? (
              <HelpCircle className="w-6 h-6" />
            ) : (
              <MessageCircle className="w-6 h-6" />
            )}
          </motion.div>

          {/* Ripple effect */}
          {!settings.reduceAnimations && (
            <motion.div
              className="absolute inset-0 rounded-full border-2 border-white/30"
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.7, 0, 0.7]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          )}
        </motion.button>

        {/* Enhanced Tooltip */}
        <AnimatePresence>
          {!isOpen && (
            <motion.div
              initial={{ opacity: 0, x: 10, scale: 0.8 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 10, scale: 0.8 }}
              transition={{ delay: 2 }}
              className="absolute right-20 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-purple-600 to-blue-600 text-white px-4 py-3 rounded-2xl whitespace-nowrap shadow-2xl border-2 border-white/30"
            >
              <div className="flex items-center space-x-2">
                <motion.span
                  animate={{ rotate: [0, 20, -20, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="text-lg"
                >
                  👋
                </motion.span>
                <span className="font-medium">Need help? Chat with Lingua!</span>
              </div>
              <div className="absolute right-0 top-1/2 transform translate-x-2 -translate-y-1/2 w-0 h-0 border-l-8 border-l-blue-600 border-t-4 border-b-4 border-transparent" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Chatbot Component */}
      <AnimatePresence>
        {isOpen && (
          <LinguaLinkChatbot
            isOpen={isOpen}
            onClose={() => setIsOpen(false)}
            settings={settings}
          />
        )}
      </AnimatePresence>
    </>
  );
}