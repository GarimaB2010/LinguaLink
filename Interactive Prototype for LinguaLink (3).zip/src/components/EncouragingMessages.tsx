import { motion } from "motion/react";
import { useEffect, useState } from "react";

const messages = [
  "🌟 Breaking barriers, one conversation at a time!",
  "💬 Your voice matters in any language!",
  "🌍 Connecting the world, one word at a time!",
  "✨ AI magic is happening right now!",
  "🎯 Making communication accessible for everyone!",
  "💝 Spreading love through understanding!",
  "🚀 Technology bringing people together!",
  "🌈 Every language is beautiful!",
  "💡 Empowering communication for all!",
  "🎉 You're making a difference!"
];

interface EncouragingMessagesProps {
  interval?: number;
}

export function EncouragingMessages({ interval = 5000 }: EncouragingMessagesProps) {
  const [currentMessage, setCurrentMessage] = useState(messages[0]);
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setMessageIndex((prev) => {
        const next = (prev + 1) % messages.length;
        setCurrentMessage(messages[next]);
        return next;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [interval]);

  return (
    <motion.div
      key={messageIndex}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.5 }}
      className="text-center text-sm text-muted-foreground italic"
    >
      {currentMessage}
    </motion.div>
  );
}
