import { motion } from "motion/react";
import { CheckCircle, Sparkles } from "lucide-react";

interface SuccessFeedbackProps {
  message: string;
  onClose?: () => void;
  autoClose?: boolean;
}

export function SuccessFeedback({ message, onClose, autoClose = true }: SuccessFeedbackProps) {
  if (autoClose && onClose) {
    setTimeout(onClose, 3000);
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.8, y: -20 }}
      className="fixed top-4 right-4 left-4 mx-auto max-w-sm z-50"
    >
      <div className="bg-green-50 border border-green-200 rounded-2xl p-4 shadow-lg">
        <div className="flex items-center space-x-3">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="flex-shrink-0"
          >
            <CheckCircle className="w-6 h-6 text-green-600" />
          </motion.div>
          <div className="flex-1">
            <p className="text-green-800 font-medium">{message}</p>
          </div>
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles className="w-5 h-5 text-green-500" />
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}