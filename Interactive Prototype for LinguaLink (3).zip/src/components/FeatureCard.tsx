import { LucideIcon } from "lucide-react";
import { motion } from "motion/react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  color: string;
  onClick: () => void;
}

export function FeatureCard({ icon: Icon, title, description, color, onClick }: FeatureCardProps) {
  const handleClick = () => {
    // Haptic feedback
    if ('vibrate' in navigator) {
      navigator.vibrate(50);
    }
    onClick();
  };

  return (
    <motion.button
      onClick={handleClick}
      whileHover={{ 
        scale: 1.08,
        y: -12,
        rotateZ: 2
      }}
      whileTap={{ scale: 0.95 }}
      className={`w-full p-6 rounded-3xl shadow-xl hover:shadow-2xl transition-all duration-300 ${color} text-white relative overflow-hidden group`}
    >
      {/* Animated background effect */}
      <motion.div
        className="absolute inset-0 bg-white/10"
        initial={{ x: "-100%" }}
        whileHover={{ x: "100%" }}
        transition={{ duration: 0.6 }}
      />
      
      <div className="flex flex-col items-center text-center space-y-4 relative z-10">
        <motion.div 
          className="p-4 bg-white/30 rounded-2xl backdrop-blur-sm border-2 border-white/40 shadow-inner"
          whileHover={{ 
            rotate: [0, -15, 15, -15, 0],
            scale: [1, 1.1, 1.1, 1.1, 1]
          }}
          transition={{ duration: 0.6 }}
        >
          <Icon className="w-10 h-10" />
        </motion.div>
        <div>
          <motion.h3 
            className="text-xl mb-2 font-semibold drop-shadow-lg"
            whileHover={{ scale: 1.05 }}
          >
            {title}
          </motion.h3>
          <p className="text-white/95 text-sm leading-relaxed font-medium">{description}</p>
        </div>
      </div>
      
      {/* Enhanced sparkle effects */}
      <motion.div
        className="absolute top-3 right-3 w-3 h-3 bg-yellow-300 rounded-full shadow-lg"
        animate={{
          scale: [0, 1.2, 0],
          opacity: [0, 1, 0],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          delay: Math.random() * 2,
        }}
      />
      <motion.div
        className="absolute bottom-5 left-5 w-2 h-2 bg-white rounded-full shadow-lg"
        animate={{
          scale: [0, 1.3, 0],
          opacity: [0, 1, 0],
        }}
        transition={{
          duration: 2.5,
          repeat: Infinity,
          delay: Math.random() * 2,
        }}
      />
      <motion.div
        className="absolute top-1/2 left-3 w-1.5 h-1.5 bg-yellow-200 rounded-full"
        animate={{
          scale: [0, 1, 0],
          opacity: [0, 1, 0],
        }}
        transition={{
          duration: 1.8,
          repeat: Infinity,
          delay: Math.random() * 2,
        }}
      />
      
      {/* Pulse ring on hover */}
      <motion.div
        className="absolute inset-0 border-4 border-white/30 rounded-3xl"
        initial={{ opacity: 0, scale: 0.9 }}
        whileHover={{ 
          opacity: [0, 0.5, 0],
          scale: [0.9, 1.1, 1.2]
        }}
        transition={{ duration: 0.8 }}
      />
    </motion.button>
  );
}
