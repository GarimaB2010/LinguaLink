import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Camera, Mic, AlertCircle, CheckCircle, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Alert, AlertDescription } from './ui/alert';
import { toast } from 'sonner@2.0.3';
import { useNotifications } from './NotificationContext';

interface SimpleMediaManagerProps {
  onPermissionsUpdated: (permissions: Record<string, boolean>) => void;
  requiredFeatures?: string[];
  onClose?: () => void;
}

export function SimpleMediaManager({ onPermissionsUpdated, requiredFeatures = [], onClose }: SimpleMediaManagerProps) {
  const [permissions, setPermissions] = useState({
    camera: false,
    microphone: false
  });
  const [isRequesting, setIsRequesting] = useState(false);
  const { canShowCameraNotification, markCameraNotificationShown } = useNotifications();

  const requestMicrophone = async () => {
    try {
      setIsRequesting(true);
      toast.info('🎤 Requesting microphone access...', { duration: 2000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      
      if (stream) {
        // Keep stream alive briefly
        setTimeout(() => {
          stream.getTracks().forEach(track => track.stop());
        }, 1000);
        
        const newPermissions = { ...permissions, microphone: true };
        setPermissions(newPermissions);
        onPermissionsUpdated(newPermissions);
        
        toast.success('✅ Microphone access granted!', { duration: 3000 });
        return true;
      }
    } catch (error: any) {
      console.error('Microphone permission failed:', error);
      toast.error(`❌ Microphone denied: ${error.message}`, { duration: 4000 });
      return false;
    } finally {
      setIsRequesting(false);
    }
  };

  const requestCamera = async () => {
    try {
      setIsRequesting(true);
      toast.info('📹 Requesting camera access...', { duration: 2000 });
      
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 1280 }, 
          height: { ideal: 720 }
        } 
      });
      
      if (stream) {
        // Keep stream alive briefly
        setTimeout(() => {
          stream.getTracks().forEach(track => track.stop());
        }, 1000);
        
        const newPermissions = { ...permissions, camera: true };
        setPermissions(newPermissions);
        onPermissionsUpdated(newPermissions);
        
        // Only show camera notification if none has been shown yet
        if (canShowCameraNotification()) {
          toast.success('✅ Camera access granted!', { 
            duration: 3000,
            description: 'You can now use camera features!'
          });
          markCameraNotificationShown();
        }
        return true;
      }
    } catch (error: any) {
      console.error('Camera permission failed:', error);
      toast.error(`❌ Camera denied: ${error.message}`, { duration: 4000 });
      return false;
    } finally {
      setIsRequesting(false);
    }
  };

  const requestAllPermissions = async () => {
    setIsRequesting(true);
    
    const needsMic = requiredFeatures.includes('microphone');
    const needsCamera = requiredFeatures.includes('camera');
    
    let results = { microphone: false, camera: false };
    
    if (needsMic) {
      results.microphone = await requestMicrophone();
    }
    
    if (needsCamera) {
      results.camera = await requestCamera();
    }
    
    const allSuccess = (!needsMic || results.microphone) && (!needsCamera || results.camera);
    
    if (allSuccess) {
      toast.success('🎉 All permissions granted! You\'re ready!', { duration: 4000 });
      setTimeout(() => {
        onClose?.();
      }, 2000);
    }
    
    setIsRequesting(false);
  };

  // Auto-request on mount
  useEffect(() => {
    if (requiredFeatures.length > 0) {
      setTimeout(() => {
        requestAllPermissions();
      }, 1000);
    }
  }, []);

  const needsMicrophone = requiredFeatures.includes('microphone');
  const needsCamera = requiredFeatures.includes('camera');
  const hasAllNeeded = (!needsMicrophone || permissions.microphone) && (!needsCamera || permissions.camera);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.8 }}
      className="fixed inset-0 bg-black/60 backdrop-blur-md z-50 flex items-center justify-center p-4"
    >
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
          <motion.div
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0]
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center"
          >
            <Zap className="w-8 h-8 text-white" />
          </motion.div>
          <CardTitle className="text-xl">Quick Permission Setup</CardTitle>
          <p className="text-sm text-muted-foreground">
            Let's get your {requiredFeatures.join(' and ')} ready for LinguaLink!
          </p>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Browser Check */}
          {!navigator.mediaDevices && (
            <Alert className="border-red-200 bg-red-50">
              <AlertCircle className="w-4 h-4" />
              <AlertDescription>
                ❌ Your browser doesn't support media features. Please use Chrome, Edge, or Safari.
              </AlertDescription>
            </Alert>
          )}

          {/* Permission Status */}
          <div className="space-y-3">
            {needsMicrophone && (
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Mic className="w-5 h-5" />
                  <div>
                    <div className="font-medium">Microphone</div>
                    <div className="text-xs text-muted-foreground">For speech recognition</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {permissions.microphone ? (
                    <div className="flex items-center text-green-600">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      <span className="text-sm">Ready</span>
                    </div>
                  ) : (
                    <Button
                      size="sm"
                      onClick={requestMicrophone}
                      disabled={isRequesting}
                      className="bg-blue-500 hover:bg-blue-600"
                    >
                      {isRequesting ? 'Requesting...' : 'Grant'}
                    </Button>
                  )}
                </div>
              </div>
            )}

            {needsCamera && (
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <Camera className="w-5 h-5" />
                  <div>
                    <div className="font-medium">Camera</div>
                    <div className="text-xs text-muted-foreground">For sign language recognition</div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {permissions.camera ? (
                    <div className="flex items-center text-green-600">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      <span className="text-sm">Ready</span>
                    </div>
                  ) : (
                    <Button
                      size="sm"
                      onClick={requestCamera}
                      disabled={isRequesting}
                      className="bg-blue-500 hover:bg-blue-600"
                    >
                      {isRequesting ? 'Requesting...' : 'Grant'}
                    </Button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="space-y-2 pt-4">
            {!hasAllNeeded && (
              <Button
                onClick={requestAllPermissions}
                disabled={isRequesting}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                {isRequesting ? (
                  <>
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-4 h-4 mr-2"
                    >
                      <Zap className="w-4 h-4" />
                    </motion.div>
                    Getting Permissions...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Grant All Permissions
                  </>
                )}
              </Button>
            )}

            <Button
              variant="outline"
              onClick={() => {
                onClose?.();
                toast.info('ℹ️ You can grant permissions later when needed', { duration: 4000 });
              }}
              className="w-full"
            >
              {hasAllNeeded ? 'Continue' : 'Skip for Now'}
            </Button>
          </div>

          <div className="text-xs text-center text-muted-foreground">
            🔒 All processing happens locally. Your privacy is protected.
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}