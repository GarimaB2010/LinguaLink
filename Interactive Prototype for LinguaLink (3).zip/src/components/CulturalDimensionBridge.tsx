import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Globe, Users, Compass, Map, Link, Lightbulb, Star, Crown } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';

interface CulturalDimension {
  name: string;
  userScore: number;
  targetScore: number;
  gap: number;
  description: string;
}

interface CulturalProfile {
  primaryCulture: string;
  secondaryCultures: string[];
  communicationStyle: string;
  dimensions: CulturalDimension[];
  bridgeRecommendations: string[];
  culturalTips: string[];
}

interface CulturalBridgeProps {
  isActive: boolean;
  userInput: string;
  targetLanguage: string;
  onBridgeComplete: (profile: CulturalProfile) => void;
}

export function CulturalDimensionBridge({ isActive, userInput, targetLanguage, onBridgeComplete }: CulturalBridgeProps) {
  const [bridgeStage, setBridgeStage] = useState('idle');
  const [culturalMapping, setCulturalMapping] = useState(0);
  const [dimensionAnalysis, setDimensionAnalysis] = useState(0);
  const [contextualBridge, setContextualBridge] = useState(0);
  const [currentProfile, setCurrentProfile] = useState<CulturalProfile | null>(null);

  const culturalDimensions = [
    {
      name: 'Power Distance',
      icon: Crown,
      description: 'Hierarchy and authority acceptance'
    },
    {
      name: 'Individualism',
      icon: Users,
      description: 'Individual vs collective focus'
    },
    {
      name: 'Uncertainty Avoidance',
      icon: Compass,
      description: 'Comfort with ambiguity'
    },
    {
      name: 'Long-term Orientation',
      icon: Map,
      description: 'Future vs present focus'
    },
    {
      name: 'Indulgence',
      icon: Star,
      description: 'Freedom of expression'
    }
  ];

  const culturalStyles = {
    'english': {
      name: 'Anglo-Saxon',
      style: 'Direct, individualistic',
      powerDistance: 35,
      individualism: 89,
      uncertainty: 35,
      longTerm: 51,
      indulgence: 69
    },
    'spanish': {
      name: 'Hispanic',
      style: 'Warm, relationship-focused',
      powerDistance: 57,
      individualism: 51,
      uncertainty: 86,
      longTerm: 48,
      indulgence: 44
    },
    'chinese': {
      name: 'East Asian',
      style: 'Indirect, context-sensitive',
      powerDistance: 80,
      individualism: 20,
      uncertainty: 30,
      longTerm: 87,
      indulgence: 24
    },
    'arabic': {
      name: 'Middle Eastern',
      style: 'Formal, respect-oriented',
      powerDistance: 70,
      individualism: 45,
      uncertainty: 75,
      longTerm: 61,
      indulgence: 34
    },
    'japanese': {
      name: 'Japanese',
      style: 'Highly contextual, harmony-focused',
      powerDistance: 54,
      individualism: 46,
      uncertainty: 92,
      longTerm: 88,
      indulgence: 42
    }
  };

  useEffect(() => {
    if (isActive) {
      startCulturalBridging();
    }
  }, [isActive, userInput, targetLanguage]);

  const startCulturalBridging = async () => {
    setBridgeStage('mapping');
    
    // Stage 1: Cultural Mapping
    for (let i = 0; i <= 100; i += 3) {
      setCulturalMapping(i);
      await new Promise(resolve => setTimeout(resolve, 30));
    }

    // Stage 2: Dimensional Analysis
    setBridgeStage('analyzing');
    for (let i = 0; i <= 100; i += 4) {
      setDimensionAnalysis(i);
      await new Promise(resolve => setTimeout(resolve, 25));
    }

    // Stage 3: Contextual Bridge Building
    setBridgeStage('bridging');
    for (let i = 0; i <= 100; i += 5) {
      setContextualBridge(i);
      await new Promise(resolve => setTimeout(resolve, 20));
    }

    // Generate cultural profile
    const profile = generateCulturalProfile();
    setCurrentProfile(profile);
    setBridgeStage('complete');
    onBridgeComplete(profile);

    // Auto-reset
    setTimeout(() => {
      setBridgeStage('idle');
      setCurrentProfile(null);
      setCulturalMapping(0);
      setDimensionAnalysis(0);
      setContextualBridge(0);
    }, 6000);
  };

  const generateCulturalProfile = (): CulturalProfile => {
    // Detect source culture (simplified)
    const sourceCulture = 'english'; // Default assumption
    const targetCulture = targetLanguage.toLowerCase();
    
    const sourceData = culturalStyles[sourceCulture as keyof typeof culturalStyles] || culturalStyles.english;
    const targetData = culturalStyles[targetCulture as keyof typeof culturalStyles] || culturalStyles.english;

    // Calculate dimensional gaps
    const dimensions: CulturalDimension[] = [
      {
        name: 'Power Distance',
        userScore: sourceData.powerDistance,
        targetScore: targetData.powerDistance,
        gap: Math.abs(targetData.powerDistance - sourceData.powerDistance),
        description: 'Hierarchy acceptance and formal structure'
      },
      {
        name: 'Individualism',
        userScore: sourceData.individualism,
        targetScore: targetData.individualism,
        gap: Math.abs(targetData.individualism - sourceData.individualism),
        description: 'Self-reliance vs group harmony'
      },
      {
        name: 'Uncertainty Avoidance',
        userScore: sourceData.uncertainty,
        targetScore: targetData.uncertainty,
        gap: Math.abs(targetData.uncertainty - sourceData.uncertainty),
        description: 'Comfort with ambiguous situations'
      },
      {
        name: 'Long-term Orientation',
        userScore: sourceData.longTerm,
        targetScore: targetData.longTerm,
        gap: Math.abs(targetData.longTerm - sourceData.longTerm),
        description: 'Future planning vs immediate results'
      },
      {
        name: 'Indulgence',
        userScore: sourceData.indulgence,
        targetScore: targetData.indulgence,
        gap: Math.abs(targetData.indulgence - sourceData.indulgence),
        description: 'Expression freedom vs social norms'
      }
    ];

    // Generate bridge recommendations
    const bridgeRecommendations = generateBridgeRecommendations(dimensions, targetData);
    const culturalTips = generateCulturalTips(targetCulture, dimensions);

    return {
      primaryCulture: sourceData.name,
      secondaryCultures: [targetData.name],
      communicationStyle: targetData.style,
      dimensions,
      bridgeRecommendations,
      culturalTips
    };
  };

  const generateBridgeRecommendations = (dimensions: CulturalDimension[], targetData: any): string[] => {
    const recommendations = [];

    // Power Distance recommendations
    const powerGap = dimensions.find(d => d.name === 'Power Distance')?.gap || 0;
    if (powerGap > 30) {
      if (targetData.powerDistance > 60) {
        recommendations.push('🏛️ Use more formal titles and show respect for hierarchy');
      } else {
        recommendations.push('🤝 Adopt a more egalitarian and casual approach');
      }
    }

    // Individualism recommendations
    const individualismGap = dimensions.find(d => d.name === 'Individualism')?.gap || 0;
    if (individualismGap > 30) {
      if (targetData.individualism < 40) {
        recommendations.push('👥 Emphasize group harmony and collective benefits');
      } else {
        recommendations.push('🎯 Focus on personal achievements and individual goals');
      }
    }

    // Uncertainty Avoidance recommendations
    const uncertaintyGap = dimensions.find(d => d.name === 'Uncertainty Avoidance')?.gap || 0;
    if (uncertaintyGap > 30) {
      if (targetData.uncertainty > 60) {
        recommendations.push('📋 Provide detailed structure and clear expectations');
      } else {
        recommendations.push('🌊 Embrace flexibility and adaptability in communication');
      }
    }

    // Long-term Orientation recommendations
    const longTermGap = dimensions.find(d => d.name === 'Long-term Orientation')?.gap || 0;
    if (longTermGap > 30) {
      if (targetData.longTerm > 60) {
        recommendations.push('🎋 Emphasize long-term benefits and future planning');
      } else {
        recommendations.push('⚡ Focus on immediate results and quick wins');
      }
    }

    return recommendations.slice(0, 4);
  };

  const generateCulturalTips = (culture: string, dimensions: CulturalDimension[]): string[] => {
    const tips: { [key: string]: string[] } = {
      spanish: [
        '🌮 Personal relationships come before business',
        '⏰ Time is flexible - allow for extended conversations',
        '🤗 Physical warmth and expressiveness are valued',
        '👨‍👩‍👧‍👦 Family and community connections are central'
      ],
      chinese: [
        '🙏 Face-saving and dignity are paramount',
        '🎭 Indirect communication - read between the lines',
        '🧧 Reciprocity and gift-giving show respect',
        '⚖️ Harmony and avoiding conflict are important'
      ],
      arabic: [
        '🕌 Religious and cultural sensitivities matter',
        '👥 Group consensus and consultation are valued',
        '🎩 Formal greetings and titles show respect',
        '🍵 Hospitality and relationship-building take time'
      ],
      japanese: [
        '🎌 Extreme attention to detail and perfection',
        '🤫 Silence and pauses are part of communication',
        '🙇 Bowing and formal respect are essential',
        '🌸 Seasonal and contextual awareness shows sophistication'
      ]
    };

    return tips[culture] || [
      '🌍 Research local customs before communicating',
      '👂 Listen actively and observe non-verbal cues',
      '🤝 Build trust through consistent respectful interaction',
      '📚 Learn about their values and worldview'
    ];
  };

  if (!isActive) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
    >
      <Card className="w-[600px] max-h-[80vh] overflow-y-auto bg-gradient-to-br from-indigo-900/90 to-purple-900/90 text-white border-indigo-500/50 shadow-2xl">
        <CardContent className="p-6">
          <div className="text-center mb-6">
            <motion.div
              animate={{ 
                rotateY: [0, 360],
                scale: [1, 1.1, 1]
              }}
              transition={{ 
                duration: 6, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center"
            >
              <Link className="w-8 h-8" />
            </motion.div>
            <h3 className="text-xl font-bold bg-gradient-to-r from-indigo-300 to-purple-300 bg-clip-text text-transparent">
              Cultural Dimension Bridge
            </h3>
            <p className="text-sm text-indigo-200">
              Bridging cultural gaps for deeper understanding
            </p>
          </div>

          {bridgeStage !== 'idle' && bridgeStage !== 'complete' && (
            <div className="space-y-4 mb-6">
              <div className="text-center mb-4">
                <div className="text-sm text-indigo-300 mb-2">
                  {bridgeStage === 'mapping' && '🗺️ Mapping cultural landscapes...'}
                  {bridgeStage === 'analyzing' && '🔍 Analyzing dimensional gaps...'}
                  {bridgeStage === 'bridging' && '🌉 Building contextual bridges...'}
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Cultural Mapping</span>
                  <span className="text-xs text-indigo-300">{culturalMapping}%</span>
                </div>
                <Progress value={culturalMapping} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Dimensional Analysis</span>
                  <span className="text-xs text-indigo-300">{dimensionAnalysis}%</span>
                </div>
                <Progress value={dimensionAnalysis} className="h-2" />

                <div className="flex justify-between items-center">
                  <span className="text-sm">Contextual Bridge</span>
                  <span className="text-xs text-indigo-300">{contextualBridge}%</span>
                </div>
                <Progress value={contextualBridge} className="h-2" />
              </div>
            </div>
          )}

          {currentProfile && bridgeStage === 'complete' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-6"
            >
              {/* Cultural Overview */}
              <div className="p-4 bg-gradient-to-r from-indigo-500/20 to-purple-500/20 rounded-lg border border-indigo-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Globe className="w-4 h-4" />
                  <span>Cultural Bridge Analysis</span>
                </h4>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <span className="text-xs text-indigo-300">Your Culture:</span>
                    <p className="text-sm text-white">{currentProfile.primaryCulture}</p>
                  </div>
                  <div>
                    <span className="text-xs text-indigo-300">Target Style:</span>
                    <p className="text-sm text-white">{currentProfile.communicationStyle}</p>
                  </div>
                </div>

                <div>
                  <span className="text-xs text-indigo-300 mb-2 block">Cultural Dimensions Gap Analysis:</span>
                  <div className="space-y-3">
                    {currentProfile.dimensions.map((dimension, index) => {
                      const DimensionIcon = culturalDimensions.find(d => d.name === dimension.name)?.icon || Compass;
                      return (
                        <div key={index} className="flex items-center space-x-3">
                          <DimensionIcon className="w-4 h-4 text-indigo-400" />
                          <div className="flex-1">
                            <div className="flex justify-between text-xs mb-1">
                              <span>{dimension.name}</span>
                              <span className={`${dimension.gap > 30 ? 'text-orange-300' : 'text-green-300'}`}>
                                Gap: {dimension.gap}
                              </span>
                            </div>
                            <div className="flex space-x-2 text-xs">
                              <div className="flex-1 bg-blue-800/50 rounded">
                                <div 
                                  className="bg-blue-500 h-2 rounded"
                                  style={{ width: `${dimension.userScore}%` }}
                                />
                              </div>
                              <span className="text-blue-300">You: {dimension.userScore}</span>
                              <div className="flex-1 bg-purple-800/50 rounded">
                                <div 
                                  className="bg-purple-500 h-2 rounded"
                                  style={{ width: `${dimension.targetScore}%` }}
                                />
                              </div>
                              <span className="text-purple-300">Target: {dimension.targetScore}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Bridge Recommendations */}
              <div className="p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg border border-purple-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Lightbulb className="w-4 h-4" />
                  <span>Cultural Bridge Recommendations</span>
                </h4>
                
                <div className="space-y-2">
                  {currentProfile.bridgeRecommendations.map((rec, index) => (
                    <Badge key={index} variant="outline" className="w-full justify-start text-xs border-purple-400/50 text-purple-200 p-2">
                      {rec}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Cultural Tips */}
              <div className="p-4 bg-gradient-to-r from-green-500/20 to-teal-500/20 rounded-lg border border-green-500/30">
                <h4 className="font-medium mb-3 flex items-center space-x-2">
                  <Star className="w-4 h-4" />
                  <span>Cultural Insights & Tips</span>
                </h4>
                
                <div className="space-y-2">
                  {currentProfile.culturalTips.map((tip, index) => (
                    <div key={index} className="text-xs text-green-200 flex items-start space-x-2">
                      <span className="text-green-400 mt-0.5">•</span>
                      <span>{tip}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* Bridge Visualization */}
          <div className="mt-6 flex justify-center">
            <div className="relative">
              <motion.div
                animate={{ 
                  rotate: [0, 10, -10, 0],
                  scale: [1, 1.05, 1]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="text-4xl"
              >
                🌉
              </motion.div>
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-xs text-indigo-300">
                Cultural Bridge Active
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}