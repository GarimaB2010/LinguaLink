import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, 
  X, 
  Send, 
  Mic, 
  MicOff, 
  Camera, 
  Settings, 
  Languages, 
  Accessibility, 
  HelpCircle,
  Sparkles,
  Home,
  User
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { toast } from 'sonner@2.0.3';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

interface LinguaLinkChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  settings: any;
}

const QUICK_REPLIES = [
  { text: "How to get started", icon: HelpCircle, category: "🚀 Tutorial" },
  { text: "Navigate the website", icon: Settings, category: "🧭 Guide" },
  { text: "Revolutionary AI features", icon: Sparkles, category: "✨ Hot" },
  { text: "How to use voice recognition", icon: Mic, category: "🎤 Voice" },
  { text: "Sign language tutorial", icon: Camera, category: "🤟 Sign" },
  { text: "Settings and customization", icon: Languages, category: "⚙️ Setup" }
];

const KNOWLEDGE_BASE: Record<string, { answer: string; quickActions?: string[] }> = {
  "speech recognition": {
    answer: "🎤 **Speech Recognition Setup:**\n\n**Step 1: Grant Microphone Permission**\n• Click the 🔐 button at top-right\n• Allow microphone access when prompted\n• Or go to Settings → Quick Media Test\n\n**Step 2: Navigate to Conversation**\n• Tap 💬 in bottom navigation\n• Select 'Speak' mode at the top\n\n**Step 3: Start Speaking**\n• Click the microphone icon\n• Speak clearly into your device\n• Watch real-time transcription appear\n\n**Pro Tips:**\n• Ensure quiet environment for best results\n• Speak at normal pace\n• Click the speaker icon to hear text-to-speech\n\n**Troubleshooting:**\n• Refresh page if mic isn't working\n• Check browser settings for mic permission\n• Try Google Chrome for best compatibility",
    quickActions: ["Test microphone", "Go to conversation", "Check permissions"]
  },

  "camera": {
    answer: "📹 **Camera & Sign Language Setup:**\n\n**Step 1: Grant Camera Permission**\n• Click the 🔐 button at top-right\n• Allow camera access when prompted\n• Position camera at eye level for best results\n\n**Step 2: Access Sign Language Mode**\n• Go to Conversation page (💬)\n• Select 'Sign' mode\n• Ensure good lighting and clear background\n\n**Step 3: Start Signing**\n• Keep hands visible in camera frame\n• Start with simple letters (A-Z)\n• Watch confidence scoring for feedback\n\n**Supported Features:**\n• ASL alphabet recognition\n• Common word detection\n• Real-time translation\n• Learning progress tracking\n\n**Best Practices:**\n• Ensure adequate lighting\n• Keep consistent hand positioning\n• Sign at normal speed",
    quickActions: ["Test camera", "Try sign language", "Check lighting"]
  },

  "audio": {
    answer: "🔊 **Audio & Sound Setup:**\n\n**Text-to-Speech Controls:**\n• Click speaker icons (🔊) to hear text\n• Adjust speed in Settings page\n• Choose male/female voices\n• Control volume and auto-play\n\n**Audio Feedback:**\n• Button clicks have sound effects\n• Success notifications with audio\n• Voice confirmation for actions\n\n**Settings Customization:**\n• Go to Settings page (⚙️)\n• Adjust 'Speech Speed' (0.5x to 2x)\n• Select 'Voice Type' preference\n• Toggle 'Auto-play' on/off\n\n**Quick Test:**\n• Settings → Quick Media Test\n• Tests all audio functionality\n• Checks speaker output\n• Verifies volume levels\n\n**Troubleshooting:**\n• Check device volume levels\n• Ensure speakers/headphones work\n• Try different browsers if issues persist",
    quickActions: ["Test audio", "Adjust settings", "Check volume"]
  },

  "language": {
    answer: "🌍 **Language & Translation Features:**\n\n**Supported Languages:**\n• 50+ languages for speech recognition\n• Real-time translation between languages\n• Cultural context preservation\n• Regional dialect support\n\n**Language Settings:**\n• Go to Settings page (⚙️)\n• Select 'Preferred Language'\n• Choose from extensive language list\n• Settings apply across all features\n\n**Translation Features:**\n• Automatic language detection\n• Quantum Translation Engine (Revolutionary!)\n• Cultural Dimension Bridge\n• Context-aware translations\n\n**Usage:**\n• Speak in any supported language\n• Text is auto-detected and translated\n• Original text can be shown alongside\n• Cultural context tips provided\n\n**Revolutionary AI:**\n• Try our Quantum Translation Engine\n• 99.7% accuracy with cultural context\n• Emotional resonance matching",
    quickActions: ["Change language", "Try translation", "Revolutionary features"]
  },

  "sign language": {
    answer: "🤟 **Sign Language Recognition Guide:**\n\n**Getting Started:**\n• Navigate to Conversation page (💬)\n• Select 'Sign' mode tab\n• Grant camera permission when prompted\n• Position hands clearly in camera view\n\n**What's Supported:**\n• American Sign Language (ASL)\n• Alphabet letters (A-Z)\n• Common words and phrases\n• Numbers (1-10)\n• Basic conversation signs\n\n**Tips for Best Results:**\n• Ensure good lighting (natural light preferred)\n• Keep hands in camera frame\n• Sign at normal, consistent speed\n• Maintain clear background\n• Face the camera directly\n\n**Learning Features:**\n• Real-time confidence scoring\n• Progress tracking\n• Practice mode available\n• Instant feedback on accuracy\n\n**Revolutionary Technology:**\n• Holographic Gesture Interface\n• 3D spatial recognition\n• Advanced gesture mapping",
    quickActions: ["Try signing", "Practice alphabet", "Check camera"]
  },

  "accessibility": {
    answer: "♿ **Accessibility Features:**\n\n**Visual Accessibility:**\n• Large text options (50% to 200%)\n• High contrast mode\n• Color blind friendly palette\n• Dark mode support\n• Reduced motion options\n\n**Motor Accessibility:**\n• Large touch targets\n• Voice navigation\n• Easy mode interface\n• Gesture alternatives\n• Haptic feedback control\n\n**Cognitive Support:**\n• Text simplification\n• Easy mode interface\n• Clear navigation patterns\n• Consistent layouts\n• Progress indicators\n\n**Audio Accessibility:**\n• Screen reader compatibility\n• Audio descriptions\n• Sound visualization\n• Volume controls\n• Speed adjustments\n\n**Settings Location:**\n• Go to Settings page (⚙️)\n• Find 'Accessibility' section\n• Customize all options\n• Real-time preview available",
    quickActions: ["Accessibility settings", "Enable easy mode", "Test features"]
  },

  "permissions": {
    answer: "🔐 **Permissions Setup Guide:**\n\n**Quick Access:**\n• Click the 🔐 button (top-right corner)\n• Follow the guided permission setup\n\n**Required Permissions:**\n• **Microphone** - For speech recognition\n• **Camera** - For sign language detection\n\n**Step-by-Step:**\n1. **Click Grant Permissions button**\n2. **Allow Microphone** - Click 'Allow' when prompted\n3. **Allow Camera** - Click 'Allow' when prompted\n4. **Test Everything** - Use Quick Media Test\n\n**If Blocked:**\n• Click the lock icon in browser address bar\n• Change permissions to 'Allow'\n• Refresh the page\n• Try the 🔐 button again\n\n**Browser Support:**\n• Chrome (Recommended)\n• Edge\n• Safari\n• Firefox\n\n**Testing:**\n• Go to Settings → Quick Media Test\n• Verify all permissions working\n• Test microphone and camera\n\n**Troubleshooting:**\n• Refresh page and try again\n• Check browser settings\n• Use incognito mode to test",
    quickActions: ["Grant permissions", "Quick test", "Browser help"]
  },

  "settings": {
    answer: "⚙️ **Settings & Customization:**\n\n**Access Settings:**\n• Tap ⚙️ in bottom navigation\n• Comprehensive customization options\n\n**Key Features:**\n\n**Display & Accessibility:**\n• Text size adjustment (50%-200%)\n• Dark mode toggle\n• Color blind friendly mode\n• Reduce animations\n• High contrast options\n\n**Audio & Voice:**\n• Speech speed control (0.5x-2x)\n• Voice type (male/female)\n• Auto-play settings\n• Volume controls\n\n**Language & Communication:**\n• Preferred language selection\n• Auto-simplification toggle\n• Show original text option\n• Cultural context settings\n\n**Quick Media Test:**\n• One-click testing of all features\n• Microphone test\n• Camera test\n• Audio playback test\n• Permission verification\n\n**Pro Tip:** Use Quick Media Test first to ensure everything works perfectly!",
    quickActions: ["Open settings", "Quick test", "Customize display"]
  },

  "community": {
    answer: "👥 **Community & Impact:**\n\n**Real-World Applications:**\n\n**🏥 Healthcare:**\n• Doctor-patient communication\n• Emergency room assistance\n• Medical terminology simplification\n• 125,000+ people helped\n\n**🎓 Education:**\n• Classroom inclusivity\n• Student-teacher communication\n• Learning disability support\n• 89,000+ students supported\n\n**⚖️ Legal Aid:**\n• Court interpretation\n• Legal document simplification\n• Attorney-client communication\n• 45,000+ cases assisted\n\n**Global Impact:**\n• 259,000+ total users worldwide\n• 1.2M+ successful conversations\n• 50+ languages supported\n• 98.7% user satisfaction rate\n\n**How to Explore:**\n• Visit Community page (👥 in navigation)\n• See live demos of each use case\n• Read success stories\n• View global impact statistics",
    quickActions: ["Visit community", "See demos", "View impact"]
  },

  "demo": {
    answer: "🎯 **Demo & Testing:**\n\n**Try these features:**\n1. **Speech Recognition** - Click mic button and speak\n2. **Text-to-Speech** - Click speaker to hear text\n3. **Sign Language** - Use camera for gesture recognition\n4. **Text Simplification** - Make complex text easier\n\n**Quick tests:**\n• Media test in Settings\n• Revolutionary features in Conversation\n• Community use case demos\n\n**Best browsers:**\nChrome, Edge, Safari (latest versions)",
    quickActions: ["Start demo", "Test features", "Browser check"]
  },

  "navigation": {
    answer: "🧭 **Website Navigation Guide:**\n\n**🏠 Home Page:**\n• Main dashboard with 4 feature cards\n• Click Speak, Type, Sign, or Simplify\n• Quick access to all major features\n\n**💬 Conversation Page:**\n• Real-time communication tools\n• Switch between modes: Speak, Type, Sign, Simplify\n• Revolutionary AI features panel\n• Live text input/output area\n\n**⚙️ Settings Page:**\n• Customize text size, themes, voices\n• Quick Media Test for permissions\n• Accessibility options\n• Language preferences\n\n**👥 Community Page:**\n• Real-world use case demos\n• Healthcare, Education, Legal examples\n• Success stories and impact stats\n\n**Bottom Navigation:**\nTap any icon to switch between pages instantly!",
    quickActions: ["Go to Home", "Open Settings", "View Community"]
  },

  "homepage": {
    answer: "🏠 **Home Page Guide:**\n\n**Main Feature Cards:**\n\n🎤 **Speak Card**\n• Tap to go to voice recognition\n• Uses microphone for speech-to-text\n• Real-time transcription\n\n✍️ **Type Card**\n• Traditional text input mode\n• Enhanced with AI assistance\n• Text-to-speech playback\n\n🤟 **Sign Card**\n• ASL gesture recognition\n• Camera-based sign detection\n• Real-time translation\n\n🧠 **Simplify Card**\n• Complex text simplification\n• Multiple difficulty levels\n• Educational support\n\n**Getting Started:**\n1. Choose any card based on your needs\n2. Grant permissions when prompted\n3. Start communicating immediately!\n\nWhich feature would you like to try first?",
    quickActions: ["Try Speak", "Try Sign", "Try Simplify"]
  }
};

export function LinguaLinkChatbot({ isOpen, onClose, settings }: LinguaLinkChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "🌟 Hello! I'm Lingua, your LinguaLink navigation assistant! I'm here to help you explore every amazing feature of our revolutionary communication platform!\n\n💡 **Quick Start:**\n• Ask me about any feature\n• Get step-by-step tutorials  \n• Navigate to any page\n• Troubleshoot issues\n\nWhat would you like to explore today? 😊",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
        toast.error('Speech recognition error. Please try again.');
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }
  }, []);

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) {
      toast.error('Speech recognition not supported in this browser');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  const generateBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    // Revolutionary features questions
    if (message.includes('revolutionary') || message.includes('quantum') || message.includes('neural') || message.includes('empathy') || message.includes('holographic')) {
      return "🚀 **Revolutionary AI Features!** 🚀\n\nYou've discovered our cutting-edge technology! Here's what makes LinguaLink truly revolutionary:\n\n🧠 **Quantum Translation Engine**\n• Multi-dimensional linguistic processing\n• 99.7% accuracy with cultural context\n• Real-time emotional resonance matching\n\n💖 **Neural Empathy Synchronization**\n• Detects emotional state through bio-signals\n• Adapts communication style automatically\n• Creates empathetic connections between users\n\n✨ **Holographic Gesture Interface**\n• 3D spatial interaction system\n• Gesture recognition in virtual space\n• Next-generation accessibility controls\n\n🧬 **Bio-Rhythmic Communication Matching**\n• Analyzes circadian rhythms and stress levels\n• Optimizes timing for conversations\n• Personalizes interaction based on energy levels\n\n🌉 **Cultural Dimension Bridge**\n• Maps cultural communication patterns\n• Bridges cultural gaps automatically\n• Provides context-aware cultural tips\n\n⚡ **Synaptic Learning Assistant**\n• AI that evolves with each conversation\n• Learns your unique communication style\n• Optimizes interface for your preferences\n\nThese features are **never-before-seen** in any communication platform! Want to try one? Just go to the Conversation page and click any of the revolutionary feature buttons! 🎯";
    }
    
    // Check knowledge base
    for (const [keyword, data] of Object.entries(KNOWLEDGE_BASE)) {
      if (message.includes(keyword) || message.includes(keyword.replace(' ', ''))) {
        return data.answer;
      }
    }

    // Common greetings
    if (message.match(/\b(hi|hello|hey|help)\b/)) {
      return "Hello there! 👋 I'm absolutely thrilled to help you master LinguaLink! \n\n🌟 **Popular Topics:**\n• 🎤 Speech recognition mastery\n• 📹 Camera & sign language magic\n• 🔊 Crystal-clear audio setup\n• 🌍 Global language support\n• ♿ Accessibility superpowers\n• 🚀 **Revolutionary AI features** ⭐\n\nWhat amazing feature would you like to explore first? I'm here to make your LinguaLink experience absolutely phenomenal! ✨";
    }

    // Tutorial and getting started guidance
    if (message.includes('how to use') || message.includes('how do i') || message.includes('get started') || message.includes('tutorial') || message.includes('guide me') || message.includes('show me how')) {
      return "📚 **Complete LinguaLink Tutorial:**\n\n**🚀 Quick Start (30 seconds):**\n1. **Grant Permissions** - Click 🔐 button, allow camera & mic\n2. **Choose Mode** - Tap any card on Home page\n3. **Start Communicating** - Speak, type, sign, or simplify!\n\n**📱 Detailed Walkthrough:**\n\n**Step 1: Understanding the Interface**\n• **Bottom Navigation**: 4 main sections\n• **Home** 🏠: Feature cards and quick access\n• **Conversation** 💬: Active communication tools\n• **Settings** ⚙️: Customization and testing\n• **Community** 👥: Real-world examples\n\n**Step 2: Setting Up Permissions**\n• Look for 🔐 button (top-right corner)\n• Click it for permission guide\n• Allow camera for sign language\n• Allow microphone for speech recognition\n• Test everything in Settings → Quick Media Test\n\n**Step 3: Exploring Features**\n• **Start with Home page** - tap feature cards\n• **Try Conversation page** - switch between modes\n• **Customize in Settings** - adjust to your needs\n• **Explore Community** - see real impact\n\n**Step 4: Advanced Features**\n• Revolutionary AI panel in Conversation\n• Voice commands throughout the app\n• Accessibility options in Settings\n\n**Need specific help?** Ask me 'how to [specific task]' and I'll guide you step-by-step! 😊";
    }

    // Navigation and website guidance  
    if (message.includes('navigate') || message.includes('go to') || message.includes('where') || message.includes('find') || message.includes('page')) {
      return KNOWLEDGE_BASE['navigation'].answer;
    }

    // Homepage questions
    if (message.includes('home') || message.includes('main page') || message.includes('dashboard') || message.includes('start page')) {
      return KNOWLEDGE_BASE['homepage'].answer;
    }

    // Specific page guidance
    if (message.includes('conversation page') || message.includes('chat page') || message.includes('talk')) {
      return "💬 **Conversation Page Guide:**\n\n**How to get there:**\n• Tap 💬 in bottom navigation\n• Or click any feature card from Home\n\n**What you'll find:**\n\n🎯 **Mode Selector:**\n• Speak: Voice-to-text recognition\n• Type: Enhanced text input\n• Sign: ASL gesture recognition\n• Simplify: Text simplification\n\n⚡ **Revolutionary Features Panel:**\n• 6 cutting-edge AI technologies\n• Quantum Translation Engine\n• Neural Empathy Synchronization\n• Holographic Gesture Interface\n• Bio-Rhythmic Communication Matching\n• Cultural Dimension Bridge\n• Synaptic Learning Assistant\n\n📝 **Communication Area:**\n• Real-time input/output\n• Voice controls and audio feedback\n• Language detection and translation\n\n**Pro Tips:**\n• Switch modes anytime using the tabs\n• Try revolutionary features for amazing results\n• Use voice commands for hands-free operation!";
    }

    // Settings page guidance  
    if (message.includes('settings page') || message.includes('configuration') || message.includes('preferences')) {
      return "⚙️ **Settings Page Deep Dive:**\n\n**How to get there:**\n• Tap ⚙️ in bottom navigation\n\n**Customization Options:**\n\n🎨 **Display & Accessibility:**\n• Text size: 50% to 200%\n• Dark mode toggle\n• Color blind friendly mode\n• Reduce animations\n• High contrast options\n\n🔊 **Audio & Voice:**\n• Speech speed control (0.5x to 2x)\n• Voice type selection (male/female)\n• Auto-play settings\n• Volume controls\n\n🌍 **Language & Communication:**\n• Preferred language selection\n• Auto-simplification toggle\n• Show original text option\n• Cultural context settings\n\n♿ **Accessibility Features:**\n• Easy mode interface\n• Haptic feedback control\n• Large touch targets\n• Screen reader compatibility\n\n🔧 **Quick Media Test:**\n• Test microphone instantly\n• Test camera functionality\n• Test audio playback\n• Check all permissions\n\n**Pro Tip:** Use Quick Media Test first to ensure everything works perfectly!";
    }

    // Community page guidance
    if (message.includes('community page') || message.includes('examples') || message.includes('use cases')) {
      return "👥 **Community Page Exploration:**\n\n**How to get there:**\n• Tap 👥 in bottom navigation\n\n**Real-World Demos:**\n\n🏥 **Healthcare Demo:**\n• Emergency room communication\n• Doctor-patient language barriers\n• Medical terminology simplification\n• Real user impact: 125K+ helped\n\n🎓 **Education Demo:**\n• Classroom inclusivity tools\n• Student-teacher communication\n• Learning disability support\n• Real impact: 89K+ students supported\n\n⚖️ **Legal Aid Demo:**\n• Legal consultation access\n• Complex document simplification\n• Court interpretation services\n• Real impact: 45K+ cases assisted\n\n**Global Impact Stats:**\n• 259K+ total users worldwide\n• 1.2M+ successful conversations\n• 50+ languages supported\n• 98.7% user satisfaction rate\n\n**Interactive Elements:**\n• Click any demo to see it in action\n• View before/after examples\n• See real success stories\n• Explore global reach map\n\n**Pro Tip:** These demos show real-world applications - perfect for understanding LinguaLink's true impact!";
    }

    // Specific navigation requests
    if (message.includes('take me to') || message.includes('go to home') || message.includes('go to settings') || message.includes('go to conversation') || message.includes('go to community')) {
      return "🧭 **Navigation Instructions:**\n\n**To navigate anywhere in LinguaLink:**\n\n📱 **Use Bottom Navigation Bar:**\n• **Home** 🏠 - Main dashboard and feature cards\n• **Conversation** 💬 - Communication tools and AI features\n• **Settings** ⚙️ - Customization and testing\n• **Community** 👥 - Real-world examples and impact\n\n**Quick Access Methods:**\n\n🏠 **From Home Page:**\n• Tap any feature card (Speak, Type, Sign, Simplify)\n• This takes you directly to Conversation page\n\n💬 **In Conversation Page:**\n• Switch modes using top tabs\n• Access revolutionary features panel\n• Use voice commands for hands-free navigation\n\n⚙️ **Settings Shortcuts:**\n• Quick Media Test for instant feature testing\n• Accessibility options for easier navigation\n• Voice settings for audio feedback\n\n**Pro Tip:** You can always see which page you're on by checking the highlighted icon in the bottom navigation! The current page icon will be colored and active.\n\nWhere would you like to go? Just tap the corresponding icon! 🎯";
    }

    // Bottom navigation help
    if (message.includes('bottom navigation') || message.includes('navigation bar') || message.includes('menu bar') || message.includes('tabs')) {
      return "📱 **Bottom Navigation Guide:**\n\n**Location & Access:**\n• Fixed at bottom of screen\n• Always visible on all pages\n• 4 main sections with icons\n\n**Navigation Options:**\n\n🏠 **Home Tab**\n• Main dashboard\n• Feature overview cards\n• Quick access to all tools\n• Welcome messages and tips\n\n💬 **Conversation Tab**\n• Active communication tools\n• Mode switching (Speak/Type/Sign/Simplify)\n• Revolutionary AI features panel\n• Real-time input/output area\n\n⚙️ **Settings Tab**\n• Customization options\n• Quick Media Test\n• Accessibility controls\n• Voice and language preferences\n\n👥 **Community Tab**\n• Real-world use cases\n• Success stories\n• Impact statistics\n• Demo examples\n\n**Visual Indicators:**\n• Active tab is highlighted in color\n• Icons show current location\n• Smooth animations between sections\n\n**Accessibility:**\n• Large touch targets\n• Screen reader compatible\n• High contrast mode support\n• Voice navigation available\n\nTap any icon to instantly switch sections! 🚀";
    }

    // Features and capabilities overview
    if (message.includes('what can') || message.includes('features') || message.includes('capabilities') || message.includes('what does') || message.includes('overview')) {
      return "🌟 **LinguaLink Complete Feature Overview:**\n\n**🏠 HOME PAGE:**\n• Feature card dashboard\n• Quick access to all tools\n• Welcome and introduction\n\n**💬 CONVERSATION PAGE:**\n• **Speak Mode:** Voice-to-text recognition\n• **Type Mode:** Enhanced text input\n• **Sign Mode:** ASL gesture recognition\n• **Simplify Mode:** Text simplification\n• **Revolutionary AI Features:** 6 cutting-edge tools\n\n**⚙️ SETTINGS PAGE:**\n• Text size and display options\n• Voice and audio controls\n• Language preferences\n• Accessibility features\n• Quick Media Test\n\n**👥 COMMUNITY PAGE:**\n• Healthcare use case demos\n• Education examples\n• Legal aid applications\n• Global impact statistics\n\n**🚀 REVOLUTIONARY FEATURES:**\n• Quantum Translation Engine\n• Neural Empathy Synchronization\n• Holographic Gesture Interface\n• Bio-Rhythmic Communication Matching\n• Cultural Dimension Bridge\n• Synaptic Learning Assistant\n\n**Want to explore something specific?** Ask me about any page or feature! 😊";
    }

    // Troubleshooting
    if (message.includes('not working') || message.includes('broken') || message.includes('error')) {
      return "🔧 **Troubleshooting Steps:**\n\n1. **Refresh the page** - This fixes most issues\n2. **Check permissions** - Ensure camera/mic access is granted\n3. **Update browser** - Use latest Chrome/Edge for best support\n4. **Clear cache** - Go to browser settings → Clear browsing data\n5. **Try incognito mode** - Rules out extension conflicts\n\nIf issues persist, please describe exactly what's not working and I'll provide specific help!";
    }

    // Default navigation-focused response
    return "🌟 **I'm your LinguaLink navigation guide!** I'm here to help you explore every amazing feature! \n\n🧭 **Navigation Help:**\n• **\"How to get started\"** 🚀 (Perfect for beginners!)\n• **\"Navigate the website\"** 📱 (Complete guide!)\n• **\"Take me to [page name]\"** 🎯 (Direct navigation!)\n\n🔥 **Feature Tutorials:**\n• **\"How to use voice recognition\"** 🎤\n• **\"Sign language tutorial\"** 🤟\n• **\"Revolutionary AI features\"** ⚡\n• **\"Settings and customization\"** ⚙️\n\n📱 **Page-Specific Help:**\n• **\"Home page guide\"** 🏠\n• **\"Conversation page guide\"** 💬\n• **\"Settings page guide\"** ⚙️\n• **\"Community page guide\"** 👥\n\n💡 **Pro Tips:**\n• Try the quick reply buttons below for instant guidance!\n• Ask me \"how to [do something]\" for step-by-step instructions\n• Say \"take me to [page]\" for navigation help\n\nI can guide you through anything in LinguaLink! What would you like to explore? 😊✨";
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: generateBotResponse(inputText),
        sender: 'bot',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleQuickReply = (text: string) => {
    setInputText(text);
    setTimeout(() => handleSendMessage(), 100);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, scale: 0.9 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 50, scale: 0.9 }}
      transition={{ duration: 0.3, type: "spring", stiffness: 300, damping: 25 }}
      className="fixed bottom-24 right-4 w-96 h-[600px] bg-gradient-to-br from-white/95 to-blue-50/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/30 z-50 flex flex-col overflow-hidden"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 p-4 text-white relative overflow-hidden">
        <div className="flex items-center justify-between relative z-10">
          <div className="flex items-center space-x-3">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm"
            >
              <MessageCircle className="w-5 h-5" />
            </motion.div>
            <div>
              <h3 className="font-semibold">Lingua Assistant</h3>
              <p className="text-xs text-blue-100">Your LinguaLink guide</p>
            </div>
          </div>
          <Button
            onClick={onClose}
            size="sm"
            variant="ghost"
            className="text-white hover:bg-white/20 w-8 h-8 p-0 rounded-full"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
        
        {/* Animated background elements */}
        <motion.div
          animate={{ 
            x: [-100, 100, -100],
            y: [-50, 50, -50]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-0 left-0 w-20 h-20 bg-white/10 rounded-full blur-xl"
        />
        <motion.div
          animate={{ 
            x: [100, -100, 100],
            y: [50, -50, 50]
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-0 right-0 w-16 h-16 bg-yellow-400/20 rounded-full blur-xl"
        />
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 space-y-4 overflow-y-auto max-h-[400px]" style={{ scrollbarWidth: 'thin' }}>
        <AnimatePresence>
          {messages.map(message => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] p-3 rounded-2xl ${
                message.sender === 'user'
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                  : 'bg-white/80 text-gray-800 shadow-sm border border-gray-100'
              }`}>
                <div className="whitespace-pre-wrap text-sm leading-relaxed">
                  {message.text}
                </div>
                <div className={`text-xs mt-2 ${
                  message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                }`}>
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {/* Typing indicator */}
        <AnimatePresence>
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex justify-start"
            >
              <div className="bg-white/80 p-3 rounded-2xl shadow-sm border border-gray-100">
                <div className="flex space-x-1">
                  {[0, 1, 2].map(i => (
                    <motion.div
                      key={i}
                      animate={{ y: [0, -8, 0] }}
                      transition={{ 
                        duration: 0.6, 
                        repeat: Infinity, 
                        delay: i * 0.2 
                      }}
                      className="w-2 h-2 bg-blue-500 rounded-full"
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Reply Buttons */}
      <div className="px-4 pb-2">
        <div className="flex flex-wrap gap-2">
          {QUICK_REPLIES.slice(0, 3).map((reply, index) => (
            <motion.button
              key={index}
              onClick={() => handleQuickReply(reply.text)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-3 py-1.5 bg-gradient-to-r from-purple-100 to-blue-100 hover:from-purple-200 hover:to-blue-200 text-purple-700 rounded-full text-xs font-medium transition-all duration-200 border border-purple-200/50"
            >
              <reply.icon className="w-3 h-3 inline mr-1" />
              {reply.category}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div className="p-4 border-t border-gray-200/50 bg-white/50 backdrop-blur-sm">
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me anything about LinguaLink..."
              className="w-full px-4 py-3 rounded-2xl border border-gray-200 focus:border-purple-400 focus:ring-2 focus:ring-purple-100 outline-none bg-white/80 backdrop-blur-sm text-sm placeholder-gray-500"
            />
          </div>
          
          <Button
            onClick={toggleVoiceInput}
            size="sm"
            variant={isListening ? "destructive" : "secondary"}
            className="w-10 h-10 p-0 rounded-2xl"
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </Button>
          
          <Button
            onClick={handleSendMessage}
            disabled={!inputText.trim()}
            size="sm"
            className="w-10 h-10 p-0 rounded-2xl bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}