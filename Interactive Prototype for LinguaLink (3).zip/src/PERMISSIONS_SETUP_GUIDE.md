# 🎥 Camera & Permissions Setup Guide

## How Permissions Work in LinguaLink

LinguaLink automatically manages camera and microphone permissions for you! Here's what happens:

### 📋 Automatic Permission Management

1. **On Page Load**: The app checks which features you're using (Speak, Sign, etc.)
2. **Smart Prompts**: Only requests permissions for features you actually use
3. **User Control**: Camera/mic only activate when YOU press the button

### 🎤 Speech Recognition (Speak Mode)
- **Permission**: Microphone access
- **When**: Automatically requested when you tap "Start Recording"
- **Browser Support**: Chrome, Edge, Safari
- **Fallback**: Shows helpful message if not supported

### 📹 Sign Language (Sign Mode)
- **Permission**: Camera access  
- **When**: Requested when you tap the camera button (NOT automatic)
- **Browser Support**: All modern browsers
- **Fallback**: Clear instructions to enable in browser settings

### 🔒 Privacy & Security

✅ **All processing happens locally in your browser**
✅ **No data is sent to servers**
✅ **Camera/mic stop when you stop using the feature**
✅ **Full control over when to grant permissions**

### 🛠️ Troubleshooting

#### Permission Denied?
1. Click the 🔒 lock icon in your browser's address bar
2. Find "Camera" or "Microphone" settings
3. Change from "Block" to "Allow"
4. Refresh the page

#### Feature Not Working?
- Check the **System Status** in Settings page
- Verify your camera/microphone is connected
- Try using Chrome, Edge, or Safari

#### Browser Compatibility Alert?
- Some browsers don't support all features
- Recommended: Chrome, Edge, or Safari for best experience
- Firefox has limited speech recognition support

### 🎯 Testing Features

To test if everything works:

1. **Go to Settings** → See "System Status" at bottom
2. **Check Feature Health**: Shows which features are available
3. **Grant Permissions**: Use the permission manager if needed

### 💡 Tips

- **First Time**: Allow permissions when prompted
- **Mobile**: May need to enable permissions in device settings too
- **Privacy Mode**: Some features may not work in incognito/private browsing
- **iOS Safari**: Requires user gesture (tap) before accessing camera/mic

---

## For Developers

### Components Overview

- **MediaPermissionsManager**: Handles camera/mic permission requests
- **RealSignLanguage**: Camera access with error handling
- **RealSpeechRecognition**: Microphone access with error handling  
- **BrowserCompatibilityAlert**: Shows warnings for unsupported browsers
- **FeatureHealthCheck**: Displays system status

### Permission Flow

```
User navigates to feature page
    ↓
MediaPermissionsManager checks required permissions
    ↓
If not granted → Shows permission dialog
    ↓
User grants permission
    ↓
Feature component can now access camera/mic
    ↓
User taps button to activate
    ↓
Camera/mic starts
```

### Error Handling

Every component that uses browser APIs includes:
- ✅ Browser support detection
- ✅ Permission status checking
- ✅ User-friendly error messages
- ✅ Fallback UI when features unavailable

---

**Built with ❤️ for accessibility and privacy**
